# FlipFlat 0.10-alpha | Demo Single Player

**Base preservada:** v0.9.1-alpha (fonte + APK da Biblioteca).

## Novidades
- Home com assinatura do skatista saltando sobre um smartphone, baseada na arte aprovada.
- Lobby com Treino Livre, Tentativas Ranqueadas (somente aviso EM BREVE) e Competição Offline / Survival 30s.
- Treino Livre mantém as sete manobras, escolha de uma delas ou modo livre.
- Survival presencial com contagem de 30 segundos desde o toque em ESTOU PRONTO; pontuação das manobras reconhecidas e +120 por cada manobra distinta além da primeira. Recorde salvo apenas quando o tempo se esgota.
- Perfil offline com nick, @rede social opcional (não validado), nível e XP derivados das tentativas locais.
- Carreira com recorde de Survival e histórico preservado.
- Motor de sensores, análise, classificação, calibragem, áudio, replay e CSV de v0.9.1 preservados.

## Fora do escopo
- Sem ranking online, login, antitrapaça remoto, envio de scores ou permissão de Internet.
- Não é binário de publicação/loja; exige QA presencial com sensores e testes de sobrevivência após 30s.

## QA mínimo
1. Instalação por cima da 0.9.1 preserva histórico/som/segurança.
2. Treino Livre mantém escolha de sete manobras e classificação/Replay 3D.
3. Survival inicia em 30s, termina sozinho e não salva score de sessão abortada.
4. Variedade: +120 por 2ª manobra distinta, +240 por 3ª e nenhum extra por repetição.
5. Sair/voltar, fixação de tela, áudio, calibração e CSV não regrediram.
6. Sem Internet ou conta deve funcionar integralmente.

**Nota:** arte de capa é um recorte da arte conceitual aprovada, sem dependências externas.

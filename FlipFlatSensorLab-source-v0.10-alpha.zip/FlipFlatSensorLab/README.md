# Flip Flat V0.9.1 Alpha Hotfix

V0.9.1 is a surgical hotfix on top of V0.9. The stable sensor pipeline, seven-trick catalog, replay, scoring, history, anti-touch protection and calibration tooling are retained.

## Hotfix scope

1. **Flip Flat / Shuriken tutorial correction**
   - Swaps the two canonical 3D motions that were visually inverted in V0.9.
   - Revolving Door, Punch Line, Horizontal, Crazy Not Random and Backflip tutorials are unchanged.

2. **Flip Flat vs Revolving Door recognition fix**
   - The V0.9 screen-normal attitude metric was the wrong discriminator for portrait/landscape pose and caused real Flip Flats to be classified as Revolving Door.
   - V0.9.1 measures the phone's **long screen axis relative to gravity** before the main spin, with rotation-vector data plus accelerometer fallback.
   - Offline replay against known calibration data separates the five historical Flip Flat samples from both recorded Revolving Door samples, while also separating the known Punch Line example from all six recorded Shuriken examples.
   - If pose data is missing, the classifier falls back conservatively rather than forcing Revolving Door/Shuriken.

3. **One sound switch**
   - One player-facing control: **COM SOM / SEM SOM**.
   - It controls both the motion whistle and game feedback sounds.

4. **Reliable game feedback sounds**
   - Start cue and stop cue use Android ToneGenerator as a reliable audible base, layered with the synthesized Flip Flat effects.
   - Invalid attempts get a distinct negative cue.
   - C/B/A/S have progressively stronger result cues.
   - S/new record/first S retains an extra victory flourish.
   - Synthesized SFX amplitude was increased and the continuous motion whistle is briefly ducked when a result cue plays.

5. **Primary action restored above result**
   - `ESTOU PRONTO / SEGURE PARA PARAR` is again kept high in the play screen.
   - The large grade/result card remains visually prominent immediately below the primary control.

## Seven maneuvers

1. Flip Flat
2. Revolving Door
3. Punch Line
4. Shuriken
5. Flip Flat Horizontal
6. Crazy Not Random
7. Backflip

## Core capabilities retained

- Gyroscope / accelerometer / rotation vector / game rotation vector / magnetometer streams.
- Main-spin segmentation and saturation-aware lower-bound turns.
- Conservative recognition: low-confidence motion can remain unrecognized.
- Anti-touch protected play via immersive mode + optional Android screen pinning.
- Motion Whistle driven by gyroscope + accelerometer intensity.
- Immediate 3D replay, history, catalog, local records and achievements.
- Full raw CSV export, event markers, discarded candidates and developer/calibration mode.
- Grade-first reward UI and result flash.

## Scoring philosophy

- Overall grade remains the weakest validated scored criterion.
- Finish remains visible and contributes points, but still does not independently reduce the overall grade until synchronized video calibration is complete.
- Air-time/height remains a bonus signal rather than a hard grade criterion.
- Quantity remains numeric where possible; saturated readings remain honest lower bounds (`>N`).

## Calibration logging

The summary CSV now includes `long_axis_verticality` in addition to the existing `attitude_flatness`, so future sessions can validate the new pose discriminator directly.

## Build

- App id: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- versionCode: 11
- versionName: `0.9.1-alpha`

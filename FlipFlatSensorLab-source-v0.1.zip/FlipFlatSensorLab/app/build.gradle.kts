plugins {
    id("com.android.application")
}

android {
    namespace = "com.tropicalgames.flipflat"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.tropicalgames.flipflat"
        minSdk = 26
        targetSdk = 36
        versionCode = 9
        versionName = "0.8-alpha"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

package com.tropicalgames.flipflat;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int EXPORT_REQUEST = 702;
    private static final float G = SensorManager.GRAVITY_EARTH;

    // V0.2 detection thresholds. These are calibration parameters, not game rules.
    private static final float START_GYRO_RAD_S = 6.0f;
    private static final float STOP_GYRO_RAD_S = 1.20f;
    private static final float HIGH_SPIN_RAD_S = 6.0f;
    // Two-stage validation: ordinary hand movement may trigger capture, but it is not saved as a trick.
    private static final float CONFIRM_PEAK_RAD_S = 13.0f; // ~745 deg/s
    private static final double CONFIRM_MAIN_TURNS = 1.0;
    private static final long MAIN_SPIN_GAP_NS = 45_000_000L;
    private static final long STOP_HOLD_NS = 280_000_000L;
    private static final long MIN_ATTEMPT_NS = 180_000_000L;
    private static final long MAX_ATTEMPT_NS = 4_000_000_000L;
    private static final long PREBUFFER_NS = 650_000_000L;
    private static final int SENSOR_PERIOD_US = 5_000; // target ~200 Hz where supported
    private static final float LOW_G_THRESHOLD = 0.45f * G;
    private static final float SATURATION_FRACTION = 0.965f;
    private static final float ACCEL_SATURATION_FRACTION = 0.965f;
    private static final int MAX_RAW_EVENTS = 220_000;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor rotationVector;
    private Sensor gameRotationVector;
    private Sensor magnetometer;
    private Vibrator vibrator;
    private ToneGenerator toneGenerator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean monitoring = false;
    private boolean attemptActive = false;
    private long sessionStartNs = 0L;
    private long lastGyroTimestampNs = 0L;
    private long attemptStartNs = 0L;
    private long lastAboveStopNs = 0L;

    private float ax = 0f, ay = 0f, az = G;
    private float accelMagnitude = G;
    private float mx = 0f, my = 0f, mz = 0f;
    private float magneticMagnitude = 0f;
    private float liveGyroDegS = 0f;
    private float headingDeg = Float.NaN;
    private int rotAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
    private int magAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;

    private final float[] latestRotationMatrix = identityMatrix();
    private final float[] latestGameRotationMatrix = identityMatrix();
    private boolean hasRotationMatrix = false;
    private boolean hasGameRotationMatrix = false;

    private int attemptCount = 0;
    private int candidateCount = 0;
    private Attempt currentAttempt;
    private final ArrayList<Attempt> attempts = new ArrayList<>();
    private final ArrayList<Attempt> discardedCandidates = new ArrayList<>();
    private final ArrayList<TrickProposal> trickProposals = new ArrayList<>();
    private final ArrayDeque<Frame> preBuffer = new ArrayDeque<>();

    private final StringBuilder rawEventLog = new StringBuilder();
    private final StringBuilder eventLog = new StringBuilder();
    private int rawEventCount = 0;
    private boolean rawLogTruncated = false;

    private TextView statusText;
    private TextView sensorText;
    private TextView gyroText;
    private TextView accelText;
    private TextView headingText;
    private TextView lastResultText;
    private TextView sessionCountText;
    private LinearLayout attemptsContainer;
    private Button playButton;
    private Button exportButton;
    private Button clearButton;
    private Button syncButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        gameRotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 82);

        buildUi();
        updateSensorStatus();
        renderAttempts();

        if (accelerometer == null || gyroscope == null) {
            playButton.setEnabled(false);
            statusText.setText("Este aparelho não possui os sensores mínimos necessários.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (toneGenerator != null) toneGenerator.release();
    }

    private void buildUi() {
        int pad = dp(18);
        int gap = dp(10);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(24), pad, dp(34));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("FLIP FLAT", 36, Color.WHITE, true);
        title.setLetterSpacing(0.08f);
        root.addView(title);

        TextView subtitle = text("Tropical Games  •  Product Alpha V0.3", 14,
                Color.rgb(146, 255, 186), false);
        subtitle.setPadding(0, dp(2), 0, dp(14));
        root.addView(subtitle);

        TextView concept = text(
                "PRODUTO + CALIBRAÇÃO\nMenos é mais: começamos com uma manobra oficial, FLIP FLAT. O app separa movimento comum de tentativa válida, mantém números como ~2.4 ou >3.2 giros e usa grades S/A/B/C sem esconder os limites do sensor.",
                12, Color.rgb(225, 229, 236), false);
        concept.setPadding(dp(14), dp(12), dp(14), dp(12));
        concept.setBackground(roundRect(Color.rgb(34, 38, 44), 14));
        root.addView(concept, lpMatch(gap));

        LinearLayout trickCard = new LinearLayout(this);
        trickCard.setOrientation(LinearLayout.HORIZONTAL);
        trickCard.setGravity(Gravity.CENTER_VERTICAL);
        trickCard.setPadding(dp(12), dp(12), dp(12), dp(12));
        trickCard.setBackground(roundRect(Color.rgb(20, 31, 25), 16));
        TrickIconView trickIcon = new TrickIconView(this);
        trickCard.addView(trickIcon, new LinearLayout.LayoutParams(dp(92), dp(108)));
        TextView trickInfo = text(
                "MANOBRA ATIVA  •  FLIP FLAT\nGiro + eixo/plano + finalização + controle\nToque para ver regras e catálogo",
                13, Color.WHITE, true);
        trickInfo.setPadding(dp(10), 0, 0, 0);
        trickCard.addView(trickInfo, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        trickCard.setOnClickListener(v -> showCatalogDialog());
        root.addView(trickCard, lpMatch(gap));

        TextView warning = text(
                "TESTE COM SEGURANÇA\nUse cama/sofá ou área macia e livre. Comece baixo. Não teste perto de pessoas, animais ou objetos frágeis.",
                12, Color.rgb(235, 235, 235), false);
        warning.setPadding(dp(14), dp(12), dp(14), dp(12));
        warning.setBackground(roundRect(Color.rgb(37, 38, 44), 14));
        root.addView(warning, lpMatch(gap));

        sensorText = text("", 11, Color.LTGRAY, false);
        sensorText.setPadding(dp(2), dp(4), 0, dp(10));
        root.addView(sensorText);

        statusText = text("PRONTO", 19, Color.WHITE, true);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusText.setBackground(roundRect(Color.rgb(28, 29, 34), 16));
        root.addView(statusText, lpMatch(gap));

        LinearLayout liveRow = new LinearLayout(this);
        liveRow.setOrientation(LinearLayout.HORIZONTAL);
        liveRow.setWeightSum(3f);
        root.addView(liveRow, lpMatch(gap));

        gyroText = metric("GIRO\n0 °/s");
        accelText = metric("ACEL.\n1.00 g");
        headingText = metric("NORTE\n—");
        liveRow.addView(gyroText, weighted());
        liveRow.addView(accelText, weightedWithLeftMargin(dp(6)));
        liveRow.addView(headingText, weightedWithLeftMargin(dp(6)));

        lastResultText = text(
                "ÚLTIMO RESULTADO\nFaça uma tentativa para ver grade, estilo e sinais principais.",
                14, Color.rgb(225, 229, 236), true);
        lastResultText.setPadding(dp(14), dp(12), dp(14), dp(12));
        lastResultText.setBackground(roundRect(Color.rgb(22, 24, 29), 15));
        root.addView(lastResultText, lpMatch(gap));

        playButton = new Button(this);
        playButton.setText("▶  PLAY / INICIAR SESSÃO");
        playButton.setTextSize(16);
        playButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        playButton.setTextColor(Color.rgb(10, 20, 13));
        playButton.setAllCaps(false);
        playButton.setBackground(roundRect(Color.rgb(125, 255, 169), 18));
        playButton.setPadding(dp(12), dp(15), dp(12), dp(15));
        playButton.setOnClickListener(v -> toggleMonitoring());
        root.addView(playButton, lpMatch(gap));

        LinearLayout sessionTools = new LinearLayout(this);
        sessionTools.setOrientation(LinearLayout.HORIZONTAL);
        sessionTools.setWeightSum(2f);
        root.addView(sessionTools, lpMatch(gap));

        syncButton = smallButton("🔊  SYNC VÍDEO");
        syncButton.setOnClickListener(v -> runVideoSync());
        sessionTools.addView(syncButton, weighted());

        sessionCountText = text("0 tentativas", 12, Color.rgb(190, 194, 204), true);
        sessionCountText.setGravity(Gravity.CENTER);
        sessionCountText.setPadding(dp(6), dp(13), dp(6), dp(13));
        sessionCountText.setBackground(roundRect(Color.rgb(35, 37, 44), 14));
        sessionTools.addView(sessionCountText, weightedWithLeftMargin(dp(8)));

        TextView explainer = text(
                "A V0.3 usa o maior bloco contínuo de giro para avaliar a manobra e ignora movimentos comuns. Toque na tentativa para REPLAY + DADOS. " +
                        "Tempo de voo/altura, finalização e detecção de queda ainda são marcados como experimentais até a calibração com vídeo.",
                12, Color.rgb(188, 190, 198), false);
        explainer.setPadding(dp(4), dp(2), dp(4), dp(12));
        root.addView(explainer);

        TextView section = text("TENTATIVAS  •  toque para abrir", 14,
                Color.rgb(146, 255, 186), true);
        section.setLetterSpacing(0.04f);
        root.addView(section);

        attemptsContainer = new LinearLayout(this);
        attemptsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(attemptsContainer, lpMatch(gap));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2f);
        root.addView(actionRow, lpMatch(0));

        exportButton = smallButton("EXPORTAR CALIBRAÇÃO CSV");
        exportButton.setOnClickListener(v -> exportCsv());
        actionRow.addView(exportButton, weighted());

        clearButton = smallButton("ZERAR");
        clearButton.setOnClickListener(v -> clearSession());
        actionRow.addView(clearButton, weightedWithLeftMargin(dp(8)));

        TextView foot = text(
                "V0.3 = Product Alpha. FLIP FLAT é a única manobra oficial; novas manobras nascem de propostas ligadas a telemetria real.",
                10, Color.rgb(132, 134, 143), false);
        foot.setPadding(dp(2), dp(16), dp(2), 0);
        root.addView(foot);

        setContentView(scroll);
    }

    private TextView metric(String value) {
        TextView t = text(value, 14, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(12), dp(6), dp(12));
        t.setBackground(roundRect(Color.rgb(30, 31, 37), 14));
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(roundRect(Color.rgb(48, 50, 58), 14));
        return b;
    }

    private void toggleMonitoring() {
        if (monitoring) stopMonitoring(); else startMonitoring();
    }

    private void startMonitoring() {
        if (accelerometer == null || gyroscope == null) return;
        monitoring = true;
        attemptActive = false;
        currentAttempt = null;
        lastGyroTimestampNs = 0L;
        sessionStartNs = SystemClock.elapsedRealtimeNanos();
        preBuffer.clear();
        logEvent("session_start", sessionStartNs, 0, "v0.3-product-alpha");

        sensorManager.registerListener(this, accelerometer, SENSOR_PERIOD_US);
        sensorManager.registerListener(this, gyroscope, SENSOR_PERIOD_US);
        if (rotationVector != null) sensorManager.registerListener(this, rotationVector, SENSOR_PERIOD_US);
        if (gameRotationVector != null) sensorManager.registerListener(this, gameRotationVector, SENSOR_PERIOD_US);
        if (magnetometer != null) sensorManager.registerListener(this, magnetometer, SENSOR_PERIOD_US);

        playButton.setText("■  PARAR SESSÃO");
        playButton.setBackground(roundRect(Color.rgb(255, 199, 102), 18));
        statusText.setText("ARMADO • faça um Flip Flat");
    }

    private void stopMonitoring() {
        if (attemptActive) finishAttempt(lastGyroTimestampNs, "sessão encerrada");
        if (sessionStartNs != 0L) logEvent("session_stop", SystemClock.elapsedRealtimeNanos(), 0, "manual");
        monitoring = false;
        attemptActive = false;
        currentAttempt = null;
        sensorManager.unregisterListener(this);
        playButton.setText("▶  PLAY / INICIAR SESSÃO");
        playButton.setBackground(roundRect(Color.rgb(125, 255, 169), 18));
        statusText.setText("PAUSADO");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (monitoring) stopMonitoring();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!monitoring) return;

        logRawSensorEvent(event);

        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            ax = event.values[0];
            ay = event.values[1];
            az = event.values[2];
            accelMagnitude = hypot3(ax, ay, az);
            accelText.setText(String.format(Locale.US, "ACEL.\n%.2f g", accelMagnitude / G));
            return;
        }

        if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            mx = event.values[0];
            my = event.values[1];
            mz = event.values[2];
            magneticMagnitude = hypot3(mx, my, mz);
            magAccuracy = event.accuracy;
            return;
        }

        if (type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(latestRotationMatrix, event.values);
            hasRotationMatrix = true;
            rotAccuracy = event.accuracy;
            float[] orientation = new float[3];
            SensorManager.getOrientation(latestRotationMatrix, orientation);
            headingDeg = normalize360((float) Math.toDegrees(orientation[0]));
            headingText.setText(String.format(Locale.US, "NORTE\n%03.0f°", headingDeg));
            return;
        }

        if (type == Sensor.TYPE_GAME_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(latestGameRotationMatrix, event.values);
            hasGameRotationMatrix = true;
            return;
        }

        if (type == Sensor.TYPE_GYROSCOPE) {
            handleGyroscope(event);
        }
    }

    private void handleGyroscope(SensorEvent event) {
        float gx = event.values[0];
        float gy = event.values[1];
        float gz = event.values[2];
        float mag = hypot3(gx, gy, gz);
        liveGyroDegS = (float) Math.toDegrees(mag);
        gyroText.setText(String.format(Locale.US, "GIRO\n%.0f °/s", liveGyroDegS));

        long ts = event.timestamp;
        Frame frame = buildFrame(ts, gx, gy, gz, mag);
        addPreBuffer(frame);

        if (!attemptActive && mag >= START_GYRO_RAD_S) beginAttempt(ts);
        if (!attemptActive || currentAttempt == null) {
            lastGyroTimestampNs = ts;
            return;
        }

        if (currentAttempt.frames.isEmpty() || currentAttempt.frames.get(currentAttempt.frames.size() - 1).timestampNs != ts) {
            currentAttempt.frames.add(frame.copy());
        }

        if (mag >= STOP_GYRO_RAD_S) lastAboveStopNs = ts;
        long durationNs = ts - attemptStartNs;
        statusText.setText(String.format(Locale.US,
                "CAPTURANDO #%d  •  %.0f°/s%s",
                attemptCount + 1,
                liveGyroDegS,
                isGyroSaturated(gx, gy, gz) ? "  MAX" : ""));

        boolean calmLongEnough = durationNs > MIN_ATTEMPT_NS && (ts - lastAboveStopNs) > STOP_HOLD_NS;
        boolean timedOut = durationNs > MAX_ATTEMPT_NS;
        if (calmLongEnough || timedOut) finishAttempt(ts, timedOut ? "timeout" : "estabilizou");

        lastGyroTimestampNs = ts;
    }

    private Frame buildFrame(long ts, float gx, float gy, float gz, float gyroMag) {
        Frame f = new Frame();
        f.timestampNs = ts;
        f.sessionMs = sessionStartNs == 0L ? 0.0 : (ts - sessionStartNs) / 1_000_000.0;
        f.gx = gx; f.gy = gy; f.gz = gz; f.gyroMag = gyroMag;
        f.ax = ax; f.ay = ay; f.az = az; f.accelMag = accelMagnitude;
        f.accelSaturated = isAccelSaturated(ax, ay, az);
        f.mx = mx; f.my = my; f.mz = mz; f.magMag = magneticMagnitude;
        f.headingDeg = headingDeg;
        f.gyroSaturated = isGyroSaturated(gx, gy, gz);
        f.rotAccuracy = rotAccuracy;
        f.magAccuracy = magAccuracy;
        float[] src = hasGameRotationMatrix ? latestGameRotationMatrix : latestRotationMatrix;
        f.hasOrientation = hasGameRotationMatrix || hasRotationMatrix;
        System.arraycopy(src, 0, f.rotationMatrix, 0, 9);
        return f;
    }

    private void addPreBuffer(Frame f) {
        preBuffer.addLast(f.copy());
        long minTs = f.timestampNs - PREBUFFER_NS;
        while (!preBuffer.isEmpty() && preBuffer.peekFirst().timestampNs < minTs) preBuffer.removeFirst();
    }

    private void beginAttempt(long ts) {
        attemptActive = true;
        attemptStartNs = ts;
        lastAboveStopNs = ts;
        currentAttempt = new Attempt();
        candidateCount++;
        currentAttempt.candidateId = candidateCount;
        currentAttempt.index = attemptCount + 1;
        currentAttempt.startTimestampNs = ts;
        currentAttempt.startSessionMs = sessionMs(ts);
        for (Frame f : preBuffer) currentAttempt.frames.add(f.copy());
        logEvent("candidate_start", ts, 0, "candidate=" + currentAttempt.candidateId + "; gyro_trigger");
        statusText.setText("CAPTURANDO #" + currentAttempt.index);
    }

    private void finishAttempt(long ts, String closeReason) {
        if (!attemptActive || currentAttempt == null) return;
        attemptActive = false;
        currentAttempt.endTimestampNs = ts;
        currentAttempt.endSessionMs = sessionMs(ts);
        currentAttempt.closeReason = closeReason;
        analyzeAttempt(currentAttempt);

        Attempt saved = currentAttempt;
        currentAttempt = null;

        if (!saved.validMotion) {
            discardedCandidates.add(saved);
            logEvent("candidate_discarded", ts, 0, String.format(Locale.US,
                    "candidate=%d; main_turns=%.2f; peak=%.0fdeg/s",
                    saved.candidateId, saved.spinWindowTurnsLowerBound, saved.peakGyroDegS));
            statusText.setText("MOVIMENTO IGNORADO • não foi uma tentativa válida");
            return;
        }

        saved.index = attemptCount + 1;
        attempts.add(saved);
        attemptCount++;
        logEvent("attempt_end", ts, saved.index, closeReason);
        renderAttempts();
        renderLastResult(saved);
        statusText.setText(String.format(Locale.US, "#%d SALVO • %s • GRADE %s",
                saved.index, saved.trickName, saved.overallGrade));
        vibrateCapture();
    }

    private void analyzeAttempt(Attempt a) {
        if (a.frames.size() < 2) return;

        double totalPath = 0;
        double accelSatMs = 0;
        double lowGMs = 0;
        float minAccel = Float.MAX_VALUE;
        float peakAccel = 0;
        ArrayList<Double> gyroIntervalsMs = new ArrayList<>();

        Frame prev = null;
        for (Frame f : a.frames) {
            if (f.timestampNs < a.startTimestampNs) { prev = f; continue; }
            if (prev == null) { prev = f; continue; }
            double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - prev.timestampNs) / 1_000_000_000.0));
            double dtMs = dt * 1000.0;
            if (dt <= 0) { prev = f; continue; }
            gyroIntervalsMs.add(dtMs);
            minAccel = Math.min(minAccel, f.accelMag);
            peakAccel = Math.max(peakAccel, f.accelMag);
            totalPath += f.gyroMag * dt;
            if (f.accelSaturated) accelSatMs += dtMs;
            if (f.accelMag < LOW_G_THRESHOLD) lowGMs += dtMs;
            prev = f;
        }

        ArrayList<SpinSegment> segments = buildSpinSegments(a);
        SpinSegment main = null;
        for (SpinSegment seg : segments) {
            if (main == null || seg.pathRad > main.pathRad) main = seg;
        }
        if (main == null) main = new SpinSegment();

        double axisSum = main.absX + main.absY + main.absZ;
        String dominant = "X";
        double dominantVal = main.absX;
        if (main.absY > dominantVal) { dominant = "Y"; dominantVal = main.absY; }
        if (main.absZ > dominantVal) { dominant = "Z"; dominantVal = main.absZ; }
        double purity = axisSum > 0 ? dominantVal / axisSum : 0;

        a.durationMs = (a.endTimestampNs - a.startTimestampNs) / 1_000_000.0;
        a.totalTurnsLowerBound = totalPath / (Math.PI * 2.0);
        a.spinWindowTurnsLowerBound = main.pathRad / (Math.PI * 2.0);
        a.spinRateLowerBoundRps = main.peakGyro / (Math.PI * 2.0);
        a.saturationOnlyTurnsFloor = (main.satMs / 1000.0) * (getGyroMaxRange() * SATURATION_FRACTION) / (Math.PI * 2.0);
        a.orientationPathTurnsEstimate = main.orientationPath / (Math.PI * 2.0);
        a.magVectorPathTurnsIndicator = main.magVectorPath / (Math.PI * 2.0);
        a.highSpinMs = main.highSpinMs;
        a.mainSpinDurationMs = main.startNs == 0 || main.endNs == 0 ? 0 : (main.endNs - main.startNs) / 1_000_000.0;
        a.saturationMs = main.satMs;
        a.saturationPctOfHighSpin = main.highSpinMs > 0 ? (main.satMs / main.highSpinMs) * 100.0 : 0;
        a.saturated = main.satMs >= 8.0 || main.peakGyro >= getGyroMaxRange() * SATURATION_FRACTION;
        a.accelSaturated = accelSatMs >= 4.0;
        a.accelSaturationMs = accelSatMs;
        a.peakGyroDegS = Math.toDegrees(main.peakGyro);
        a.minAccelG = minAccel == Float.MAX_VALUE ? 0 : minAccel / G;
        a.peakAccelG = peakAccel / G;
        a.lowGMs = lowGMs;
        a.lowGCandidate = lowGMs >= 20.0;
        a.dominantAxis = dominant;
        a.axisPurityPct = purity * 100.0;
        a.highSpinStartMs = main.startNs == 0 ? Double.NaN : sessionMs(main.startNs);
        a.highSpinEndMs = main.endNs == 0 ? Double.NaN : sessionMs(main.endNs);
        a.catchCandidateMs = main.endNs == 0 ? Double.NaN : sessionMs(main.endNs);
        a.headingStartDeg = headingAtOrBefore(a, a.startTimestampNs);
        a.headingEndDeg = headingAtOrBefore(a, a.endTimestampNs);
        a.sampleCount = a.frames.size();

        if (!gyroIntervalsMs.isEmpty()) {
            java.util.Collections.sort(gyroIntervalsMs);
            a.sampleDtMedianMs = percentile(gyroIntervalsMs, 0.50);
            a.sampleDtP95Ms = percentile(gyroIntervalsMs, 0.95);
            a.sampleDtMaxMs = gyroIntervalsMs.get(gyroIntervalsMs.size() - 1);
        }

        analyzeFinishAndLanding(a, main);

        // A trick must be more than ordinary hand movement. This rule intentionally describes a minimum
        // viable Flip Flat, not an elite score. Rejected candidates remain in the calibration export.
        a.validMotion = a.spinWindowTurnsLowerBound >= CONFIRM_MAIN_TURNS
                && main.peakGyro >= CONFIRM_PEAK_RAD_S
                && a.mainSpinDurationMs >= 180.0;
        a.flipFlatRecognized = a.validMotion && "Y".equals(a.dominantAxis) && a.axisPurityPct >= 35.0;
        a.trickName = a.flipFlatRecognized ? "FLIP FLAT" : (a.validMotion ? "NÃO RECONHECIDA" : "MOVIMENTO");

        a.spinGrade = gradeSpin(a);
        a.axisGrade = gradeAxis(purity);
        a.finishGrade = gradeFinish(a);
        a.catchGrade = gradeControl(a);
        a.overallGrade = a.flipFlatRecognized ? overallGrade(a) : "—";
        a.styleLabel = styleLabel(a);

        if (a.mainSpinDurationMs >= 250 && a.mainSpinDurationMs <= 900 && a.axisPurityPct >= 65) {
            a.flightTimeCandidateMs = a.mainSpinDurationMs;
            double t = a.flightTimeCandidateMs / 1000.0;
            a.heightCandidateCm = (G * t * t / 8.0) * 100.0;
        }

        if (main.startNs != 0) logEvent("main_spin_start", main.startNs, 0,
                "candidate=" + a.candidateId + "; threshold=" + HIGH_SPIN_RAD_S);
        if (main.endNs != 0) logEvent("main_spin_end", main.endNs, 0,
                "candidate=" + a.candidateId);
        if (a.saturated) logEvent("gyro_saturation", main.startNs == 0 ? a.startTimestampNs : main.startNs,
                0, String.format(Locale.US, "candidate=%d; %.1fms; turns>%.3f; rps>%.3f",
                        a.candidateId, a.saturationMs, a.spinWindowTurnsLowerBound, a.spinRateLowerBoundRps));
        if (a.dropSuspected) logEvent("possible_drop", main.endNs == 0 ? a.endTimestampNs : main.endNs,
                0, "candidate=" + a.candidateId + "; post-chaos heuristic");
    }

    private ArrayList<SpinSegment> buildSpinSegments(Attempt a) {
        ArrayList<SpinSegment> result = new ArrayList<>();
        SpinSegment current = null;
        Frame previousHigh = null;
        for (Frame f : a.frames) {
            if (f.timestampNs < a.startTimestampNs || f.gyroMag < HIGH_SPIN_RAD_S) continue;
            if (current == null || previousHigh == null || f.timestampNs - previousHigh.timestampNs > MAIN_SPIN_GAP_NS) {
                current = new SpinSegment();
                current.startNs = f.timestampNs;
                result.add(current);
                previousHigh = null;
            }
            current.endNs = f.timestampNs;
            current.peakGyro = Math.max(current.peakGyro, f.gyroMag);
            if (previousHigh != null) {
                double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - previousHigh.timestampNs) / 1_000_000_000.0));
                double dtMs = dt * 1000.0;
                current.pathRad += f.gyroMag * dt;
                current.highSpinMs += dtMs;
                current.absX += Math.abs(f.gx) * dt;
                current.absY += Math.abs(f.gy) * dt;
                current.absZ += Math.abs(f.gz) * dt;
                if (f.gyroSaturated) current.satMs += dtMs;
                if (previousHigh.hasOrientation && f.hasOrientation)
                    current.orientationPath += rotationDeltaAngle(previousHigh.rotationMatrix, f.rotationMatrix);
                if (previousHigh.magMag > 5f && f.magMag > 5f)
                    current.magVectorPath += vectorDeltaAngle(previousHigh.mx, previousHigh.my, previousHigh.mz, f.mx, f.my, f.mz);
            }
            previousHigh = f;
        }
        return result;
    }

    private void analyzeFinishAndLanding(Attempt a, SpinSegment main) {
        if (main.startNs == 0 || main.endNs == 0) return;

        double[] preNormal = averageDeviceNormal(a, main.startNs - 350_000_000L, main.startNs - 80_000_000L);
        double[] postNormal = averageDeviceNormal(a, main.endNs + 100_000_000L, main.endNs + 700_000_000L);
        if (preNormal != null && postNormal != null) {
            double dot = clamp(preNormal[0] * postNormal[0] + preNormal[1] * postNormal[1] + preNormal[2] * postNormal[2], -1, 1);
            a.finishNormalDeltaDeg = Math.toDegrees(Math.acos(dot));
            a.sameFaceFinish = dot > 0;
        }

        long postEnd = Math.min(a.endTimestampNs, main.endNs + 700_000_000L);
        Frame prev = null;
        double path = 0;
        double maxG = 0;
        int impactCount = 0;
        long lastImpactNs = Long.MIN_VALUE / 4;
        for (Frame f : a.frames) {
            if (f.timestampNs < main.endNs || f.timestampNs > postEnd) continue;
            if (prev != null) {
                double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - prev.timestampNs) / 1_000_000_000.0));
                path += f.gyroMag * dt;
            }
            double g = f.accelMag / G;
            maxG = Math.max(maxG, g);
            if (g >= 4.0 && f.timestampNs - lastImpactNs > 70_000_000L) {
                impactCount++;
                lastImpactNs = f.timestampNs;
            }
            prev = f;
        }
        a.postSpinTurns700Ms = path / (Math.PI * 2.0);
        a.catchAccelG = maxG;
        a.secondaryImpactCount = impactCount;
        a.settleAfterMainMs = Math.max(0, (a.endTimestampNs - main.endNs) / 1_000_000.0);
        a.dropSuspected = impactCount >= 2 || (a.postSpinTurns700Ms >= 1.0 && a.settleAfterMainMs > 700);
    }

    private double[] averageDeviceNormal(Attempt a, long fromNs, long toNs) {
        double x = 0, y = 0, z = 0;
        int n = 0;
        for (Frame f : a.frames) {
            if (!f.hasOrientation || f.timestampNs < fromNs || f.timestampNs > toNs || f.gyroMag > 1.2f) continue;
            // Third column of the device->world rotation matrix is the screen-normal axis in world coordinates.
            x += f.rotationMatrix[2]; y += f.rotationMatrix[5]; z += f.rotationMatrix[8]; n++;
        }
        if (n < 4) return null;
        double norm = Math.sqrt(x*x + y*y + z*z);
        if (norm < 1e-6) return null;
        return new double[]{x/norm, y/norm, z/norm};
    }

    private double clamp(double value, double lo, double hi) {
        return Math.max(lo, Math.min(hi, value));
    }

    private String gradeSpin(Attempt a) {
        double turns = a.spinWindowTurnsLowerBound;
        double rps = a.spinRateLowerBoundRps;
        if (turns >= 3.0 && (a.saturated || rps >= 5.8)) return "S";
        if (turns >= 2.2 && rps >= 4.5) return "A";
        if (turns >= 1.3 && rps >= 3.2) return "B";
        return "C";
    }

    private String gradeAxis(double purity) {
        if (purity >= 0.92) return "S";
        if (purity >= 0.80) return "A";
        if (purity >= 0.65) return "B";
        return "C";
    }

    private String gradeFinish(Attempt a) {
        if (Double.isNaN(a.finishNormalDeltaDeg)) return "?";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 20) return "S";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 45) return "A";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 75) return "B";
        return "C";
    }

    private String gradeControl(Attempt a) {
        if (a.dropSuspected || "CAIU".equals(a.userRating)) return "F";
        if (a.postSpinTurns700Ms < 0.25 && a.settleAfterMainMs < 1000) return "S";
        if (a.postSpinTurns700Ms < 0.45 && a.settleAfterMainMs < 1400) return "A";
        if (a.postSpinTurns700Ms < 0.80 && a.settleAfterMainMs < 2100) return "B";
        return "C";
    }

    private String overallGrade(Attempt a) {
        if (a.dropSuspected || "CAIU".equals(a.userRating)) return "F";
        int spinV = gradeValue(a.spinGrade);
        int axisV = gradeValue(a.axisGrade);
        int finishV = "?".equals(a.finishGrade) ? 2 : gradeValue(a.finishGrade);
        int controlV = "F".equals(a.catchGrade) ? 1 : gradeValue(a.catchGrade);
        double score = spinV * 0.40 + axisV * 0.40 + finishV * 0.10 + controlV * 0.10;
        if (score >= 3.60) return "S";
        if (score >= 2.80) return "A";
        if (score >= 2.00) return "B";
        return "C";
    }

    private int gradeValue(String grade) {
        if ("S".equals(grade)) return 4;
        if ("A".equals(grade)) return 3;
        if ("B".equals(grade)) return 2;
        return 1;
    }

    private String styleLabel(Attempt a) {
        if (!a.validMotion) return "MOVIMENTO";
        if (!a.flipFlatRecognized) return "NOVA MANOBRA?";
        if (a.dropSuspected || "CAIU".equals(a.userRating)) return "FALHA / QUEDA";
        if (a.axisPurityPct >= 92 && a.spinGrade.equals("S")) return "AXIS LOCK";
        if (a.saturated && a.axisPurityPct >= 80) return "MAX SPIN";
        if (a.axisPurityPct >= 82) return "CLEAN FLAT";
        if (a.axisPurityPct < 58) return "WILD FLAT";
        if ("S".equals(a.catchGrade)) return "CLEAN CATCH";
        return "SOLID FLAT";
    }

    private void renderLastResult(Attempt a) {
        if (!a.flipFlatRecognized) {
            lastResultText.setText(String.format(Locale.US,
                    "MANOBRA NÃO RECONHECIDA\nGIROS %s  |  %s %.0f%%  |  %s\nToque no card e use PROPOR NOVA MANOBRA para dar nome e descrever o padrão.",
                    formatTurnsForUser(a), a.dominantAxis, a.axisPurityPct, formatSpinRateForUser(a)));
            lastResultText.setBackground(roundRect(Color.rgb(67, 55, 31), 15));
            return;
        }
        String finish = Double.isNaN(a.finishNormalDeltaDeg) ? "?" :
                (a.sameFaceFinish ? String.format(Locale.US, "MESMA FACE %.0f°", a.finishNormalDeltaDeg) :
                        String.format(Locale.US, "FACE OPOSTA %.0f°", a.finishNormalDeltaDeg));
        lastResultText.setText(String.format(Locale.US,
                "%s  •  GRADE %s  •  %s\nGIROS %s  |  SPIN %s  |  EIXO %s (%s %.0f%%)\nFINAL %s %s  |  CONTROLE %s%s",
                a.trickName, a.overallGrade, a.styleLabel,
                formatTurnsForUser(a), a.spinGrade, a.axisGrade, a.dominantAxis, a.axisPurityPct,
                a.finishGrade, finish, a.catchGrade,
                a.dropSuspected ? "  •  QUEDA?" : (a.saturated ? "  •  SENSOR MAX" : "")));
        lastResultText.setBackground(roundRect(
                a.overallGrade.equals("S") ? Color.rgb(40, 76, 57) :
                        a.overallGrade.equals("F") ? Color.rgb(91, 38, 42) : Color.rgb(22, 24, 29), 15));
    }

    private void renderAttempts() {
        attemptsContainer.removeAllViews();
        sessionCountText.setText(attempts.size() + (attempts.size() == 1 ? " tentativa" : " tentativas"));
        exportButton.setEnabled(!attempts.isEmpty() || !discardedCandidates.isEmpty() || !trickProposals.isEmpty());

        if (attempts.isEmpty()) {
            TextView empty = text("Nenhuma tentativa ainda.\nPLAY → faça um arremesso → toque no card para Replay + Dados.",
                    13, Color.rgb(210, 213, 221), false);
            empty.setPadding(dp(14), dp(12), dp(14), dp(12));
            empty.setBackground(roundRect(Color.rgb(24, 25, 30), 14));
            attemptsContainer.addView(empty, lpMatch(dp(8)));
            return;
        }

        for (int i = attempts.size() - 1; i >= 0; i--) {
            Attempt a = attempts.get(i);
            TextView card = text("", 13, Color.WHITE, false);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(roundRect(Color.rgb(24, 25, 30), 14));
            card.setText(buildAttemptCardText(a));
            card.setOnClickListener(v -> showAttemptDetail(a));
            attemptsContainer.addView(card, lpMatch(dp(8)));
        }
    }

    private String buildAttemptCardText(Attempt a) {
        String rating = a.userRating == null ? "—" : a.userRating;
        String title = a.flipFlatRecognized ? a.trickName + "  •  GRADE " + a.overallGrade : "NÃO RECONHECIDA  •  PROPOR NOME";
        return String.format(Locale.US,
                "#%02d   %s\nGIROS %s   |   SPIN %s   EIXO %s   FINAL %s   CTRL %s\n%s %.0f%%   |   %s   |   sua nota: %s",
                a.index, title, formatTurnsForUser(a), a.spinGrade, a.axisGrade, a.finishGrade, a.catchGrade,
                a.dominantAxis, a.axisPurityPct, formatSpinRateForUser(a), rating);
    }

    private String formatTurnsForUser(Attempt a) {
        if (a.saturated) return String.format(Locale.US, "> %.2f", a.spinWindowTurnsLowerBound);
        return String.format(Locale.US, "~ %.2f", a.spinWindowTurnsLowerBound);
    }

    private String formatSpinRateForUser(Attempt a) {
        if (a.saturated) return String.format(Locale.US, "> %.1f giros/s", a.spinRateLowerBoundRps);
        return String.format(Locale.US, "~ %.1f giros/s", a.spinRateLowerBoundRps);
    }

    private void showAttemptDetail(Attempt a) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(26));
        scroll.addView(root);

        TextView title = text(String.format(Locale.US, "#%02d  •  %s  •  GRADE %s", a.index, a.trickName, a.overallGrade),
                25, Color.WHITE, true);
        root.addView(title);
        TextView label = text(a.styleLabel + "  •  classificação em evolução", 14,
                Color.rgb(146, 255, 186), true);
        label.setPadding(0, 0, 0, dp(12));
        root.addView(label);

        TextView replayHeader = text("REPLAY SENSORIAL", 13, Color.rgb(190, 196, 207), true);
        root.addView(replayHeader);
        ReplayView replay = new ReplayView(this, a);
        replay.setBackground(roundRect(Color.rgb(20, 22, 27), 14));
        root.addView(replay, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        Button replayButton = smallButton("▶  REPLAY EM SLOW MOTION");
        replayButton.setOnClickListener(v -> replay.startReplay());
        root.addView(replayButton, lpMatch(dp(10)));

        TimelineView timeline = new TimelineView(this, a);
        timeline.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(timeline, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)));

        TextView note = text(
                "Replay = orientação estimada pelos sensores. O bloco verde é o giro principal usado na pontuação. Voo/altura e queda continuam como hipóteses calibráveis.",
                11, Color.rgb(157, 161, 171), false);
        note.setPadding(dp(2), dp(6), dp(2), dp(12));
        root.addView(note);

        TextView ratingTitle = text("COMO VOCÊ AVALIA ESSA EXECUÇÃO?", 12, Color.WHITE, true);
        root.addView(ratingTitle);
        LinearLayout ratings = new LinearLayout(this);
        ratings.setOrientation(LinearLayout.HORIZONTAL);
        ratings.setWeightSum(4f);
        root.addView(ratings, lpMatch(dp(12)));
        String[] names = {"BOA", "MÉDIA", "RUIM", "CAIU"};
        for (String r : names) {
            Button b = smallButton(r);
            b.setOnClickListener(v -> {
                a.userRating = r;
                a.catchGrade = gradeControl(a);
                a.overallGrade = a.flipFlatRecognized ? overallGrade(a) : "—";
                a.styleLabel = styleLabel(a);
                renderAttempts();
                renderLastResult(a);
                Toast.makeText(this, "Avaliação salva: " + r, Toast.LENGTH_SHORT).show();
            });
            ratings.addView(b, ratings.getChildCount() == 0 ? weighted() : weightedWithLeftMargin(dp(4)));
        }

        Button propose = smallButton(a.proposedTrickName == null ? "+  PROPOR NOVA MANOBRA" : "✓  PROPOSTA: " + a.proposedTrickName);
        propose.setOnClickListener(v -> showProposalDialog(a));
        root.addView(propose, lpMatch(dp(12)));

        TextView stats = text(buildTechnicalStats(a), 12, Color.rgb(225, 229, 236), false);
        stats.setTypeface(Typeface.MONOSPACE);
        stats.setPadding(dp(12), dp(12), dp(12), dp(12));
        stats.setBackground(roundRect(Color.rgb(24, 25, 30), 12));
        root.addView(stats, lpMatch(dp(12)));

        TextView gyroH = text("GIROSCÓPIO X / Y / Z", 12, Color.rgb(190, 196, 207), true);
        root.addView(gyroH);
        SensorChartView gyroChart = new SensorChartView(this, a, SensorChartView.MODE_GYRO);
        gyroChart.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(gyroChart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));

        TextView accelH = text("ACELERAÇÃO TOTAL", 12, Color.rgb(190, 196, 207), true);
        accelH.setPadding(0, dp(12), 0, 0);
        root.addView(accelH);
        SensorChartView accelChart = new SensorChartView(this, a, SensorChartView.MODE_ACCEL);
        accelChart.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(accelChart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(180)));

        Button close = smallButton("FECHAR");
        close.setOnClickListener(v -> dialog.dismiss());
        root.addView(close, lpMatch(0));

        dialog.setContentView(scroll);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
        if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        replay.startReplay();
    }

    private String buildTechnicalStats(Attempt a) {
        String air = Double.isNaN(a.flightTimeCandidateMs) ? "—" :
                String.format(Locale.US, "~%.0f ms / ~%.0f cm*", a.flightTimeCandidateMs, a.heightCandidateCm);
        String finish = Double.isNaN(a.finishNormalDeltaDeg) ? "—" :
                String.format(Locale.US, "%.1f deg / %s", a.finishNormalDeltaDeg, a.sameFaceFinish ? "same face" : "opposite face");
        return String.format(Locale.US,
                "PRODUCT + CALIBRATION\n" +
                "trick / recognized %s / %s\n" +
                "overall grade      %s\n" +
                "spin/axis/final/ctrl %s / %s / %s / %s\n" +
                "dominant axis      %s (%.1f%% purity)\n" +
                "peak gyro          %.1f deg/s%s\n" +
                "spin rate          %s\n" +
                "main spin duration %.1f ms\n" +
                "turn estimate      %s giros\n" +
                "gyro saturation    %s  %.1f ms (%.1f%% main spin)\n" +
                "orientation path   %.3f turn-eq\n" +
                "mag vector path    %.3f turn-eq (cross-check)\n" +
                "finish return      %s\n" +
                "post-spin turns    %.3f / 700ms\n" +
                "settle after spin  %.1f ms\n" +
                "secondary impacts  %d  | possible drop %s\n" +
                "air/height cand.   %s\n" +
                "accel min / peak   %.3fg / %.3fg%s\n" +
                "sample dt med/p95  %.2f / %.2f ms\n" +
                "sample dt max      %.2f ms\n" +
                "user rating        %s\n" +
                "*height assumes catch near launch height; calibrate with video",
                a.trickName, a.flipFlatRecognized ? "YES" : "NO", a.overallGrade,
                a.spinGrade, a.axisGrade, a.finishGrade, a.catchGrade,
                a.dominantAxis, a.axisPurityPct, a.peakGyroDegS, a.saturated ? "+" : "",
                formatSpinRateForUser(a), a.mainSpinDurationMs, formatTurnsForUser(a),
                a.saturated ? "YES" : "NO", a.saturationMs, a.saturationPctOfHighSpin,
                a.orientationPathTurnsEstimate, a.magVectorPathTurnsIndicator, finish,
                a.postSpinTurns700Ms, a.settleAfterMainMs, a.secondaryImpactCount,
                a.dropSuspected ? "YES" : "NO", air,
                a.minAccelG, a.peakAccelG, a.accelSaturated ? "  ACCEL MAX" : "",
                a.sampleDtMedianMs, a.sampleDtP95Ms, a.sampleDtMaxMs,
                a.userRating == null ? "—" : a.userRating);
    }

    private void showCatalogDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        scroll.addView(root);

        root.addView(text("CATÁLOGO DE MANOBRAS", 27, Color.WHITE, true));
        TextView intro = text("A modalidade começa pequena. Uma regra oficial bem entendida vale mais do que dezenas de manobras inventadas.",
                12, Color.rgb(190, 196, 207), false);
        intro.setPadding(0, dp(4), 0, dp(14)); root.addView(intro);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12)); card.setBackground(roundRect(Color.rgb(20, 31, 25), 16));
        TrickIconView icon = new TrickIconView(this);
        card.addView(icon, new LinearLayout.LayoutParams(dp(110), dp(130)));
        TextView rules = text(
                "FLIP FLAT  •  OFICIAL\n\n" +
                "• GIRO: quantidade + velocidade; saturou = >N, nunca número inventado\n" +
                "• EIXO/PLANO: pureza do eixo pontua; horizontalidade física será fixada com vídeo\n" +
                "• FINALIZAÇÃO: voltar à mesma face/orientação é desempate\n" +
                "• CONTROLE: estabilizar limpo depois da captura\n" +
                "• QUEDA: tentativa falha (detecção ainda em calibração)\n" +
                "• VOO/ALTURA: medido como candidato até validação em vídeo",
                12, Color.WHITE, false);
        rules.setPadding(dp(10), 0, 0, 0);
        card.addView(rules, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(card, lpMatch(dp(12)));

        TextView community = text("LAB DA COMUNIDADE", 13, Color.rgb(146, 255, 186), true);
        root.addView(community);
        root.addView(text("Uma execução não reconhecida pode virar proposta: nome + descrição + critérios sugeridos + telemetria da tentativa. Nesta alpha a proposta fica na sessão/CSV; depois pode ir para moderação comunitária.",
                12, Color.rgb(205, 209, 217), false), lpMatch(dp(10)));
        if (trickProposals.isEmpty()) {
            root.addView(text("Nenhuma proposta nesta sessão.", 12, Color.rgb(150, 155, 165), false), lpMatch(dp(10)));
        } else {
            for (TrickProposal tp : trickProposals) {
                TextView p = text("• " + tp.name + "  (#" + tp.sourceAttempt + ")\n" + tp.description,
                        12, Color.WHITE, false);
                p.setPadding(dp(10), dp(9), dp(10), dp(9)); p.setBackground(roundRect(Color.rgb(26, 28, 34), 12));
                root.addView(p, lpMatch(dp(7)));
            }
        }
        Button close = smallButton("FECHAR"); close.setOnClickListener(v -> dialog.dismiss()); root.addView(close, lpMatch(0));
        dialog.setContentView(scroll);
        Window w = dialog.getWindow();
        if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); }
        dialog.show(); if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void showProposalDialog(Attempt a) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(18), dp(18), dp(20));
        root.setBackgroundColor(Color.rgb(15, 16, 20));
        root.addView(text("PROPOR NOVA MANOBRA", 23, Color.WHITE, true));
        root.addView(text("A telemetria da tentativa #" + a.index + " será ligada à proposta. Descreva só o que você acha essencial; a regra pode amadurecer depois.",
                12, Color.rgb(190, 196, 207), false), lpMatch(dp(10)));

        EditText name = new EditText(this); name.setHint("Nome da manobra"); name.setTextColor(Color.WHITE); name.setHintTextColor(Color.GRAY);
        name.setSingleLine(true); name.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); name.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickName != null) name.setText(a.proposedTrickName); root.addView(name, lpMatch(dp(8)));
        EditText desc = new EditText(this); desc.setHint("Como é feita / o que a diferencia?"); desc.setTextColor(Color.WHITE); desc.setHintTextColor(Color.GRAY);
        desc.setMinLines(3); desc.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); desc.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickDescription != null) desc.setText(a.proposedTrickDescription); root.addView(desc, lpMatch(dp(8)));
        EditText criteria = new EditText(this); criteria.setHint("Critérios sugeridos (ex.: eixo X, voltar tela para cima, 2+ giros)"); criteria.setTextColor(Color.WHITE); criteria.setHintTextColor(Color.GRAY);
        criteria.setMinLines(2); criteria.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); criteria.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickCriteria != null) criteria.setText(a.proposedTrickCriteria); root.addView(criteria, lpMatch(dp(10)));
        Button save = smallButton("SALVAR PROPOSTA");
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { Toast.makeText(this, "Dê um nome à manobra.", Toast.LENGTH_SHORT).show(); return; }
            a.proposedTrickName = n; a.proposedTrickDescription = desc.getText().toString().trim(); a.proposedTrickCriteria = criteria.getText().toString().trim();
            for (int i = trickProposals.size() - 1; i >= 0; i--) if (trickProposals.get(i).sourceAttempt == a.index) trickProposals.remove(i);
            TrickProposal tp = new TrickProposal(); tp.sourceAttempt = a.index; tp.name = a.proposedTrickName; tp.description = a.proposedTrickDescription; tp.criteria = a.proposedTrickCriteria;
            trickProposals.add(tp); renderAttempts(); Toast.makeText(this, "Proposta salva para exportação.", Toast.LENGTH_SHORT).show(); dialog.dismiss();
        });
        root.addView(save, lpMatch(dp(6)));
        Button cancel = smallButton("CANCELAR"); cancel.setOnClickListener(v -> dialog.dismiss()); root.addView(cancel, lpMatch(0));
        dialog.setContentView(root); Window w = dialog.getWindow(); if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show(); if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void runVideoSync() {
        if (!monitoring) {
            Toast.makeText(this, "Inicie a sessão antes do SYNC VÍDEO.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText("SYNC VÍDEO • 3…");
        scheduleSyncTone(0, 3, ToneGenerator.TONE_PROP_BEEP);
        scheduleSyncTone(700, 2, ToneGenerator.TONE_PROP_BEEP);
        scheduleSyncTone(1400, 1, ToneGenerator.TONE_PROP_BEEP);
        handler.postDelayed(() -> {
            long ts = SystemClock.elapsedRealtimeNanos();
            if (toneGenerator != null) toneGenerator.startTone(ToneGenerator.TONE_PROP_ACK, 300);
            logEvent("sync_beep_GO", ts, 0, "video_ground_truth");
            statusText.setText("SYNC GO • agora faça as tentativas");
        }, 2100);
    }

    private void scheduleSyncTone(long delayMs, int n, int tone) {
        handler.postDelayed(() -> {
            long ts = SystemClock.elapsedRealtimeNanos();
            if (toneGenerator != null) toneGenerator.startTone(tone, 140);
            logEvent("sync_beep_" + n, ts, 0, "video_ground_truth");
            statusText.setText("SYNC VÍDEO • " + n + "…");
        }, delayMs);
    }

    private void updateSensorStatus() {
        String gyro = sensorName(gyroscope);
        String acc = sensorName(accelerometer);
        String rot = sensorName(rotationVector);
        String game = sensorName(gameRotationVector);
        String mag = sensorName(magnetometer);
        sensorText.setText("Sensores\n" +
                "• Giroscópio: " + gyro + "\n" +
                "• Acelerômetro: " + acc + "\n" +
                "• Rotation Vector: " + rot + "\n" +
                "• Game Rotation Vector: " + game + "\n" +
                "• Magnetômetro / bússola: " + mag);
    }

    private String sensorName(Sensor s) {
        return s == null ? "AUSENTE" : s.getName();
    }

    private void clearSession() {
        if (attemptActive) return;
        attempts.clear();
        discardedCandidates.clear();
        trickProposals.clear();
        preBuffer.clear();
        rawEventLog.setLength(0);
        eventLog.setLength(0);
        rawEventCount = 0;
        rawLogTruncated = false;
        attemptCount = 0;
        candidateCount = 0;
        renderAttempts();
        lastResultText.setText("ÚLTIMO RESULTADO\nFaça um Flip Flat para ver giro, eixo, finalização e controle.");
        lastResultText.setBackground(roundRect(Color.rgb(22, 24, 29), 15));
        statusText.setText(monitoring ? "ARMADO • sessão zerada" : "PRONTO");
    }

    private void exportCsv() {
        if (attempts.isEmpty() && discardedCandidates.isEmpty() && trickProposals.isEmpty()) {
            Toast.makeText(this, "Ainda não há dados para exportar.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "flipflat-v021-calibration-" + stamp + ".csv");
        startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("Sem stream de saída");
            os.write(buildCsv().getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Calibração CSV exportada.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao exportar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String buildCsv() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Flip Flat Product Alpha V0.3\n");
        sb.append("# Purpose: product UX + calibration + trick-catalog growth\n");
        sb.append("# Main metrics use the strongest continuous high-spin segment; ordinary motion candidates are discarded from the product UI but kept below.\n");
        sb.append("# Saturated gyro values are lower bounds (>N), never false precision. Magnetometer/orientation remain calibration cross-checks.\n");
        sb.append("# Flight/height and drop detection are experimental until video ground-truth calibration.\n");
        sb.append("# raw_log_truncated,").append(rawLogTruncated).append("\n");
        appendSensorMeta(sb, "gyroscope", gyroscope);
        appendSensorMeta(sb, "accelerometer", accelerometer);
        appendSensorMeta(sb, "rotation_vector", rotationVector);
        appendSensorMeta(sb, "game_rotation_vector", gameRotationVector);
        appendSensorMeta(sb, "magnetometer", magnetometer);

        sb.append("\nSUMMARY\n");
        sb.append("attempt,trick_name,recognized,overall_grade,style_label,spin_grade,axis_grade,finish_grade,control_grade,user_rating,duration_ms,dominant_axis,axis_purity_pct,peak_gyro_deg_s,spin_rate_lower_bound_rps,main_spin_duration_ms,main_spin_turns_lower_bound,total_turns_lower_bound,gyro_saturated,saturation_ms,saturation_pct_main_spin,orientation_path_turns_estimate,mag_vector_path_turns_indicator,finish_normal_delta_deg,same_face_finish,post_spin_turns_700ms,settle_after_main_ms,secondary_impact_count,drop_suspected,flight_time_candidate_ms,height_candidate_cm,min_accel_g,peak_accel_g,accel_saturated,accel_saturation_ms,heading_start_deg,heading_end_deg,sample_count,sample_dt_median_ms,sample_dt_p95_ms,sample_dt_max_ms,proposed_trick_name,proposed_description,proposed_criteria,close_reason\n");
        for (Attempt a : attempts) {
            sb.append(String.format(Locale.US,
                    "%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%.3f,%s,%.4f,%.4f,%.6f,%.3f,%.6f,%.6f,%s,%.3f,%.3f,%.6f,%.6f,%.3f,%s,%.6f,%.3f,%d,%s,%.3f,%.3f,%.6f,%.6f,%s,%.3f,%.3f,%.3f,%d,%.4f,%.4f,%.4f,%s,%s,%s,%s\n",
                    a.index, csvFlat(a.trickName), a.flipFlatRecognized ? "true" : "false", a.overallGrade,
                    csvFlat(a.styleLabel), a.spinGrade, a.axisGrade, a.finishGrade, a.catchGrade,
                    a.userRating == null ? "" : a.userRating, a.durationMs, a.dominantAxis,
                    a.axisPurityPct, a.peakGyroDegS, a.spinRateLowerBoundRps, a.mainSpinDurationMs,
                    a.spinWindowTurnsLowerBound, a.totalTurnsLowerBound, a.saturated ? "true" : "false",
                    a.saturationMs, a.saturationPctOfHighSpin, a.orientationPathTurnsEstimate,
                    a.magVectorPathTurnsIndicator, a.finishNormalDeltaDeg, a.sameFaceFinish ? "true" : "false",
                    a.postSpinTurns700Ms, a.settleAfterMainMs, a.secondaryImpactCount,
                    a.dropSuspected ? "true" : "false", a.flightTimeCandidateMs, a.heightCandidateCm,
                    a.minAccelG, a.peakAccelG, a.accelSaturated ? "true" : "false", a.accelSaturationMs,
                    a.headingStartDeg, a.headingEndDeg, a.sampleCount, a.sampleDtMedianMs,
                    a.sampleDtP95Ms, a.sampleDtMaxMs,
                    csvFlat(a.proposedTrickName == null ? "" : a.proposedTrickName),
                    csvFlat(a.proposedTrickDescription == null ? "" : a.proposedTrickDescription),
                    csvFlat(a.proposedTrickCriteria == null ? "" : a.proposedTrickCriteria),
                    csvFlat(a.closeReason)));
        }

        sb.append("\nDISCARDED_CANDIDATES\n");
        sb.append("candidate_id,duration_ms,main_turns_lower_bound,peak_gyro_deg_s,dominant_axis,axis_purity_pct,main_spin_duration_ms,close_reason\n");
        for (Attempt a : discardedCandidates) {
            sb.append(String.format(Locale.US, "%d,%.3f,%.6f,%.3f,%s,%.3f,%.3f,%s\n",
                    a.candidateId, a.durationMs, a.spinWindowTurnsLowerBound, a.peakGyroDegS,
                    a.dominantAxis, a.axisPurityPct, a.mainSpinDurationMs, csvFlat(a.closeReason)));
        }

        sb.append("\nTRICK_PROPOSALS\n");
        sb.append("source_attempt,name,description,suggested_criteria\n");
        for (TrickProposal tp : trickProposals) {
            sb.append(tp.sourceAttempt).append(',').append(csvFlat(tp.name)).append(',')
                    .append(csvFlat(tp.description)).append(',').append(csvFlat(tp.criteria)).append('\n');
        }

        sb.append("\nATTEMPT_FRAMES\n");
        sb.append("attempt,session_ms,relative_to_trigger_ms,phase,gx_rad_s,gy_rad_s,gz_rad_s,gyro_mag_rad_s,gyro_saturated,ax_ms2,ay_ms2,az_ms2,accel_mag_ms2,accel_saturated,mx_uT,my_uT,mz_uT,mag_mag_uT,heading_deg,rot_accuracy,mag_accuracy,r00,r01,r02,r10,r11,r12,r20,r21,r22\n");
        for (Attempt a : attempts) {
            for (Frame f : a.frames) {
                String phase = phaseForFrame(a, f);
                double rel = (f.timestampNs - a.startTimestampNs) / 1_000_000.0;
                sb.append(String.format(Locale.US,
                        "%d,%.3f,%.3f,%s,%.7f,%.7f,%.7f,%.7f,%s,%.7f,%.7f,%.7f,%.7f,%s,%.7f,%.7f,%.7f,%.7f,%.3f,%d,%d,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f\n",
                        a.index, f.sessionMs, rel, phase,
                        f.gx, f.gy, f.gz, f.gyroMag, f.gyroSaturated ? "true" : "false",
                        f.ax, f.ay, f.az, f.accelMag, f.accelSaturated ? "true" : "false", f.mx, f.my, f.mz, f.magMag,
                        f.headingDeg, f.rotAccuracy, f.magAccuracy,
                        f.rotationMatrix[0], f.rotationMatrix[1], f.rotationMatrix[2],
                        f.rotationMatrix[3], f.rotationMatrix[4], f.rotationMatrix[5],
                        f.rotationMatrix[6], f.rotationMatrix[7], f.rotationMatrix[8]));
            }
        }

        sb.append("\nEVENT_MARKERS\n");
        sb.append("session_ms,event,attempt,detail\n");
        sb.append(eventLog);

        sb.append("\nRAW_SENSOR_EVENTS\n");
        sb.append("session_ms,sensor,accuracy,v0,v1,v2,v3,v4\n");
        sb.append(rawEventLog);
        return sb.toString();
    }

    private String phaseForFrame(Attempt a, Frame f) {
        if (f.timestampNs < a.startTimestampNs) return "PREBUFFER";
        if (!Double.isNaN(a.highSpinStartMs) && !Double.isNaN(a.highSpinEndMs)
                && f.sessionMs >= a.highSpinStartMs && f.sessionMs <= a.highSpinEndMs)
            return f.gyroSaturated ? "MAIN_SPIN_SAT" : "MAIN_SPIN";
        if (f.accelMag < LOW_G_THRESHOLD) return "LOW_G_CANDIDATE";
        if (!Double.isNaN(a.catchCandidateMs) && Math.abs(f.sessionMs - a.catchCandidateMs) < 35) return "CATCH_CANDIDATE";
        if (!Double.isNaN(a.highSpinEndMs) && f.sessionMs > a.highSpinEndMs) return "POST_SPIN";
        return "ACTIVE";
    }

    private void appendSensorMeta(StringBuilder sb, String label, Sensor s) {
        if (s == null) {
            sb.append("# sensor,").append(label).append(",ABSENT\n");
            return;
        }
        sb.append("# sensor,").append(label)
                .append(",name,").append(csvFlat(s.getName()))
                .append(",vendor,").append(csvFlat(s.getVendor()))
                .append(",version,").append(s.getVersion())
                .append(",max_range,").append(s.getMaximumRange())
                .append(",resolution,").append(s.getResolution())
                .append(",min_delay_us,").append(s.getMinDelay())
                .append("\n");
    }

    private void logRawSensorEvent(SensorEvent event) {
        if (rawEventCount >= MAX_RAW_EVENTS) {
            rawLogTruncated = true;
            return;
        }
        rawEventCount++;
        double t = sessionMs(event.timestamp);
        String name = sensorShortName(event.sensor.getType());
        float[] v = event.values;
        rawEventLog.append(String.format(Locale.US, "%.3f,%s,%d", t, name, event.accuracy));
        for (int i = 0; i < 5; i++) {
            rawEventLog.append(',');
            if (i < v.length) rawEventLog.append(String.format(Locale.US, "%.8f", v[i]));
        }
        rawEventLog.append('\n');
    }

    private String sensorShortName(int type) {
        if (type == Sensor.TYPE_GYROSCOPE) return "gyro";
        if (type == Sensor.TYPE_ACCELEROMETER) return "accel";
        if (type == Sensor.TYPE_ROTATION_VECTOR) return "rotation_vector";
        if (type == Sensor.TYPE_GAME_ROTATION_VECTOR) return "game_rotation_vector";
        if (type == Sensor.TYPE_MAGNETIC_FIELD) return "magnetometer";
        return "sensor_" + type;
    }

    private void logEvent(String event, long timestampNs, int attempt, String detail) {
        if (sessionStartNs == 0L) return;
        eventLog.append(String.format(Locale.US, "%.3f,%s,%d,%s\n",
                sessionMs(timestampNs), event, attempt, csvFlat(detail)));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (sensor == null || !monitoring) return;
        if (sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) magAccuracy = accuracy;
        if (sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) rotAccuracy = accuracy;
        logEvent("sensor_accuracy", SystemClock.elapsedRealtimeNanos(), 0,
                sensorShortName(sensor.getType()) + "=" + accuracy);
    }

    private boolean isGyroSaturated(float gx, float gy, float gz) {
        float max = getGyroMaxRange();
        if (max <= 0) return false;
        float threshold = max * SATURATION_FRACTION;
        return Math.abs(gx) >= threshold || Math.abs(gy) >= threshold || Math.abs(gz) >= threshold;
    }

    private float getGyroMaxRange() {
        return gyroscope == null ? 0f : gyroscope.getMaximumRange();
    }

    private boolean isAccelSaturated(float x, float y, float z) {
        float max = accelerometer == null ? 0f : accelerometer.getMaximumRange();
        if (max <= 0) return false;
        float threshold = max * ACCEL_SATURATION_FRACTION;
        return Math.abs(x) >= threshold || Math.abs(y) >= threshold || Math.abs(z) >= threshold;
    }

    private static double rotationDeltaAngle(float[] a, float[] b) {
        double frobenius = 0.0;
        for (int i = 0; i < 9; i++) frobenius += a[i] * b[i];
        double c = (frobenius - 1.0) * 0.5;
        c = Math.max(-1.0, Math.min(1.0, c));
        return Math.acos(c);
    }

    private static double vectorDeltaAngle(float ax, float ay, float az, float bx, float by, float bz) {
        double am = Math.sqrt(ax * ax + ay * ay + az * az);
        double bm = Math.sqrt(bx * bx + by * by + bz * bz);
        if (am < 1e-6 || bm < 1e-6) return 0.0;
        double c = (ax * bx + ay * by + az * bz) / (am * bm);
        c = Math.max(-1.0, Math.min(1.0, c));
        double angle = Math.acos(c);
        return angle < Math.toRadians(0.5) ? 0.0 : angle;
    }

    private double sessionMs(long timestampNs) {
        if (sessionStartNs == 0L) return 0.0;
        return (timestampNs - sessionStartNs) / 1_000_000.0;
    }

    private double headingAtOrBefore(Attempt a, long ts) {
        double result = Double.NaN;
        for (Frame f : a.frames) {
            if (f.timestampNs > ts) break;
            if (!Float.isNaN(f.headingDeg)) result = f.headingDeg;
        }
        return result;
    }

    private double percentile(ArrayList<Double> values, double p) {
        if (values.isEmpty()) return Double.NaN;
        int idx = (int) Math.round((values.size() - 1) * p);
        idx = Math.max(0, Math.min(values.size() - 1, idx));
        return values.get(idx);
    }

    private void vibrateCapture() {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0f, 1.12f);
        return t;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams lpMatch(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = bottomMargin;
        return p;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams weightedWithLeftMargin(int margin) {
        LinearLayout.LayoutParams p = weighted();
        p.leftMargin = margin;
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static float hypot3(float x, float y, float z) {
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    private static float normalize360(float deg) {
        float r = deg % 360f;
        if (r < 0) r += 360f;
        return r;
    }

    private static String csvFlat(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private static float[] identityMatrix() {
        return new float[]{1,0,0, 0,1,0, 0,0,1};
    }

    private static class Frame {
        long timestampNs;
        double sessionMs;
        float gx, gy, gz, gyroMag;
        float ax, ay, az, accelMag;
        boolean accelSaturated;
        float mx, my, mz, magMag;
        float headingDeg = Float.NaN;
        boolean gyroSaturated;
        int rotAccuracy;
        int magAccuracy;
        boolean hasOrientation;
        final float[] rotationMatrix = identityMatrix();

        Frame copy() {
            Frame n = new Frame();
            n.timestampNs = timestampNs; n.sessionMs = sessionMs;
            n.gx = gx; n.gy = gy; n.gz = gz; n.gyroMag = gyroMag;
            n.ax = ax; n.ay = ay; n.az = az; n.accelMag = accelMag; n.accelSaturated = accelSaturated;
            n.mx = mx; n.my = my; n.mz = mz; n.magMag = magMag;
            n.headingDeg = headingDeg; n.gyroSaturated = gyroSaturated;
            n.rotAccuracy = rotAccuracy; n.magAccuracy = magAccuracy;
            n.hasOrientation = hasOrientation;
            System.arraycopy(rotationMatrix, 0, n.rotationMatrix, 0, 9);
            return n;
        }
    }

    private static class Attempt {
        int candidateId;
        int index;
        long startTimestampNs;
        long endTimestampNs;
        double startSessionMs;
        double endSessionMs;
        double durationMs;
        final ArrayList<Frame> frames = new ArrayList<>();
        String closeReason = "";
        String userRating;

        boolean validMotion;
        boolean flipFlatRecognized;
        String trickName = "MOVIMENTO";
        String proposedTrickName;
        String proposedTrickDescription;
        String proposedTrickCriteria;

        String dominantAxis = "?";
        double axisPurityPct;
        double peakGyroDegS;
        double highSpinMs;
        double mainSpinDurationMs;
        double spinWindowTurnsLowerBound;
        double spinRateLowerBoundRps;
        double saturationOnlyTurnsFloor;
        double orientationPathTurnsEstimate;
        double magVectorPathTurnsIndicator;
        double totalTurnsLowerBound;
        boolean saturated;
        double saturationMs;
        double saturationPctOfHighSpin;
        boolean accelSaturated;
        double accelSaturationMs;
        double minAccelG;
        double peakAccelG;
        double catchAccelG;
        double lowGMs;
        boolean lowGCandidate;
        double headingStartDeg = Double.NaN;
        double headingEndDeg = Double.NaN;
        double highSpinStartMs = Double.NaN;
        double highSpinEndMs = Double.NaN;
        double lastLowGMs = Double.NaN;
        double catchCandidateMs = Double.NaN;
        int sampleCount;
        double sampleDtMedianMs = Double.NaN;
        double sampleDtP95Ms = Double.NaN;
        double sampleDtMaxMs = Double.NaN;

        double finishNormalDeltaDeg = Double.NaN;
        boolean sameFaceFinish = false;
        double postSpinTurns700Ms = 0;
        double settleAfterMainMs = 0;
        int secondaryImpactCount = 0;
        boolean dropSuspected = false;
        double flightTimeCandidateMs = Double.NaN;
        double heightCandidateCm = Double.NaN;

        String spinGrade = "C";
        String axisGrade = "C";
        String finishGrade = "?";
        String catchGrade = "C";
        String overallGrade = "C";
        String styleLabel = "UNCLASSIFIED";
    }

    private static class SpinSegment {
        long startNs;
        long endNs;
        double pathRad;
        double highSpinMs;
        double satMs;
        double absX, absY, absZ;
        double orientationPath;
        double magVectorPath;
        float peakGyro;
    }

    private static class TrickProposal {
        int sourceAttempt;
        String name = "";
        String description = "";
        String criteria = "";
    }

    private class ReplayView extends View {
        private final Attempt attempt;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cameraPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint frontPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long replayStartMs = 0L;
        private boolean playing = false;
        private int frameIndex = 0;
        private static final float SLOW_FACTOR = 0.32f;

        ReplayView(Context context, Attempt attempt) {
            super(context);
            this.attempt = attempt;
            fill.setColor(Color.rgb(121, 255, 170));
            fill.setStyle(Paint.Style.FILL);
            edge.setColor(Color.WHITE);
            edge.setStrokeWidth(dp(2));
            edge.setStyle(Paint.Style.STROKE);
            textPaint.setColor(Color.rgb(195, 201, 211));
            textPaint.setTextSize(dp(12));
            cameraPaint.setColor(Color.rgb(28, 30, 34));
            cameraPaint.setStyle(Paint.Style.FILL);
            frontPaint.setColor(Color.rgb(225, 229, 236));
            frontPaint.setStrokeWidth(dp(2));
        }

        void startReplay() {
            if (attempt.frames.isEmpty()) return;
            playing = true;
            frameIndex = 0;
            replayStartMs = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (attempt.frames.isEmpty()) return;

            Frame first = attempt.frames.get(0);
            Frame last = attempt.frames.get(attempt.frames.size() - 1);
            if (playing) {
                double targetSessionMs = first.sessionMs + (SystemClock.uptimeMillis() - replayStartMs) * SLOW_FACTOR;
                while (frameIndex + 1 < attempt.frames.size() && attempt.frames.get(frameIndex + 1).sessionMs <= targetSessionMs) {
                    frameIndex++;
                }
                if (frameIndex >= attempt.frames.size() - 1 || targetSessionMs >= last.sessionMs) {
                    playing = false;
                } else {
                    postInvalidateOnAnimation();
                }
            }

            Frame f = attempt.frames.get(Math.min(frameIndex, attempt.frames.size() - 1));
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f + dp(8);
            float scale = Math.min(getWidth(), getHeight()) * 0.27f;

            float[][] pts = new float[][]{
                    {-0.58f, -1.0f, 0f},
                    { 0.58f, -1.0f, 0f},
                    { 0.58f,  1.0f, 0f},
                    {-0.58f,  1.0f, 0f}
            };
            Path p = new Path();
            for (int i = 0; i < pts.length; i++) {
                float[] v = rotate(f.rotationMatrix, pts[i][0], pts[i][1], pts[i][2]);
                float perspective = 1.0f / (1.0f + 0.18f * v[2]);
                float x = cx + v[0] * scale * perspective;
                float y = cy + v[1] * scale * perspective;
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            canvas.drawPath(p, fill);
            canvas.drawPath(p, edge);

            // Subtle front/back cue: the back gets a camera dot; the front gets a tiny earpiece mark.
            float[] normal = rotate(f.rotationMatrix, 0f, 0f, 1f);
            float[] cam = rotate(f.rotationMatrix, -0.38f, -0.70f, 0.02f);
            float camPerspective = 1.0f / (1.0f + 0.18f * cam[2]);
            float camX = cx + cam[0] * scale * camPerspective;
            float camY = cy + cam[1] * scale * camPerspective;
            if (normal[2] < 0) {
                canvas.drawCircle(camX, camY, dp(7), cameraPaint);
                canvas.drawCircle(camX + dp(2), camY - dp(2), dp(2), frontPaint);
            } else {
                float[] earA = rotate(f.rotationMatrix, -0.13f, -0.77f, 0.02f);
                float[] earB = rotate(f.rotationMatrix, 0.13f, -0.77f, 0.02f);
                float pa = 1.0f / (1.0f + 0.18f * earA[2]);
                float pb = 1.0f / (1.0f + 0.18f * earB[2]);
                canvas.drawLine(cx + earA[0] * scale * pa, cy + earA[1] * scale * pa,
                        cx + earB[0] * scale * pb, cy + earB[1] * scale * pb, frontPaint);
            }

            double rel = f.sessionMs - attempt.startSessionMs;
            String phase = phaseForFrame(attempt, f);
            canvas.drawText(String.format(Locale.US, "%s   %+5.0f ms", phase, rel), dp(12), dp(24), textPaint);
            canvas.drawText(String.format(Locale.US, "%s %.0f%%   %.0f°/s%s",
                    attempt.dominantAxis, attempt.axisPurityPct, Math.toDegrees(f.gyroMag),
                    f.gyroSaturated ? " MAX" : ""), dp(12), getHeight() - dp(14), textPaint);
        }

        private float[] rotate(float[] r, float x, float y, float z) {
            return new float[]{
                    r[0] * x + r[1] * y + r[2] * z,
                    r[3] * x + r[4] * y + r[5] * z,
                    r[6] * x + r[7] * y + r[8] * z
            };
        }
    }

    private class TrickIconView extends View {
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cam = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
        TrickIconView(Context c) {
            super(c);
            body.setColor(Color.rgb(121, 255, 170)); body.setStyle(Paint.Style.FILL);
            edge.setColor(Color.WHITE); edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(dp(2));
            cam.setColor(Color.rgb(28, 30, 34));
            arrow.setColor(Color.rgb(190, 196, 207)); arrow.setStyle(Paint.Style.STROKE); arrow.setStrokeWidth(dp(2));
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            Path p=new Path();
            p.moveTo(w*.22f,h*.26f); p.lineTo(w*.72f,h*.18f); p.lineTo(w*.82f,h*.72f); p.lineTo(w*.32f,h*.82f); p.close();
            c.drawPath(p,body); c.drawPath(p,edge);
            c.drawCircle(w*.34f,h*.34f,dp(5),cam);
            c.drawCircle(w*.36f,h*.32f,dp(2),edge);
            Path a=new Path(); a.moveTo(w*.18f,h*.70f); a.quadTo(w*.05f,h*.42f,w*.20f,h*.20f); c.drawPath(a,arrow);
            c.drawLine(w*.20f,h*.20f,w*.13f,h*.23f,arrow); c.drawLine(w*.20f,h*.20f,w*.19f,h*.28f,arrow);
        }
    }

    private class TimelineView extends View {
        private final Attempt a;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);

        TimelineView(Context c, Attempt a) {
            super(c);
            this.a = a;
            textP.setColor(Color.rgb(200, 205, 214));
            textP.setTextSize(dp(10));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(14), right = getWidth() - dp(14);
            float y = dp(44);
            p.setStrokeWidth(dp(7));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(65, 68, 78));
            canvas.drawLine(left, y, right, y, p);

            double start = a.frames.isEmpty() ? a.startSessionMs : a.frames.get(0).sessionMs;
            double end = a.frames.isEmpty() ? a.endSessionMs : a.frames.get(a.frames.size() - 1).sessionMs;
            double span = Math.max(1.0, end - start);

            if (!Double.isNaN(a.highSpinStartMs) && !Double.isNaN(a.highSpinEndMs)) {
                p.setColor(a.saturated ? Color.rgb(255, 188, 92) : Color.rgb(125, 255, 169));
                canvas.drawLine(mapX(a.highSpinStartMs, start, span, left, right), y,
                        mapX(a.highSpinEndMs, start, span, left, right), y, p);
            }
            if (!Double.isNaN(a.catchCandidateMs)) {
                p.setColor(Color.rgb(255, 118, 132));
                float x = mapX(a.catchCandidateMs, start, span, left, right);
                canvas.drawCircle(x, y, dp(7), p);
            }
            canvas.drawText("PREBUFFER", left, dp(20), textP);
            canvas.drawText(a.saturated ? "MAIN SPIN / MAX" : "MAIN SPIN", getWidth() * 0.38f, dp(20), textP);
            canvas.drawText("CONTROL", right - dp(48), dp(20), textP);
            canvas.drawText("main spin = bloco usado na nota • voo/queda ainda experimentais", left, getHeight() - dp(12), textP);
        }

        private float mapX(double v, double start, double span, float left, float right) {
            double ratio = Math.max(0, Math.min(1, (v - start) / span));
            return (float) (left + ratio * (right - left));
        }
    }

    private class SensorChartView extends View {
        static final int MODE_GYRO = 0;
        static final int MODE_ACCEL = 1;
        private final Attempt a;
        private final int mode;
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint px = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint py = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pz = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pacc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);

        SensorChartView(Context c, Attempt a, int mode) {
            super(c);
            this.a = a;
            this.mode = mode;
            grid.setColor(Color.rgb(55, 58, 66)); grid.setStrokeWidth(dp(1));
            px.setColor(Color.rgb(255, 112, 120)); px.setStrokeWidth(dp(1)); px.setStyle(Paint.Style.STROKE);
            py.setColor(Color.rgb(125, 255, 169)); py.setStrokeWidth(dp(1)); py.setStyle(Paint.Style.STROKE);
            pz.setColor(Color.rgb(105, 180, 255)); pz.setStrokeWidth(dp(1)); pz.setStyle(Paint.Style.STROKE);
            pacc.setColor(Color.rgb(255, 205, 105)); pacc.setStrokeWidth(dp(2)); pacc.setStyle(Paint.Style.STROKE);
            label.setColor(Color.rgb(190, 195, 205)); label.setTextSize(dp(9));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (a.frames.size() < 2) return;
            float left = dp(8), right = getWidth() - dp(8), top = dp(14), bottom = getHeight() - dp(22);
            for (int i = 0; i <= 4; i++) {
                float yy = top + (bottom - top) * i / 4f;
                canvas.drawLine(left, yy, right, yy, grid);
            }
            if (mode == MODE_GYRO) drawGyro(canvas, left, right, top, bottom);
            else drawAccel(canvas, left, right, top, bottom);
        }

        private void drawGyro(Canvas c, float left, float right, float top, float bottom) {
            double max = Math.max(1.0, getGyroMaxRange());
            Path x = new Path(), y = new Path(), z = new Path();
            for (int i = 0; i < a.frames.size(); i++) {
                Frame f = a.frames.get(i);
                float xx = timeX(f, left, right);
                float vx = mapSigned(f.gx, max, top, bottom);
                float vy = mapSigned(f.gy, max, top, bottom);
                float vz = mapSigned(f.gz, max, top, bottom);
                if (i == 0) { x.moveTo(xx, vx); y.moveTo(xx, vy); z.moveTo(xx, vz); }
                else { x.lineTo(xx, vx); y.lineTo(xx, vy); z.lineTo(xx, vz); }
            }
            c.drawPath(x, px); c.drawPath(y, py); c.drawPath(z, pz);
            c.drawText("X", left, bottom + dp(14), px);
            c.drawText("Y", left + dp(20), bottom + dp(14), py);
            c.drawText("Z", left + dp(40), bottom + dp(14), pz);
            c.drawText("± sensor max", right - dp(70), bottom + dp(14), label);
        }

        private void drawAccel(Canvas c, float left, float right, float top, float bottom) {
            double max = Math.max(3.0 * G, a.peakAccelG * G * 1.08);
            Path p = new Path();
            for (int i = 0; i < a.frames.size(); i++) {
                Frame f = a.frames.get(i);
                float xx = timeX(f, left, right);
                float yy = (float) (bottom - Math.min(1.0, f.accelMag / max) * (bottom - top));
                if (i == 0) p.moveTo(xx, yy); else p.lineTo(xx, yy);
            }
            c.drawPath(p, pacc);
            float oneG = (float) (bottom - (G / max) * (bottom - top));
            c.drawLine(left, oneG, right, oneG, grid);
            c.drawText("1g", left + dp(3), oneG - dp(3), label);
            c.drawText(String.format(Locale.US, "max scale %.1fg", max / G), right - dp(78), bottom + dp(14), label);
        }

        private float timeX(Frame f, float left, float right) {
            double start = a.frames.get(0).sessionMs;
            double end = a.frames.get(a.frames.size() - 1).sessionMs;
            double span = Math.max(0.001, end - start);
            double ratio = Math.max(0, Math.min(1, (f.sessionMs - start) / span));
            return (float) (left + ratio * (right - left));
        }

        private float mapSigned(double value, double max, float top, float bottom) {
            double n = Math.max(-1, Math.min(1, value / max));
            return (float) (top + (1 - (n + 1) / 2.0) * (bottom - top));
        }
    }
}

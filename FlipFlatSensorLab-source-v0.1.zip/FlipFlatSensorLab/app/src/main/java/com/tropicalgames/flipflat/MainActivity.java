package com.tropicalgames.flipflat;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int EXPORT_REQUEST = 702;
    private static final float G = SensorManager.GRAVITY_EARTH;

    // V0.2 detection thresholds. These are calibration parameters, not game rules.
    private static final float START_GYRO_RAD_S = 6.0f;
    private static final float STOP_GYRO_RAD_S = 1.20f;
    private static final float HIGH_SPIN_RAD_S = 6.0f;
    // Two-stage validation: ordinary hand movement may trigger capture, but it is not saved as a trick.
    private static final float CONFIRM_PEAK_RAD_S = 13.0f; // ~745 deg/s
    private static final double CONFIRM_MAIN_TURNS = 1.0;
    private static final long MAIN_SPIN_GAP_NS = 45_000_000L;
    private static final long STOP_HOLD_NS = 280_000_000L;
    private static final long MIN_ATTEMPT_NS = 180_000_000L;
    private static final long MAX_ATTEMPT_NS = 4_000_000_000L;
    private static final long PREBUFFER_NS = 650_000_000L;
    private static final int SENSOR_PERIOD_US = 5_000; // target ~200 Hz where supported
    private static final float LOW_G_THRESHOLD = 0.45f * G;
    private static final float SATURATION_FRACTION = 0.965f;
    private static final float ACCEL_SATURATION_FRACTION = 0.965f;
    private static final int MAX_RAW_EVENTS = 220_000;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor rotationVector;
    private Sensor gameRotationVector;
    private Sensor magnetometer;
    private Vibrator vibrator;
    private ToneGenerator toneGenerator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean monitoring = false;
    private boolean attemptActive = false;
    private long sessionStartNs = 0L;
    private long lastGyroTimestampNs = 0L;
    private long attemptStartNs = 0L;
    private long lastAboveStopNs = 0L;

    private float ax = 0f, ay = 0f, az = G;
    private float accelMagnitude = G;
    private float mx = 0f, my = 0f, mz = 0f;
    private float magneticMagnitude = 0f;
    private float liveGyroDegS = 0f;
    private float headingDeg = Float.NaN;
    private int rotAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
    private int magAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;

    private final float[] latestRotationMatrix = identityMatrix();
    private final float[] latestGameRotationMatrix = identityMatrix();
    private boolean hasRotationMatrix = false;
    private boolean hasGameRotationMatrix = false;

    private int attemptCount = 0;
    private int candidateCount = 0;
    private Attempt currentAttempt;
    private final ArrayList<Attempt> attempts = new ArrayList<>();
    private final ArrayList<Attempt> discardedCandidates = new ArrayList<>();
    private final ArrayList<TrickProposal> trickProposals = new ArrayList<>();
    private final ArrayDeque<Frame> preBuffer = new ArrayDeque<>();

    private final StringBuilder rawEventLog = new StringBuilder();
    private final StringBuilder eventLog = new StringBuilder();
    private int rawEventCount = 0;
    private boolean rawLogTruncated = false;

    // V0.4 product shell. Sensor/calibration engine remains the V0.3 engine underneath.
    private static final int C_BG = Color.rgb(5, 5, 6);
    private static final int C_PANEL = Color.rgb(17, 18, 20);
    private static final int C_PANEL_2 = Color.rgb(26, 27, 30);
    private static final int C_WHITE = Color.rgb(246, 246, 244);
    private static final int C_MUTED = Color.rgb(164, 166, 171);
    private static final int C_ACID = Color.rgb(184, 255, 45);
    private static final String PREFS = "flipflat_v04_local";
    private static final String PREF_HISTORY = "history";
    private static final String PREF_SAFETY = "safety_accepted";
    private static final String PREF_PROTECT = "protect_play";

    private SharedPreferences prefs;
    private boolean safetyAccepted = false;
    private boolean protectPlay = true;
    private boolean lockTaskRequested = false;
    private String currentScreen = "HOME";
    private String activeTrickName = "FLIP FLAT";
    private final ArrayList<PersistedAttempt> localHistory = new ArrayList<>();

    private TextView statusText;
    private TextView sensorText;
    private TextView gyroText;
    private TextView accelText;
    private TextView headingText;
    private TextView lastResultText;
    private TextView sessionCountText;
    private LinearLayout attemptsContainer;
    private Button playButton;
    private Button exportButton;
    private Button clearButton;
    private Button syncButton;
    private TextView screenTitleText;
    private TextView scoreSummaryText;
    private LinearLayout lastResultContainer;
    private ReplayView inlineReplay;
    private Attempt inlineReplayAttempt;
    private Runnable stopHoldRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        gameRotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 82);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        safetyAccepted = prefs.getBoolean(PREF_SAFETY, false);
        protectPlay = prefs.getBoolean(PREF_PROTECT, true);
        loadLocalHistory();

        buildUi();
        enterImmersiveMode();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (toneGenerator != null) toneGenerator.release();
    }

    private void buildUi() {
        showHomeScreen();
    }

    private void resetUiRefs() {
        statusText = null; sensorText = null; gyroText = null; accelText = null; headingText = null;
        lastResultText = null; sessionCountText = null; attemptsContainer = null;
        playButton = null; exportButton = null; clearButton = null; syncButton = null;
        screenTitleText = null; scoreSummaryText = null;
        lastResultContainer = null; inlineReplay = null; inlineReplayAttempt = null;
    }

    private LinearLayout newScreenRoot() {
        resetUiRefs();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(C_BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(38));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
        return root;
    }

    private void addBrand(LinearLayout root, String eyebrow) {
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        TextView flip = text("FLIP", 26, C_WHITE, true);
        flip.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        TextView flat = text(" FLAT", 26, C_ACID, true);
        flat.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        brand.addView(flip); brand.addView(flat);
        root.addView(brand);
        if (eyebrow != null && !eyebrow.isEmpty()) {
            TextView e = text(eyebrow.toUpperCase(Locale.ROOT), 10, C_MUTED, true);
            e.setLetterSpacing(.12f); e.setPadding(1, 0, 0, dp(18)); root.addView(e);
        } else {
            brand.setPadding(0,0,0,dp(18));
        }
    }

    private TextView navLink(String label) {
        TextView v = text(label, 12, C_MUTED, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(12), dp(10), dp(12));
        v.setBackground(strokeRect(C_PANEL, Color.rgb(65,66,70), 14, 1));
        return v;
    }

    private Button acidButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(Color.BLACK);
        b.setBackground(roundRect(C_ACID, 17));
        b.setPadding(dp(12), dp(15), dp(12), dp(15));
        return b;
    }

    private Button ghostButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(C_WHITE);
        b.setBackground(strokeRect(C_BG, Color.rgb(99,100,105), 16, 1));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        return b;
    }

    private void enterImmersiveMode() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    private void requestScreenPinningIfEnabled() {
        if (!protectPlay || lockTaskRequested) return;
        lockTaskRequested = true;
        try {
            startLockTask();
        } catch (Exception e) {
            lockTaskRequested = false;
            Toast.makeText(this, "Proteção do Android indisponível; o jogo continua normalmente.", Toast.LENGTH_SHORT).show();
        }
    }

    private void releaseScreenPinning() {
        if (!lockTaskRequested) return;
        try { stopLockTask(); } catch (Exception ignored) {}
        lockTaskRequested = false;
    }

    private void setMonitoringButtonMode() {
        if (playButton == null) return;
        playButton.setText("SEGURE PARA PARAR");
        playButton.setTextColor(C_WHITE);
        playButton.setBackground(roundRect(Color.rgb(38,39,42),17));
        playButton.setOnClickListener(null);
        playButton.setOnTouchListener((v, event) -> {
            if (!monitoring) return false;
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (stopHoldRunnable != null) handler.removeCallbacks(stopHoldRunnable);
                stopHoldRunnable = () -> {
                    if (monitoring) {
                        stopMonitoring();
                        Toast.makeText(this, "Sessão pausada.", Toast.LENGTH_SHORT).show();
                    }
                };
                handler.postDelayed(stopHoldRunnable, 900);
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                if (stopHoldRunnable != null) handler.removeCallbacks(stopHoldRunnable);
                return true;
            }
            return true;
        });
    }

    private void setStartButtonMode() {
        if (playButton == null) return;
        playButton.setOnTouchListener(null);
        playButton.setText("▶  ESTOU PRONTO");
        playButton.setTextColor(Color.BLACK);
        playButton.setBackground(roundRect(C_ACID,17));
        playButton.setOnClickListener(v -> startMonitoring());
    }

    private LinearLayout statTile(String big, String small) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(12),dp(12),dp(12),dp(12));
        tile.setBackground(roundRect(C_PANEL,14));
        TextView a=text(big,18,C_WHITE,true); tile.addView(a);
        TextView b=text(small.toUpperCase(Locale.ROOT),9,C_MUTED,true); b.setLetterSpacing(.08f); tile.addView(b);
        return tile;
    }

    private void showHomeScreen() {
        if (monitoring) stopMonitoring();
        releaseScreenPinning();
        currentScreen = "HOME";
        LinearLayout root = newScreenRoot();
        addBrand(root, "esporte real + recorde digital");

        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(roundRect(C_PANEL, 20));
        ImageView heroArt = new ImageView(this);
        heroArt.setImageResource(R.drawable.home_hero);
        heroArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroArt.setAlpha(.68f);
        hero.addView(heroArt, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(246,5,5,6), Color.argb(190,5,5,6), Color.argb(45,5,5,6)}));
        hero.addView(shade, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL); copy.setPadding(dp(18),dp(22),dp(18),dp(18));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        hero.addView(copy, cp);
        TextView hero1=text("FARME AURA.",31,C_WHITE,true); hero1.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC)); copy.addView(hero1);
        TextView hero2=text("OU PASSE VERGONHA.",31,C_ACID,true); hero2.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC)); copy.addView(hero2);
        TextView sub=text("Habilidade real. Recorde digital.\nSeu celular. Seu estilo. Seu risco.",13,C_WHITE,false); sub.setPadding(0,dp(6),0,dp(18)); copy.addView(sub);
        Button play=acidButton("▶  FAZER MANOBRA"); play.setOnClickListener(v->openPlayWithSafety(activeTrickName)); copy.addView(play,lpMatch(dp(8)));
        Button catalog=ghostButton("VER MANOBRAS"); catalog.setOnClickListener(v->showCatalogScreen()); copy.addView(catalog,lpMatch(0));
        root.addView(hero,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(350)));

        LinearLayout quick = new LinearLayout(this); quick.setOrientation(LinearLayout.HORIZONTAL); quick.setWeightSum(3f); quick.setPadding(0,dp(14),0,0);
        TextView hist=navLink("HISTÓRICO  ›"); hist.setOnClickListener(v->showHistoryScreen());
        TextView cat=navLink("CONQUISTAS  ›"); cat.setOnClickListener(v->showCatalogScreen());
        TextView dev=navLink("MODO DEV  ›"); dev.setOnClickListener(v->showDeveloperScreen());
        quick.addView(hist,weighted()); quick.addView(cat,weightedWithLeftMargin(dp(6))); quick.addView(dev,weightedWithLeftMargin(dp(6))); root.addView(quick,lpMatch(dp(14)));

        PersistedAttempt best=bestPersistedAttempt();
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL); stats.setWeightSum(3f);
        int dominated=0; for(TrickDefinition d:trickCatalog()) if(bestForTrick(d.name)!=null) dominated++;
        LinearLayout s1=statTile(dominated+"/"+trickCatalog().size(),"manobras");
        LinearLayout s2=statTile(best==null?"—":best.grade,best==null?"melhor grade":String.format(Locale.US,"%,d pts",best.points));
        LinearLayout s3=statTile(String.valueOf(localHistory.size()),"tentativas");
        stats.addView(s1,weighted()); stats.addView(s2,weightedWithLeftMargin(dp(6))); stats.addView(s3,weightedWithLeftMargin(dp(6))); root.addView(stats,lpMatch(dp(14)));

        TextView mantra=text("MENOS MENU. MAIS TENTATIVA.\nComece pelo Flip Flat. O resto da modalidade nasce quando alguém faz algo que vale nome.",12,C_MUTED,false);
        mantra.setPadding(dp(2),0,dp(2),dp(12)); root.addView(mantra);
        TextView safety=navLink("AVISOS / JOGUE POR SUA CONTA E RISCO"); safety.setOnClickListener(v->showSafetyScreen(null)); root.addView(safety,lpMatch(0));
    }

    private void openPlayWithSafety(String trick) {
        activeTrickName = trick == null ? "FLIP FLAT" : trick;
        if (!safetyAccepted) showSafetyScreen(() -> showPlayScreen(activeTrickName));
        else showPlayScreen(activeTrickName);
    }

    private void showSafetyScreen(Runnable onAccept) {
        if (monitoring) stopMonitoring();
        releaseScreenPinning();
        currentScreen="SAFETY";
        LinearLayout root=newScreenRoot(); addBrand(root,"antes de pagar de brabo");
        FrameLayout art=new FrameLayout(this); art.setBackground(roundRect(C_PANEL,18));
        ImageView img=new ImageView(this); img.setImageResource(R.drawable.safety_hero); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setAlpha(.58f);
        art.addView(img,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        View shade=new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(35,5,5,6),Color.argb(230,5,5,6)})); art.addView(shade,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.BOTTOM);c.setPadding(dp(18),dp(18),dp(18),dp(18));art.addView(c,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        TextView h1=text("ANTES DE PAGAR DE",27,C_WHITE,true);h1.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));c.addView(h1);
        TextView h2=text("BRABO",44,C_ACID,true);h2.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));c.addView(h2);
        TextView h3=text("Jogue por sua conta e risco.",14,C_WHITE,true);c.addView(h3);
        root.addView(art,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(315)));
        String[] rules={"NADA DE VIDRO, TV, PET OU GENTE DESAVISADA POR PERTO.","QUER COMEÇAR BONITO? CAMA OU SOFÁ.","SE FOR IMPRESSIONAR ALGUÉM, A RESPONSABILIDADE É SUA.","SE DER RUIM, FALTA DE HABILIDADE NÃO É BUG NOSSO.","SEM PROTEÇÃO EMBAIXO SÓ DEPOIS DE DOMINAR — E CONTINUA SENDO SEU RISCO."};
        for(String r:rules){TextView row=text("✓  "+r,11,C_WHITE,true);row.setPadding(dp(13),dp(11),dp(13),dp(11));row.setBackground(roundRect(C_PANEL,12));root.addView(row,lpMatch(dp(6)));}
        CheckBox accept=new CheckBox(this); accept.setText(" Li os avisos e vou no meu risco.");accept.setTextColor(C_WHITE);accept.setButtonTintList(android.content.res.ColorStateList.valueOf(C_ACID));root.addView(accept,lpMatch(dp(8)));
        Button ok=acidButton("▶  EU ME GARANTO"); ok.setEnabled(false); ok.setAlpha(.45f); accept.setOnCheckedChangeListener((b,checked)->{ok.setEnabled(checked);ok.setAlpha(checked?1f:.45f);});
        ok.setOnClickListener(v->{safetyAccepted=true;prefs.edit().putBoolean(PREF_SAFETY,true).apply();if(onAccept!=null)onAccept.run();else showHomeScreen();});root.addView(ok,lpMatch(dp(8)));
        Button back=ghostButton("VOLTAR");back.setOnClickListener(v->showHomeScreen());root.addView(back,lpMatch(0));
    }

    private void showPlayScreen(String trick) {
        if (monitoring) stopMonitoring();
        currentScreen = "PLAY"; activeTrickName = trick == null ? "FLIP FLAT" : trick;
        LinearLayout root = newScreenRoot(); addBrand(root, "fazer manobra");
        TextView back = navLink("‹  INÍCIO"); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); back.setOnClickListener(v -> { if(!monitoring) showHomeScreen(); }); root.addView(back, lpMatch(dp(10)));
        TrickDefinition def = trickByName(activeTrickName);
        TextView target = text(def.name.toUpperCase(Locale.ROOT), 29, C_WHITE, true); target.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC)); root.addView(target);
        TextView status = text(def.status + "  •  " + def.tagline, 10, def.official ? C_ACID : C_MUTED, true); status.setLetterSpacing(.08f); status.setPadding(0,0,0,dp(8)); root.addView(status);
        TextView desc = text(def.description, 12, C_MUTED, false); desc.setPadding(0,0,0,dp(10)); root.addView(desc);

        TrickIconView icon = new TrickIconView(this); icon.setBackground(roundRect(C_PANEL,16)); root.addView(icon,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(135)));
        TextView criteria = text("O QUE VALE PONTO  •  " + def.criteriaText().replace("\n","  •  "), 10, C_WHITE, true); criteria.setPadding(dp(12),dp(10),dp(12),dp(10)); criteria.setBackground(roundRect(C_PANEL,12)); root.addView(criteria,lpMatch(dp(10)));

        LinearLayout guardRow=new LinearLayout(this); guardRow.setOrientation(LinearLayout.HORIZONTAL); guardRow.setGravity(Gravity.CENTER_VERTICAL); guardRow.setPadding(dp(12),dp(9),dp(12),dp(9)); guardRow.setBackground(roundRect(C_PANEL,12));
        CheckBox guard=new CheckBox(this); guard.setChecked(protectPlay); guard.setButtonTintList(android.content.res.ColorStateList.valueOf(C_ACID)); guardRow.addView(guard);
        TextView guardText=text("PROTEÇÃO ANTI-TOQUE (BETA)\nPrende o app na tela pelo Android enquanto você joga.",10,C_WHITE,true);guardRow.addView(guardText,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        guard.setOnCheckedChangeListener((b,checked)->{protectPlay=checked;prefs.edit().putBoolean(PREF_PROTECT,checked).apply();});root.addView(guardRow,lpMatch(dp(10)));

        statusText = text("PRONTO", 18, C_WHITE, true); statusText.setGravity(Gravity.CENTER); statusText.setPadding(dp(12),dp(12),dp(12),dp(12)); statusText.setBackground(roundRect(C_PANEL_2,14)); root.addView(statusText,lpMatch(dp(8)));
        LinearLayout live = new LinearLayout(this); live.setOrientation(LinearLayout.HORIZONTAL); live.setWeightSum(3f);
        gyroText=metric("GIRO\n0 °/s"); accelText=metric("ACEL.\n1.00 g"); headingText=metric("NORTE\n—");
        live.addView(gyroText,weighted()); live.addView(accelText,weightedWithLeftMargin(dp(5))); live.addView(headingText,weightedWithLeftMargin(dp(5))); root.addView(live,lpMatch(dp(8)));

        playButton=acidButton("▶  ESTOU PRONTO"); playButton.setOnClickListener(v -> startMonitoring()); root.addView(playButton,lpMatch(dp(10)));
        TextView guardHint=text("Durante a sessão, toques comuns não param o jogo. Para parar, segure o botão por ~1 segundo.",10,C_MUTED,false);guardHint.setPadding(dp(2),0,dp(2),dp(10));root.addView(guardHint);

        lastResultContainer=new LinearLayout(this);lastResultContainer.setOrientation(LinearLayout.VERTICAL);lastResultContainer.setPadding(dp(0),dp(0),dp(0),dp(0));root.addView(lastResultContainer,lpMatch(dp(10)));
        renderEmptyResult();

        TextView recentTitle=text("ÚLTIMAS TENTATIVAS",11,C_WHITE,true); recentTitle.setLetterSpacing(.08f); root.addView(recentTitle);
        sessionCountText=text(attempts.size()+" tentativas",10,C_MUTED,true); sessionCountText.setPadding(0,0,0,dp(6)); root.addView(sessionCountText);
        attemptsContainer=new LinearLayout(this); attemptsContainer.setOrientation(LinearLayout.VERTICAL); root.addView(attemptsContainer,lpMatch(dp(8)));
        renderAttempts();
        TextView dev=navLink("MODO DEV / CALIBRAÇÃO  ›"); dev.setOnClickListener(v -> {if(!monitoring)showDeveloperScreen();}); root.addView(dev,lpMatch(0));
        if (accelerometer==null || gyroscope==null) { playButton.setEnabled(false); statusText.setText("SENSORES MÍNIMOS AUSENTES"); }
    }

    private void renderEmptyResult() {
        if(lastResultContainer==null)return;
        lastResultContainer.removeAllViews();
        TextView empty=text("MANDA A MANOBRA.\nO resultado aparece aqui na hora — nota, critérios e replay 3D.",12,C_MUTED,true);
        empty.setPadding(dp(14),dp(13),dp(14),dp(13));empty.setBackground(roundRect(C_PANEL,14));lastResultContainer.addView(empty);
    }

    private void showCatalogScreen() {
        if (monitoring) stopMonitoring(); currentScreen="CATALOG";
        LinearLayout root=newScreenRoot(); addBrand(root,"catálogo + conquistas");
        TextView back=navLink("‹  INÍCIO"); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); back.setOnClickListener(v->showHomeScreen()); root.addView(back,lpMatch(dp(12)));
        TextView h=text("APRENDA. TENTE. DÊ NOME AO RESTO.",25,C_WHITE,true); h.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC)); root.addView(h);
        TextView sub=text("O catálogo também é seu mapa de conquistas. Protótipos entram antes de virarem regra oficial.",12,C_MUTED,false); sub.setPadding(0,0,0,dp(15)); root.addView(sub);
        addRecordsStrip(root);
        addAchievementStrip(root);
        for (TrickDefinition def : trickCatalog()) addTrickCatalogCard(root,def);
        TextView community=navLink("+  FEZ ALGO NOVO? REGISTRE NO RESULTADO E PROPONHA UMA MANOBRA"); community.setOnClickListener(v->openPlayWithSafety("FLIP FLAT")); root.addView(community,lpMatch(0));
    }

    private void addRecordsStrip(LinearLayout root) {
        PersistedAttempt best=bestPersistedAttempt();
        double bestAxis=0,bestTurns=0; int count=localHistory.size();
        for(PersistedAttempt p:localHistory){bestAxis=Math.max(bestAxis,p.axisPurity);bestTurns=Math.max(bestTurns,p.turns);}
        TextView r=text(best==null?"SEUS RECORDES\nAinda em branco. Excelente motivo para jogar.":String.format(Locale.US,"SEUS RECORDES\n%,d pts  •  eixo %.1f%%  •  giros %s  •  %d tentativas",best.points,bestAxis,bestTurns>=0?String.format(Locale.US,">= %.2f",bestTurns):"—",count),12,C_WHITE,true);
        r.setPadding(dp(14),dp(13),dp(14),dp(13));r.setBackground(roundRect(C_PANEL,14));root.addView(r,lpMatch(dp(12)));
    }

    private void addAchievementStrip(LinearLayout root) {
        boolean first=false, sGrade=false, axis95=false; int cleanRun=0; double bestAxis=0;
        for(PersistedAttempt p:localHistory){if("FLIP FLAT".equalsIgnoreCase(p.trickName))first=true;if("S".equals(p.grade))sGrade=true;bestAxis=Math.max(bestAxis,p.axisPurity);}
        for(int i=localHistory.size()-1;i>=0&&cleanRun<5;i--){if("F".equals(localHistory.get(i).grade))break;cleanRun++;}
        axis95=bestAxis>=95;
        String line=(first?"✓":"○")+" PRIMEIRO FLIP   "+(sGrade?"✓":"○")+" GRADE S   "+(axis95?"✓":"○")+" EIXO 95%   "+(cleanRun>=5?"✓":"○")+" 5 SEM F";
        TextView a=text("CONQUISTAS\n"+line,11,C_WHITE,true);a.setPadding(dp(14),dp(12),dp(14),dp(12));a.setBackground(roundRect(C_PANEL,14));root.addView(a,lpMatch(dp(12)));
    }

    private void addTrickCatalogCard(LinearLayout root, TrickDefinition def) {
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(14),dp(14),dp(14));card.setBackground(strokeRect(C_PANEL,def.official?C_ACID:Color.rgb(60,61,65),16,def.official?2:1));
        TextView name=text(def.name,21,C_WHITE,true);name.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));card.addView(name);
        PersistedAttempt best=bestForTrick(def.name);
        TextView badge=text((def.official?"OFICIAL":"EM CALIBRAÇÃO")+(best==null?"  •  ainda não dominada":String.format(Locale.US,"  •  melhor %s / %,d pts",best.grade,best.points)),10,def.official?C_ACID:C_MUTED,true);badge.setPadding(0,1,0,dp(8));card.addView(badge);
        TrickIconView visual=new TrickIconView(this,def.name);visual.setBackground(roundRect(Color.rgb(10,11,13),12));card.addView(visual,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(125)));
        TextView d=text(def.description,12,C_MUTED,false);d.setPadding(0,dp(8),0,0);card.addView(d);
        TextView c=text(def.criteriaText(),11,C_WHITE,false);c.setPadding(0,dp(8),0,dp(10));card.addView(c);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setWeightSum(2f);
        Button tryB=acidButton("▶  TENTAR");tryB.setTextSize(12);tryB.setOnClickListener(v->openPlayWithSafety(def.name));row.addView(tryB,weighted());
        Button info=ghostButton("DETALHES");info.setTextSize(11);info.setOnClickListener(v->Toast.makeText(this,def.status+" • reconhecimento automático em evolução",Toast.LENGTH_SHORT).show());row.addView(info,weightedWithLeftMargin(dp(7)));card.addView(row);
        root.addView(card,lpMatch(dp(10)));
    }

    private void showHistoryScreen() {
        if (monitoring) stopMonitoring(); currentScreen="HISTORY";
        LinearLayout root=newScreenRoot(); addBrand(root,"meu histórico");
        TextView back=navLink("‹  INÍCIO"); back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); back.setOnClickListener(v->showHomeScreen()); root.addView(back,lpMatch(dp(12)));
        TextView h=text("CADA TENTATIVA CONTA.",27,C_WHITE,true);h.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));root.addView(h);
        TextView s=text("Histórico local desta instalação. Replays completos continuam disponíveis para as tentativas da sessão atual.",12,C_MUTED,false);s.setPadding(0,0,0,dp(14));root.addView(s);
        addRecordsStrip(root);
        if(localHistory.isEmpty()){TextView e=text("Nada por aqui ainda. Faça uma manobra e volte com história pra contar.",13,C_MUTED,false);e.setPadding(dp(14),dp(14),dp(14),dp(14));e.setBackground(roundRect(C_PANEL,14));root.addView(e);return;}
        for(int i=localHistory.size()-1;i>=0;i--){PersistedAttempt p=localHistory.get(i);TextView card=text(String.format(Locale.US,"%s  •  %s  •  %,d PTS\nGIROS %s  |  EIXO %.1f%%  |  %s",p.trickName,p.grade,p.points,p.saturated?String.format(Locale.US,"> %.2f",p.turns):String.format(Locale.US,"~ %.2f",p.turns),p.axisPurity,p.resultLabel),12,C_WHITE,true);card.setPadding(dp(14),dp(13),dp(14),dp(13));card.setBackground(roundRect(C_PANEL,14));root.addView(card,lpMatch(dp(7)));}
    }

    private void showDeveloperScreen() {
        if (monitoring) stopMonitoring(); currentScreen="DEV";
        int pad=dp(18),gap=dp(10); LinearLayout root=newScreenRoot();
        addBrand(root,"developer / calibration lab v0.5");
        TextView back=navLink("‹  PRODUTO");back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);back.setOnClickListener(v->showHomeScreen());root.addView(back,lpMatch(gap));
        TextView concept=text("MODO TÉCNICO\nA experiência V0.5 está por cima. Aqui continuam o sensor lab, replay, gráficos, propostas, sync de vídeo e exportação completa — sem perda de capacidade da V0.3.",12,C_WHITE,false);concept.setPadding(dp(14),dp(12),dp(14),dp(12));concept.setBackground(roundRect(C_PANEL,14));root.addView(concept,lpMatch(gap));
        sensorText=text("",11,C_MUTED,false);root.addView(sensorText,lpMatch(gap));updateSensorStatus();
        statusText=text("PRONTO",19,C_WHITE,true);statusText.setGravity(Gravity.CENTER);statusText.setPadding(dp(12),dp(12),dp(12),dp(12));statusText.setBackground(roundRect(C_PANEL_2,16));root.addView(statusText,lpMatch(gap));
        LinearLayout liveRow=new LinearLayout(this);liveRow.setOrientation(LinearLayout.HORIZONTAL);liveRow.setWeightSum(3f);gyroText=metric("GIRO\n0 °/s");accelText=metric("ACEL.\n1.00 g");headingText=metric("NORTE\n—");liveRow.addView(gyroText,weighted());liveRow.addView(accelText,weightedWithLeftMargin(dp(6)));liveRow.addView(headingText,weightedWithLeftMargin(dp(6)));root.addView(liveRow,lpMatch(gap));
        playButton=acidButton("▶  PLAY / INICIAR SESSÃO");playButton.setOnClickListener(v->toggleMonitoring());root.addView(playButton,lpMatch(gap));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setWeightSum(2f);syncButton=smallButton("🔊  SYNC VÍDEO");syncButton.setOnClickListener(v->runVideoSync());tools.addView(syncButton,weighted());sessionCountText=text(attempts.size()+" tentativas",11,C_MUTED,true);sessionCountText.setGravity(Gravity.CENTER);sessionCountText.setBackground(roundRect(C_PANEL,14));tools.addView(sessionCountText,weightedWithLeftMargin(dp(8)));root.addView(tools,lpMatch(gap));
        lastResultText=text("ÚLTIMO RESULTADO\nAguardando tentativa.",13,C_MUTED,true);lastResultText.setPadding(dp(14),dp(12),dp(14),dp(12));lastResultText.setBackground(roundRect(C_PANEL,14));root.addView(lastResultText,lpMatch(gap));
        TextView section=text("TENTATIVAS  •  toque para Replay + Dados",12,C_ACID,true);root.addView(section);attemptsContainer=new LinearLayout(this);attemptsContainer.setOrientation(LinearLayout.VERTICAL);root.addView(attemptsContainer,lpMatch(gap));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setWeightSum(2f);exportButton=smallButton("EXPORTAR CSV");exportButton.setOnClickListener(v->exportCsv());actions.addView(exportButton,weighted());clearButton=smallButton("ZERAR SESSÃO");clearButton.setOnClickListener(v->clearSession());actions.addView(clearButton,weightedWithLeftMargin(dp(8)));root.addView(actions);
        renderAttempts(); if(accelerometer==null||gyroscope==null){playButton.setEnabled(false);statusText.setText("SENSORES MÍNIMOS AUSENTES");}
    }

    private GradientDrawable strokeRect(int fill, int stroke, int radiusDp, int strokeDp) {
        GradientDrawable gd=new GradientDrawable();gd.setColor(fill);gd.setCornerRadius(dp(radiusDp));gd.setStroke(dp(strokeDp),stroke);return gd;
    }

    private TrickDefinition trickByName(String name) {
        for(TrickDefinition t:trickCatalog()) if(t.name.equalsIgnoreCase(name)) return t;
        return trickCatalog().get(0);
    }

    private ArrayList<TrickDefinition> trickCatalog() {
        ArrayList<TrickDefinition> list=new ArrayList<>();
        list.add(new TrickDefinition("FLIP FLAT",true,"OFICIAL","O aterrissar perfeito.","Jogue para cima, gire mantendo um eixo limpo e capture na mesma face.",new String[]{"Giro / velocidade","Axis Lock","Finalização na mesma face*","Controle na captura"}));
        list.add(new TrickDefinition("PUNCH LINE",false,"PROTÓTIPO #01","Vira linha para quem olha.","O celular parte de lado e gira de ponta-cabeça. A execução boa parece uma linha no ar.",new String[]{"Giros e velocidade","Altura / tempo no ar","Eixo correto","Captura com a face certa"}));
        list.add(new TrickDefinition("FLIP FLAT HORIZONTAL",false,"PROTÓTIPO #02","O Flat atravessa.","O mesmo espírito do Flip Flat, mas lançado lateralmente para ser capturado pela outra mão.",new String[]{"Trajetória lateral","Tempo no ar","Eixo estável","Captura na mão oposta"}));
        list.add(new TrickDefinition("CRAZY NOT RANDOM",false,"PROTÓTIPO #03","Caos com método.","Combina o giro do Flip Flat com rotação de ponta-cabeça. Parece aleatório; a graça é não ser.",new String[]{"Equilíbrio entre dois eixos","Ritmo de rotação","Controle do caos","Captura limpa"}));
        list.add(new TrickDefinition("BACKFLIP",false,"PROTÓTIPO #04","Ponta-cabeça no horizonte.","Giro de ponta-cabeça com o aparelho alinhado ao horizonte — diferente do Punch Line.",new String[]{"Giros e velocidade","Altura / tempo no ar","Alinhamento ao horizonte","Captura na posição certa"}));
        return list;
    }

    private void loadLocalHistory() {
        localHistory.clear(); if(prefs==null)return; String raw=prefs.getString(PREF_HISTORY,""); if(raw==null||raw.isEmpty())return;
        for(String line:raw.split("\\n")){String[] x=line.split("\\|",-1);if(x.length<10)continue;try{PersistedAttempt p=new PersistedAttempt();p.whenMs=Long.parseLong(x[0]);p.trickName=x[1];p.grade=x[2];p.points=Integer.parseInt(x[3]);p.turns=Double.parseDouble(x[4]);p.saturated=Boolean.parseBoolean(x[5]);p.axisPurity=Double.parseDouble(x[6]);p.finishGrade=x[7];p.controlGrade=x[8];p.resultLabel=x[9];localHistory.add(p);}catch(Exception ignored){}}
    }

    private void persistAttemptSummary(Attempt a) {
        PersistedAttempt p=new PersistedAttempt();p.whenMs=System.currentTimeMillis();p.trickName=a.targetTrickName==null?a.trickName:a.targetTrickName;p.grade=a.overallGrade;p.points=a.points;p.turns=a.spinWindowTurnsLowerBound;p.saturated=a.saturated;p.axisPurity=a.axisPurityPct;p.finishGrade=a.finishGrade;p.controlGrade=a.catchGrade;p.resultLabel=a.styleLabel;localHistory.add(p);
        while(localHistory.size()>200)localHistory.remove(0);StringBuilder b=new StringBuilder();for(PersistedAttempt q:localHistory){if(b.length()>0)b.append('\n');b.append(q.whenMs).append('|').append(safePipe(q.trickName)).append('|').append(safePipe(q.grade)).append('|').append(q.points).append('|').append(String.format(Locale.US,"%.6f",q.turns)).append('|').append(q.saturated).append('|').append(String.format(Locale.US,"%.4f",q.axisPurity)).append('|').append(safePipe(q.finishGrade)).append('|').append(safePipe(q.controlGrade)).append('|').append(safePipe(q.resultLabel));}prefs.edit().putString(PREF_HISTORY,b.toString()).apply();
    }

    private void refreshPersistedAttempt(Attempt a){
        for(int i=localHistory.size()-1;i>=0;i--){PersistedAttempt p=localHistory.get(i);if(p.trickName.equalsIgnoreCase(a.targetTrickName==null?a.trickName:a.targetTrickName)){p.grade=a.overallGrade;p.points=a.points;p.finishGrade=a.finishGrade;p.controlGrade=a.catchGrade;p.resultLabel=a.styleLabel;break;}}
        if(prefs!=null){StringBuilder b=new StringBuilder();for(PersistedAttempt q:localHistory){if(b.length()>0)b.append('\n');b.append(q.whenMs).append('|').append(safePipe(q.trickName)).append('|').append(safePipe(q.grade)).append('|').append(q.points).append('|').append(String.format(Locale.US,"%.6f",q.turns)).append('|').append(q.saturated).append('|').append(String.format(Locale.US,"%.4f",q.axisPurity)).append('|').append(safePipe(q.finishGrade)).append('|').append(safePipe(q.controlGrade)).append('|').append(safePipe(q.resultLabel));}prefs.edit().putString(PREF_HISTORY,b.toString()).apply();}
    }

    private String safePipe(String s){return s==null?"":s.replace("|","/").replace("\n"," ");}
    private PersistedAttempt bestPersistedAttempt(){PersistedAttempt best=null;for(PersistedAttempt p:localHistory)if(best==null||p.points>best.points)best=p;return best;}
    private PersistedAttempt bestForTrick(String name){PersistedAttempt best=null;for(PersistedAttempt p:localHistory)if(p.trickName.equalsIgnoreCase(name)&&(best==null||p.points>best.points))best=p;return best;}

    @Override
    public void onBackPressed() {
        if (monitoring) {
            Toast.makeText(this, "Sessão protegida: segure o botão para parar.", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!"HOME".equals(currentScreen)){showHomeScreen();return;} super.onBackPressed();
    }

    private TextView metric(String value) {
        TextView t = text(value, 13, C_WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(11), dp(6), dp(11));
        t.setBackground(roundRect(C_PANEL, 14));
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(C_WHITE);
        b.setBackground(strokeRect(C_PANEL, Color.rgb(70,71,76), 14, 1));
        return b;
    }

    private void toggleMonitoring() {
        if (monitoring) stopMonitoring(); else startMonitoring();
    }

    private void startMonitoring() {
        if (accelerometer == null || gyroscope == null) return;
        monitoring = true; attemptActive = false; currentAttempt = null; lastGyroTimestampNs = 0L;
        sessionStartNs = SystemClock.elapsedRealtimeNanos(); preBuffer.clear();
        logEvent("session_start", sessionStartNs, 0, "v0.5-ux-alpha;target=" + activeTrickName);
        sensorManager.registerListener(this, accelerometer, SENSOR_PERIOD_US);
        sensorManager.registerListener(this, gyroscope, SENSOR_PERIOD_US);
        if (rotationVector != null) sensorManager.registerListener(this, rotationVector, SENSOR_PERIOD_US);
        if (gameRotationVector != null) sensorManager.registerListener(this, gameRotationVector, SENSOR_PERIOD_US);
        if (magnetometer != null) sensorManager.registerListener(this, magnetometer, SENSOR_PERIOD_US);
        requestScreenPinningIfEnabled();
        setMonitoringButtonMode();
        if(statusText!=null)statusText.setText("ARMADO • MANDA " + activeTrickName);
    }

    private void stopMonitoring() {
        if (attemptActive) finishAttempt(lastGyroTimestampNs, "sessão encerrada");
        if (sessionStartNs != 0L) logEvent("session_stop", SystemClock.elapsedRealtimeNanos(), 0, "manual");
        monitoring = false; attemptActive = false; currentAttempt = null; sensorManager.unregisterListener(this);
        setStartButtonMode();
        releaseScreenPinning();
        if(statusText!=null)statusText.setText("PAUSADO");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Screen pinning can briefly move focus to system UI; do not kill the throw session for that.
        if (monitoring && !lockTaskRequested) stopMonitoring();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= 23 && lockTaskRequested) {
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null && am.getLockTaskModeState() == ActivityManager.LOCK_TASK_MODE_NONE) lockTaskRequested = false;
            } catch (Exception ignored) {}
        }
        enterImmersiveMode();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!monitoring) return;

        logRawSensorEvent(event);

        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            ax = event.values[0];
            ay = event.values[1];
            az = event.values[2];
            accelMagnitude = hypot3(ax, ay, az);
            if(accelText!=null) accelText.setText(String.format(Locale.US, "ACEL.\n%.2f g", accelMagnitude / G));
            return;
        }

        if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            mx = event.values[0];
            my = event.values[1];
            mz = event.values[2];
            magneticMagnitude = hypot3(mx, my, mz);
            magAccuracy = event.accuracy;
            return;
        }

        if (type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(latestRotationMatrix, event.values);
            hasRotationMatrix = true;
            rotAccuracy = event.accuracy;
            float[] orientation = new float[3];
            SensorManager.getOrientation(latestRotationMatrix, orientation);
            headingDeg = normalize360((float) Math.toDegrees(orientation[0]));
            if(headingText!=null) headingText.setText(String.format(Locale.US, "NORTE\n%03.0f°", headingDeg));
            return;
        }

        if (type == Sensor.TYPE_GAME_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(latestGameRotationMatrix, event.values);
            hasGameRotationMatrix = true;
            return;
        }

        if (type == Sensor.TYPE_GYROSCOPE) {
            handleGyroscope(event);
        }
    }

    private void handleGyroscope(SensorEvent event) {
        float gx = event.values[0];
        float gy = event.values[1];
        float gz = event.values[2];
        float mag = hypot3(gx, gy, gz);
        liveGyroDegS = (float) Math.toDegrees(mag);
        if(gyroText!=null) gyroText.setText(String.format(Locale.US, "GIRO\n%.0f °/s", liveGyroDegS));

        long ts = event.timestamp;
        Frame frame = buildFrame(ts, gx, gy, gz, mag);
        addPreBuffer(frame);

        if (!attemptActive && mag >= START_GYRO_RAD_S) beginAttempt(ts);
        if (!attemptActive || currentAttempt == null) {
            lastGyroTimestampNs = ts;
            return;
        }

        if (currentAttempt.frames.isEmpty() || currentAttempt.frames.get(currentAttempt.frames.size() - 1).timestampNs != ts) {
            currentAttempt.frames.add(frame.copy());
        }

        if (mag >= STOP_GYRO_RAD_S) lastAboveStopNs = ts;
        long durationNs = ts - attemptStartNs;
        if(statusText!=null) statusText.setText(String.format(Locale.US,
                "CAPTURANDO #%d  •  %.0f°/s%s",
                attemptCount + 1,
                liveGyroDegS,
                isGyroSaturated(gx, gy, gz) ? "  MAX" : ""));

        boolean calmLongEnough = durationNs > MIN_ATTEMPT_NS && (ts - lastAboveStopNs) > STOP_HOLD_NS;
        boolean timedOut = durationNs > MAX_ATTEMPT_NS;
        if (calmLongEnough || timedOut) finishAttempt(ts, timedOut ? "timeout" : "estabilizou");

        lastGyroTimestampNs = ts;
    }

    private Frame buildFrame(long ts, float gx, float gy, float gz, float gyroMag) {
        Frame f = new Frame();
        f.timestampNs = ts;
        f.sessionMs = sessionStartNs == 0L ? 0.0 : (ts - sessionStartNs) / 1_000_000.0;
        f.gx = gx; f.gy = gy; f.gz = gz; f.gyroMag = gyroMag;
        f.ax = ax; f.ay = ay; f.az = az; f.accelMag = accelMagnitude;
        f.accelSaturated = isAccelSaturated(ax, ay, az);
        f.mx = mx; f.my = my; f.mz = mz; f.magMag = magneticMagnitude;
        f.headingDeg = headingDeg;
        f.gyroSaturated = isGyroSaturated(gx, gy, gz);
        f.rotAccuracy = rotAccuracy;
        f.magAccuracy = magAccuracy;
        float[] src = hasGameRotationMatrix ? latestGameRotationMatrix : latestRotationMatrix;
        f.hasOrientation = hasGameRotationMatrix || hasRotationMatrix;
        System.arraycopy(src, 0, f.rotationMatrix, 0, 9);
        return f;
    }

    private void addPreBuffer(Frame f) {
        preBuffer.addLast(f.copy());
        long minTs = f.timestampNs - PREBUFFER_NS;
        while (!preBuffer.isEmpty() && preBuffer.peekFirst().timestampNs < minTs) preBuffer.removeFirst();
    }

    private void beginAttempt(long ts) {
        attemptActive = true;
        attemptStartNs = ts;
        lastAboveStopNs = ts;
        currentAttempt = new Attempt();
        candidateCount++;
        currentAttempt.candidateId = candidateCount;
        currentAttempt.index = attemptCount + 1;
        currentAttempt.targetTrickName = activeTrickName;
        currentAttempt.startTimestampNs = ts;
        currentAttempt.startSessionMs = sessionMs(ts);
        for (Frame f : preBuffer) currentAttempt.frames.add(f.copy());
        logEvent("candidate_start", ts, 0, "candidate=" + currentAttempt.candidateId + "; gyro_trigger");
        if(statusText!=null) statusText.setText("CAPTURANDO #" + currentAttempt.index);
    }

    private void finishAttempt(long ts, String closeReason) {
        if (!attemptActive || currentAttempt == null) return;
        attemptActive = false;
        currentAttempt.endTimestampNs = ts;
        currentAttempt.endSessionMs = sessionMs(ts);
        currentAttempt.closeReason = closeReason;
        analyzeAttempt(currentAttempt);

        Attempt saved = currentAttempt;
        currentAttempt = null;

        if (!saved.validMotion) {
            discardedCandidates.add(saved);
            logEvent("candidate_discarded", ts, 0, String.format(Locale.US,
                    "candidate=%d; main_turns=%.2f; peak=%.0fdeg/s",
                    saved.candidateId, saved.spinWindowTurnsLowerBound, saved.peakGyroDegS));
            if(statusText!=null) statusText.setText("MOVIMENTO IGNORADO • não foi uma tentativa válida");
            return;
        }

        saved.index = attemptCount + 1;
        attempts.add(saved);
        attemptCount++;
        persistAttemptSummary(saved);
        logEvent("attempt_end", ts, saved.index, closeReason);
        renderAttempts();
        renderLastResult(saved);
        if(statusText!=null) statusText.setText(String.format(Locale.US, "#%d SALVO • %s • GRADE %s",
                saved.index, saved.trickName, saved.overallGrade));
        vibrateCapture();
    }

    private void analyzeAttempt(Attempt a) {
        if (a.frames.size() < 2) return;

        double totalPath = 0;
        double accelSatMs = 0;
        double lowGMs = 0;
        float minAccel = Float.MAX_VALUE;
        float peakAccel = 0;
        ArrayList<Double> gyroIntervalsMs = new ArrayList<>();

        Frame prev = null;
        for (Frame f : a.frames) {
            if (f.timestampNs < a.startTimestampNs) { prev = f; continue; }
            if (prev == null) { prev = f; continue; }
            double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - prev.timestampNs) / 1_000_000_000.0));
            double dtMs = dt * 1000.0;
            if (dt <= 0) { prev = f; continue; }
            gyroIntervalsMs.add(dtMs);
            minAccel = Math.min(minAccel, f.accelMag);
            peakAccel = Math.max(peakAccel, f.accelMag);
            totalPath += f.gyroMag * dt;
            if (f.accelSaturated) accelSatMs += dtMs;
            if (f.accelMag < LOW_G_THRESHOLD) lowGMs += dtMs;
            prev = f;
        }

        ArrayList<SpinSegment> segments = buildSpinSegments(a);
        SpinSegment main = null;
        for (SpinSegment seg : segments) {
            if (main == null || seg.pathRad > main.pathRad) main = seg;
        }
        if (main == null) main = new SpinSegment();

        double axisSum = main.absX + main.absY + main.absZ;
        String dominant = "X";
        double dominantVal = main.absX;
        if (main.absY > dominantVal) { dominant = "Y"; dominantVal = main.absY; }
        if (main.absZ > dominantVal) { dominant = "Z"; dominantVal = main.absZ; }
        double purity = axisSum > 0 ? dominantVal / axisSum : 0;

        a.durationMs = (a.endTimestampNs - a.startTimestampNs) / 1_000_000.0;
        a.totalTurnsLowerBound = totalPath / (Math.PI * 2.0);
        a.spinWindowTurnsLowerBound = main.pathRad / (Math.PI * 2.0);
        a.spinRateLowerBoundRps = main.peakGyro / (Math.PI * 2.0);
        a.saturationOnlyTurnsFloor = (main.satMs / 1000.0) * (getGyroMaxRange() * SATURATION_FRACTION) / (Math.PI * 2.0);
        a.orientationPathTurnsEstimate = main.orientationPath / (Math.PI * 2.0);
        a.magVectorPathTurnsIndicator = main.magVectorPath / (Math.PI * 2.0);
        a.highSpinMs = main.highSpinMs;
        a.mainSpinDurationMs = main.startNs == 0 || main.endNs == 0 ? 0 : (main.endNs - main.startNs) / 1_000_000.0;
        a.saturationMs = main.satMs;
        a.saturationPctOfHighSpin = main.highSpinMs > 0 ? (main.satMs / main.highSpinMs) * 100.0 : 0;
        a.saturated = main.satMs >= 8.0 || main.peakGyro >= getGyroMaxRange() * SATURATION_FRACTION;
        a.accelSaturated = accelSatMs >= 4.0;
        a.accelSaturationMs = accelSatMs;
        a.peakGyroDegS = Math.toDegrees(main.peakGyro);
        a.minAccelG = minAccel == Float.MAX_VALUE ? 0 : minAccel / G;
        a.peakAccelG = peakAccel / G;
        a.lowGMs = lowGMs;
        a.lowGCandidate = lowGMs >= 20.0;
        a.dominantAxis = dominant;
        a.axisPurityPct = purity * 100.0;
        a.highSpinStartMs = main.startNs == 0 ? Double.NaN : sessionMs(main.startNs);
        a.highSpinEndMs = main.endNs == 0 ? Double.NaN : sessionMs(main.endNs);
        a.catchCandidateMs = main.endNs == 0 ? Double.NaN : sessionMs(main.endNs);
        a.headingStartDeg = headingAtOrBefore(a, a.startTimestampNs);
        a.headingEndDeg = headingAtOrBefore(a, a.endTimestampNs);
        a.sampleCount = a.frames.size();

        if (!gyroIntervalsMs.isEmpty()) {
            java.util.Collections.sort(gyroIntervalsMs);
            a.sampleDtMedianMs = percentile(gyroIntervalsMs, 0.50);
            a.sampleDtP95Ms = percentile(gyroIntervalsMs, 0.95);
            a.sampleDtMaxMs = gyroIntervalsMs.get(gyroIntervalsMs.size() - 1);
        }

        analyzeFinishAndLanding(a, main);
        estimateTrajectory(a, main);

        // A trick must be more than ordinary hand movement. This rule intentionally describes a minimum
        // viable Flip Flat, not an elite score. Rejected candidates remain in the calibration export.
        a.validMotion = a.spinWindowTurnsLowerBound >= CONFIRM_MAIN_TURNS
                && main.peakGyro >= CONFIRM_PEAK_RAD_S
                && a.mainSpinDurationMs >= 180.0;
        a.flipFlatRecognized = a.validMotion && "Y".equals(a.dominantAxis) && a.axisPurityPct >= 35.0;
        boolean targetingOfficial = a.targetTrickName == null || "FLIP FLAT".equalsIgnoreCase(a.targetTrickName);
        a.targetedPrototype = a.validMotion && !targetingOfficial;
        a.trickName = a.targetedPrototype ? a.targetTrickName : (a.flipFlatRecognized ? "FLIP FLAT" : (a.validMotion ? "NÃO RECONHECIDA" : "MOVIMENTO"));

        a.spinGrade = gradeSpin(a);
        a.axisGrade = gradeAxis(purity);
        a.finishGrade = gradeFinish(a);
        a.catchGrade = gradeControl(a);
        a.overallGrade = (a.flipFlatRecognized && targetingOfficial) ? overallGrade(a) : (a.targetedPrototype ? "CAL" : "—");
        a.styleLabel = styleLabel(a);

        if (a.mainSpinDurationMs >= 250 && a.mainSpinDurationMs <= 900 && a.axisPurityPct >= 65) {
            a.flightTimeCandidateMs = a.mainSpinDurationMs;
            double t = a.flightTimeCandidateMs / 1000.0;
            a.heightCandidateCm = (G * t * t / 8.0) * 100.0;
        }
        a.points = calculatePoints(a);

        if (main.startNs != 0) logEvent("main_spin_start", main.startNs, 0,
                "candidate=" + a.candidateId + "; threshold=" + HIGH_SPIN_RAD_S);
        if (main.endNs != 0) logEvent("main_spin_end", main.endNs, 0,
                "candidate=" + a.candidateId);
        if (a.saturated) logEvent("gyro_saturation", main.startNs == 0 ? a.startTimestampNs : main.startNs,
                0, String.format(Locale.US, "candidate=%d; %.1fms; turns>%.3f; rps>%.3f",
                        a.candidateId, a.saturationMs, a.spinWindowTurnsLowerBound, a.spinRateLowerBoundRps));
        if (a.dropSuspected) logEvent("possible_drop", main.endNs == 0 ? a.endTimestampNs : main.endNs,
                0, "candidate=" + a.candidateId + "; post-chaos heuristic");
    }

    private ArrayList<SpinSegment> buildSpinSegments(Attempt a) {
        ArrayList<SpinSegment> result = new ArrayList<>();
        SpinSegment current = null;
        Frame previousHigh = null;
        for (Frame f : a.frames) {
            if (f.timestampNs < a.startTimestampNs || f.gyroMag < HIGH_SPIN_RAD_S) continue;
            if (current == null || previousHigh == null || f.timestampNs - previousHigh.timestampNs > MAIN_SPIN_GAP_NS) {
                current = new SpinSegment();
                current.startNs = f.timestampNs;
                result.add(current);
                previousHigh = null;
            }
            current.endNs = f.timestampNs;
            current.peakGyro = Math.max(current.peakGyro, f.gyroMag);
            if (previousHigh != null) {
                double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - previousHigh.timestampNs) / 1_000_000_000.0));
                double dtMs = dt * 1000.0;
                current.pathRad += f.gyroMag * dt;
                current.highSpinMs += dtMs;
                current.absX += Math.abs(f.gx) * dt;
                current.absY += Math.abs(f.gy) * dt;
                current.absZ += Math.abs(f.gz) * dt;
                if (f.gyroSaturated) current.satMs += dtMs;
                if (previousHigh.hasOrientation && f.hasOrientation)
                    current.orientationPath += rotationDeltaAngle(previousHigh.rotationMatrix, f.rotationMatrix);
                if (previousHigh.magMag > 5f && f.magMag > 5f)
                    current.magVectorPath += vectorDeltaAngle(previousHigh.mx, previousHigh.my, previousHigh.mz, f.mx, f.my, f.mz);
            }
            previousHigh = f;
        }
        return result;
    }

    private void analyzeFinishAndLanding(Attempt a, SpinSegment main) {
        if (main.startNs == 0 || main.endNs == 0) return;

        double[] preNormal = averageDeviceNormal(a, main.startNs - 350_000_000L, main.startNs - 80_000_000L);
        double[] postNormal = averageDeviceNormal(a, main.endNs + 100_000_000L, main.endNs + 700_000_000L);
        if (preNormal != null && postNormal != null) {
            double dot = clamp(preNormal[0] * postNormal[0] + preNormal[1] * postNormal[1] + preNormal[2] * postNormal[2], -1, 1);
            a.finishNormalDeltaDeg = Math.toDegrees(Math.acos(dot));
            a.sameFaceFinish = dot > 0;
        }

        long postEnd = Math.min(a.endTimestampNs, main.endNs + 700_000_000L);
        Frame prev = null;
        double path = 0;
        double maxG = 0;
        int impactCount = 0;
        long lastImpactNs = Long.MIN_VALUE / 4;
        for (Frame f : a.frames) {
            if (f.timestampNs < main.endNs || f.timestampNs > postEnd) continue;
            if (prev != null) {
                double dt = Math.max(0.0, Math.min(0.05, (f.timestampNs - prev.timestampNs) / 1_000_000_000.0));
                path += f.gyroMag * dt;
            }
            double g = f.accelMag / G;
            maxG = Math.max(maxG, g);
            if (g >= 4.0 && f.timestampNs - lastImpactNs > 70_000_000L) {
                impactCount++;
                lastImpactNs = f.timestampNs;
            }
            prev = f;
        }
        a.postSpinTurns700Ms = path / (Math.PI * 2.0);
        a.catchAccelG = maxG;
        a.secondaryImpactCount = impactCount;
        a.settleAfterMainMs = Math.max(0, (a.endTimestampNs - main.endNs) / 1_000_000.0);
        a.dropSuspected = (impactCount >= 2 && (a.postSpinTurns700Ms >= 0.28 || maxG >= 15.0)) || (a.postSpinTurns700Ms >= 1.1 && a.settleAfterMainMs > 700);
    }

    private void estimateTrajectory(Attempt a, SpinSegment main) {
        if(main.startNs==0||main.endNs==0)return;
        double[] base={0,0,0}; int bn=0;
        for(Frame f:a.frames){if(!f.hasOrientation||f.timestampNs<main.startNs-350_000_000L||f.timestampNs>main.startNs-70_000_000L||f.gyroMag>2.0f)continue;double[] w=worldAccel(f);base[0]+=w[0];base[1]+=w[1];base[2]+=w[2];bn++;}
        if(bn<3){base[2]=G;bn=1;} base[0]/=bn;base[1]/=bn;base[2]/=bn;
        double vx=0,vy=0,vz=0,px=0,py=0,pz=0,maxH=0,maxZ=0;Frame prev=null;
        for(Frame f:a.frames){if(!f.hasOrientation||f.timestampNs<main.startNs||f.timestampNs>main.endNs)continue;if(prev==null){prev=f;continue;}double dt=Math.max(0,Math.min(.025,(f.timestampNs-prev.timestampNs)/1e9));double[] w=worldAccel(f);double lx=w[0]-base[0],ly=w[1]-base[1],lz=w[2]-base[2];double lm=Math.sqrt(lx*lx+ly*ly+lz*lz);if(lm>6*G){double sc=6*G/lm;lx*=sc;ly*=sc;lz*=sc;}vx+=lx*dt;vy+=ly*dt;vz+=lz*dt;px+=vx*dt;py+=vy*dt;pz+=vz*dt;maxH=Math.max(maxH,Math.sqrt(px*px+py*py));maxZ=Math.max(maxZ,Math.abs(pz));prev=f;}
        a.trajectoryXcm=px*100;a.trajectoryYcm=py*100;a.trajectoryZcm=pz*100;a.trajectoryHorizontalCm=maxH*100;a.trajectoryVerticalCm=maxZ*100;
        double h=Math.sqrt(px*px+py*py),v=Math.abs(pz);if(h<.03&&v<.03)a.trajectoryLabel="INCERTA";else if(v>h*1.6)a.trajectoryLabel="VERTICAL";else if(h>v*1.6)a.trajectoryLabel="LATERAL";else a.trajectoryLabel="MISTA";
    }

    private double[] worldAccel(Frame f){return new double[]{f.rotationMatrix[0]*f.ax+f.rotationMatrix[1]*f.ay+f.rotationMatrix[2]*f.az,f.rotationMatrix[3]*f.ax+f.rotationMatrix[4]*f.ay+f.rotationMatrix[5]*f.az,f.rotationMatrix[6]*f.ax+f.rotationMatrix[7]*f.ay+f.rotationMatrix[8]*f.az};}

    private double[] averageDeviceNormal(Attempt a, long fromNs, long toNs) {
        double x = 0, y = 0, z = 0;
        int n = 0;
        for (Frame f : a.frames) {
            if (!f.hasOrientation || f.timestampNs < fromNs || f.timestampNs > toNs || f.gyroMag > 1.2f) continue;
            // Third column of the device->world rotation matrix is the screen-normal axis in world coordinates.
            x += f.rotationMatrix[2]; y += f.rotationMatrix[5]; z += f.rotationMatrix[8]; n++;
        }
        if (n < 4) return null;
        double norm = Math.sqrt(x*x + y*y + z*z);
        if (norm < 1e-6) return null;
        return new double[]{x/norm, y/norm, z/norm};
    }

    private double clamp(double value, double lo, double hi) {
        return Math.max(lo, Math.min(hi, value));
    }

    private String gradeSpin(Attempt a) {
        double turns = a.spinWindowTurnsLowerBound;
        double rps = a.spinRateLowerBoundRps;
        if (turns >= 3.0 && (a.saturated || rps >= 5.8)) return "S";
        if (turns >= 2.2 && rps >= 4.5) return "A";
        if (turns >= 1.3 && rps >= 3.2) return "B";
        return "C";
    }

    private String gradeAxis(double purity) {
        if (purity >= 0.92) return "S";
        if (purity >= 0.80) return "A";
        if (purity >= 0.65) return "B";
        return "C";
    }

    private String gradeFinish(Attempt a) {
        if (Double.isNaN(a.finishNormalDeltaDeg)) return "?";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 20) return "S";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 45) return "A";
        if (a.sameFaceFinish && a.finishNormalDeltaDeg <= 75) return "B";
        return "C";
    }

    private String gradeControl(Attempt a) {
        if ("CAIU".equals(a.userRating)) return "F";
        if (a.postSpinTurns700Ms < 0.25 && a.settleAfterMainMs < 1000) return "S";
        if (a.postSpinTurns700Ms < 0.45 && a.settleAfterMainMs < 1400) return "A";
        if (a.postSpinTurns700Ms < 0.80 && a.settleAfterMainMs < 2100) return "B";
        return "C";
    }

    private String overallGrade(Attempt a) {
        if ("CAIU".equals(a.userRating)) return "F";
        // Closed-alpha rule: overall is the weakest VALIDATED criterion. Finish is visible and contributes
        // to points, but does not cap the letter grade until video ground-truth validates it.
        int min = Math.min(gradeValue(a.spinGrade), Math.min(gradeValue(a.axisGrade), gradeValue(a.catchGrade)));
        if (min >= 4) return "S"; if (min == 3) return "A"; if (min == 2) return "B"; return "C";
    }

    private int calculatePoints(Attempt a) {
        if("F".equals(a.overallGrade)||"CAIU".equals(a.userRating))return 0;
        int base="S".equals(a.overallGrade)?8000:"A".equals(a.overallGrade)?6000:"B".equals(a.overallGrade)?3000:"C".equals(a.overallGrade)?1000:0;
        int axis=(int)Math.round(clamp(a.axisPurityPct/100.0,0,1)*500);
        int turns=(int)Math.round(clamp(a.spinWindowTurnsLowerBound/5.0,0,1)*450);
        int air=Double.isNaN(a.flightTimeCandidateMs)?0:(int)Math.round(clamp(a.flightTimeCandidateMs/1200.0,0,1)*350);
        int finish="S".equals(a.finishGrade)?300:"A".equals(a.finishGrade)?230:"B".equals(a.finishGrade)?150:"C".equals(a.finishGrade)?70:0;
        int ctrl="S".equals(a.catchGrade)?400:"A".equals(a.catchGrade)?300:"B".equals(a.catchGrade)?200:"C".equals(a.catchGrade)?100:0;
        int raw=base+axis+turns+air+finish+ctrl;return Math.min(9999,raw);
    }

    private int gradeValue(String grade) {
        if ("S".equals(grade)) return 4;
        if ("A".equals(grade)) return 3;
        if ("B".equals(grade)) return 2;
        return 1;
    }

    private String styleLabel(Attempt a) {
        if (!a.validMotion) return "MOVIMENTO";
        if (a.targetedPrototype) return "ALVO: " + a.targetTrickName;
        if (!a.flipFlatRecognized) return "NOVA MANOBRA?";
        if ("CAIU".equals(a.userRating)) return "FALHA / QUEDA";
        if (a.axisPurityPct >= 92 && a.spinGrade.equals("S")) return "AXIS LOCK";
        if (a.saturated && a.axisPurityPct >= 80) return "MAX SPIN";
        if (a.axisPurityPct >= 82) return "CLEAN FLAT";
        if (a.axisPurityPct < 58) return "WILD FLAT";
        if ("S".equals(a.catchGrade)) return "CLEAN CATCH";
        return "SOLID FLAT";
    }

    private void renderLastResult(Attempt a) {
        if (lastResultContainer == null) {
            if (lastResultText != null) lastResultText.setText(buildAttemptCardText(a));
            return;
        }
        lastResultContainer.removeAllViews();
        inlineReplayAttempt=a;
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(14),dp(14),dp(14));
        int border="S".equals(a.overallGrade)?C_ACID:Color.rgb(65,66,70);card.setBackground(strokeRect(C_PANEL,border,16,"S".equals(a.overallGrade)?2:1));
        String grade=a.targetedPrototype?"CAL":a.overallGrade;
        TextView top=text(String.format(Locale.US,"%s   •   %s   •   %,d PTS",a.trickName,grade,a.points),20,C_WHITE,true);top.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD_ITALIC));card.addView(top);
        TextView label=text(a.styleLabel,11,a.targetedPrototype?C_MUTED:C_ACID,true);label.setLetterSpacing(.08f);label.setPadding(0,0,0,dp(10));card.addView(label);

        LinearLayout grades=new LinearLayout(this);grades.setOrientation(LinearLayout.HORIZONTAL);grades.setWeightSum(4f);
        grades.addView(statTile(a.spinGrade,"SPIN"),weighted());grades.addView(statTile(a.axisGrade,"EIXO"),weightedWithLeftMargin(dp(5)));grades.addView(statTile(a.finishGrade,"FINAL*"),weightedWithLeftMargin(dp(5)));grades.addView(statTile(a.catchGrade,"CTRL"),weightedWithLeftMargin(dp(5)));card.addView(grades,lpMatch(dp(10)));

        TextView nums=text(String.format(Locale.US,"GIROS %s   •   %s   •   EIXO %.0f%%   •   %s*%s",formatTurnsForUser(a),formatSpinRateForUser(a),a.axisPurityPct,a.trajectoryLabel,a.dropSuspected?"   •   QUEDA?":""),10,C_WHITE,true);nums.setPadding(0,0,0,dp(8));card.addView(nums);
        TextView replayH=text("SEU REPLAY 3D",10,C_MUTED,true);replayH.setLetterSpacing(.10f);card.addView(replayH);
        inlineReplay=new ReplayView(this,a);inlineReplay.setBackground(roundRect(Color.rgb(10,11,13),14));card.addView(inlineReplay,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(250)));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setWeightSum(2f);
        Button again=ghostButton("↻  REPLAY");again.setTextSize(11);again.setOnClickListener(v->{if(monitoring)inlineReplay.startReplay();else inlineReplay.startReplay();});actions.addView(again,weighted());
        Button details=ghostButton("DETALHES  ›");details.setTextSize(11);details.setOnClickListener(v->{if(monitoring)Toast.makeText(this,"Segure para pausar antes de abrir os detalhes.",Toast.LENGTH_SHORT).show();else showAttemptDetail(a);});actions.addView(details,weightedWithLeftMargin(dp(6)));card.addView(actions,lpMatch(0));
        lastResultContainer.addView(card);
        inlineReplay.startReplay();
    }

    private void renderAttempts() {
        if(attemptsContainer==null)return; attemptsContainer.removeAllViews();
        if(sessionCountText!=null)sessionCountText.setText(attempts.size()+(attempts.size()==1?" tentativa":" tentativas"));
        if(exportButton!=null)exportButton.setEnabled(!attempts.isEmpty()||!discardedCandidates.isEmpty()||!trickProposals.isEmpty());
        if(attempts.isEmpty()){TextView empty=text("Nenhuma tentativa nesta sessão.",12,C_MUTED,false);empty.setPadding(dp(14),dp(12),dp(14),dp(12));empty.setBackground(roundRect(C_PANEL,14));attemptsContainer.addView(empty,lpMatch(dp(8)));return;}
        int shown=0;for(int i=attempts.size()-1;i>=0&&shown<8;i--,shown++){Attempt a=attempts.get(i);TextView card=text(buildAttemptCardText(a),12,C_WHITE,true);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(roundRect(C_PANEL,14));card.setOnClickListener(v->{if(!monitoring)showAttemptDetail(a);});attemptsContainer.addView(card,lpMatch(dp(7)));}
    }

    private String buildAttemptCardText(Attempt a) {
        String rating=a.userRating==null?"":("  •  "+a.userRating);
        String grade=a.targetedPrototype?"CAL":a.overallGrade;
        return String.format(Locale.US,"#%02d  %s  •  %s  •  %,d PTS%s\nGIROS %s  |  EIXO %.0f%%  |  %s*",a.index,a.trickName,grade,a.points,rating,formatTurnsForUser(a),a.axisPurityPct,a.trajectoryLabel);
    }

    private String formatTurnsForUser(Attempt a) {
        if (a.saturated) return String.format(Locale.US, "> %.2f", a.spinWindowTurnsLowerBound);
        return String.format(Locale.US, "~ %.2f", a.spinWindowTurnsLowerBound);
    }

    private String formatSpinRateForUser(Attempt a) {
        if (a.saturated) return String.format(Locale.US, "> %.1f giros/s", a.spinRateLowerBoundRps);
        return String.format(Locale.US, "~ %.1f giros/s", a.spinRateLowerBoundRps);
    }

    private void showAttemptDetail(Attempt a) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(26));
        scroll.addView(root);

        TextView title = text(String.format(Locale.US, "#%02d  •  %s  •  %s  •  %,d PTS", a.index, a.trickName, a.overallGrade, a.points),
                25, Color.WHITE, true);
        root.addView(title);
        TextView label = text(a.styleLabel + "  •  classificação em evolução", 14,
                Color.rgb(146, 255, 186), true);
        label.setPadding(0, 0, 0, dp(12));
        root.addView(label);

        TextView replayHeader = text("REPLAY SENSORIAL", 13, Color.rgb(190, 196, 207), true);
        root.addView(replayHeader);
        ReplayView replay = new ReplayView(this, a);
        replay.setBackground(roundRect(Color.rgb(20, 22, 27), 14));
        root.addView(replay, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        Button replayButton = smallButton("▶  REPLAY EM SLOW MOTION");
        replayButton.setOnClickListener(v -> replay.startReplay());
        root.addView(replayButton, lpMatch(dp(10)));

        TimelineView timeline = new TimelineView(this, a);
        timeline.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(timeline, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)));

        TextView note = text(
                "Replay = orientação + referência fixa do chão. O deslocamento é uma estimativa inercial experimental (*), útil para diferenciar vertical/lateral; o bloco principal continua sendo o que alimenta a pontuação.",
                11, Color.rgb(157, 161, 171), false);
        note.setPadding(dp(2), dp(6), dp(2), dp(12));
        root.addView(note);

        TextView ratingTitle = text("COMO VOCÊ AVALIA ESSA EXECUÇÃO?", 12, Color.WHITE, true);
        root.addView(ratingTitle);
        LinearLayout ratings = new LinearLayout(this);
        ratings.setOrientation(LinearLayout.HORIZONTAL);
        ratings.setWeightSum(4f);
        root.addView(ratings, lpMatch(dp(12)));
        String[] names = {"BOA", "MÉDIA", "RUIM", "CAIU"};
        for (String r : names) {
            Button b = smallButton(r);
            b.setOnClickListener(v -> {
                a.userRating = r;
                a.catchGrade = gradeControl(a);
                a.overallGrade = (a.flipFlatRecognized && !a.targetedPrototype) ? overallGrade(a) : (a.targetedPrototype ? "CAL" : "—");
                a.styleLabel = styleLabel(a);
                a.points = calculatePoints(a);
                refreshPersistedAttempt(a);
                renderAttempts();
                renderLastResult(a);
                Toast.makeText(this, "Avaliação salva: " + r, Toast.LENGTH_SHORT).show();
            });
            ratings.addView(b, ratings.getChildCount() == 0 ? weighted() : weightedWithLeftMargin(dp(4)));
        }

        Button propose = smallButton(a.proposedTrickName == null ? "+  PROPOR NOVA MANOBRA" : "✓  PROPOSTA: " + a.proposedTrickName);
        propose.setOnClickListener(v -> showProposalDialog(a));
        root.addView(propose, lpMatch(dp(12)));

        TextView stats = text(buildTechnicalStats(a), 12, Color.rgb(225, 229, 236), false);
        stats.setTypeface(Typeface.MONOSPACE);
        stats.setPadding(dp(12), dp(12), dp(12), dp(12));
        stats.setBackground(roundRect(Color.rgb(24, 25, 30), 12));
        root.addView(stats, lpMatch(dp(12)));

        TextView gyroH = text("GIROSCÓPIO X / Y / Z", 12, Color.rgb(190, 196, 207), true);
        root.addView(gyroH);
        SensorChartView gyroChart = new SensorChartView(this, a, SensorChartView.MODE_GYRO);
        gyroChart.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(gyroChart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));

        TextView accelH = text("ACELERAÇÃO TOTAL", 12, Color.rgb(190, 196, 207), true);
        accelH.setPadding(0, dp(12), 0, 0);
        root.addView(accelH);
        SensorChartView accelChart = new SensorChartView(this, a, SensorChartView.MODE_ACCEL);
        accelChart.setBackground(roundRect(Color.rgb(20, 22, 27), 12));
        root.addView(accelChart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(180)));

        Button close = smallButton("FECHAR");
        close.setOnClickListener(v -> dialog.dismiss());
        root.addView(close, lpMatch(0));

        dialog.setContentView(scroll);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
        if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        replay.startReplay();
    }

    private String buildTechnicalStats(Attempt a) {
        String air = Double.isNaN(a.flightTimeCandidateMs) ? "—" :
                String.format(Locale.US, "~%.0f ms / ~%.0f cm*", a.flightTimeCandidateMs, a.heightCandidateCm);
        String finish = Double.isNaN(a.finishNormalDeltaDeg) ? "—" :
                String.format(Locale.US, "%.1f deg / %s", a.finishNormalDeltaDeg, a.sameFaceFinish ? "same face" : "opposite face");
        return String.format(Locale.US,
                "PRODUCT + CALIBRATION\n" +
                "trick / recognized %s / %s\n" +
                "overall grade      %s  /  points %,d\n" +
                "spin/axis/final/ctrl %s / %s / %s / %s\n" +
                "dominant axis      %s (%.1f%% purity)\n" +
                "peak gyro          %.1f deg/s%s\n" +
                "spin rate          %s\n" +
                "main spin duration %.1f ms\n" +
                "turn estimate      %s giros\n" +
                "gyro saturation    %s  %.1f ms (%.1f%% main spin)\n" +
                "orientation path   %.3f turn-eq\n" +
                "mag vector path    %.3f turn-eq (cross-check)\n" +
                "finish return      %s\n" +
                "trajectory est.    %s  x %.1fcm y %.1fcm z %.1fcm*\n" +
                "post-spin turns    %.3f / 700ms\n" +
                "settle after spin  %.1f ms\n" +
                "secondary impacts  %d  | possible drop %s\n" +
                "air/height cand.   %s\n" +
                "accel min / peak   %.3fg / %.3fg%s\n" +
                "sample dt med/p95  %.2f / %.2f ms\n" +
                "sample dt max      %.2f ms\n" +
                "user rating        %s\n" +
                "*height assumes catch near launch height; calibrate with video",
                a.trickName, a.flipFlatRecognized ? "YES" : "NO", a.overallGrade, a.points,
                a.spinGrade, a.axisGrade, a.finishGrade, a.catchGrade,
                a.dominantAxis, a.axisPurityPct, a.peakGyroDegS, a.saturated ? "+" : "",
                formatSpinRateForUser(a), a.mainSpinDurationMs, formatTurnsForUser(a),
                a.saturated ? "YES" : "NO", a.saturationMs, a.saturationPctOfHighSpin,
                a.orientationPathTurnsEstimate, a.magVectorPathTurnsIndicator, finish,
                a.trajectoryLabel, a.trajectoryXcm, a.trajectoryYcm, a.trajectoryZcm,
                a.postSpinTurns700Ms, a.settleAfterMainMs, a.secondaryImpactCount,
                a.dropSuspected ? "YES" : "NO", air,
                a.minAccelG, a.peakAccelG, a.accelSaturated ? "  ACCEL MAX" : "",
                a.sampleDtMedianMs, a.sampleDtP95Ms, a.sampleDtMaxMs,
                a.userRating == null ? "—" : a.userRating);
    }

    private void showCatalogDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        scroll.addView(root);

        root.addView(text("CATÁLOGO DE MANOBRAS", 27, Color.WHITE, true));
        TextView intro = text("A modalidade começa pequena. Uma regra oficial bem entendida vale mais do que dezenas de manobras inventadas.",
                12, Color.rgb(190, 196, 207), false);
        intro.setPadding(0, dp(4), 0, dp(14)); root.addView(intro);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12)); card.setBackground(roundRect(Color.rgb(20, 31, 25), 16));
        TrickIconView icon = new TrickIconView(this);
        card.addView(icon, new LinearLayout.LayoutParams(dp(110), dp(130)));
        TextView rules = text(
                "FLIP FLAT  •  OFICIAL\n\n" +
                "• GIRO: quantidade + velocidade; saturou = >N, nunca número inventado\n" +
                "• EIXO/PLANO: pureza do eixo pontua; horizontalidade física será fixada com vídeo\n" +
                "• FINALIZAÇÃO: voltar à mesma face/orientação é desempate\n" +
                "• CONTROLE: estabilizar limpo depois da captura\n" +
                "• QUEDA: tentativa falha (detecção ainda em calibração)\n" +
                "• VOO/ALTURA: medido como candidato até validação em vídeo",
                12, Color.WHITE, false);
        rules.setPadding(dp(10), 0, 0, 0);
        card.addView(rules, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(card, lpMatch(dp(12)));

        TextView community = text("LAB DA COMUNIDADE", 13, Color.rgb(146, 255, 186), true);
        root.addView(community);
        root.addView(text("Uma execução não reconhecida pode virar proposta: nome + descrição + critérios sugeridos + telemetria da tentativa. Nesta alpha a proposta fica na sessão/CSV; depois pode ir para moderação comunitária.",
                12, Color.rgb(205, 209, 217), false), lpMatch(dp(10)));
        if (trickProposals.isEmpty()) {
            root.addView(text("Nenhuma proposta nesta sessão.", 12, Color.rgb(150, 155, 165), false), lpMatch(dp(10)));
        } else {
            for (TrickProposal tp : trickProposals) {
                TextView p = text("• " + tp.name + "  (#" + tp.sourceAttempt + ")\n" + tp.description,
                        12, Color.WHITE, false);
                p.setPadding(dp(10), dp(9), dp(10), dp(9)); p.setBackground(roundRect(Color.rgb(26, 28, 34), 12));
                root.addView(p, lpMatch(dp(7)));
            }
        }
        Button close = smallButton("FECHAR"); close.setOnClickListener(v -> dialog.dismiss()); root.addView(close, lpMatch(0));
        dialog.setContentView(scroll);
        Window w = dialog.getWindow();
        if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); }
        dialog.show(); if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void showProposalDialog(Attempt a) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(18), dp(18), dp(20));
        root.setBackgroundColor(Color.rgb(15, 16, 20));
        root.addView(text("PROPOR NOVA MANOBRA", 23, Color.WHITE, true));
        root.addView(text("A telemetria da tentativa #" + a.index + " será ligada à proposta. Descreva só o que você acha essencial; a regra pode amadurecer depois.",
                12, Color.rgb(190, 196, 207), false), lpMatch(dp(10)));

        EditText name = new EditText(this); name.setHint("Nome da manobra"); name.setTextColor(Color.WHITE); name.setHintTextColor(Color.GRAY);
        name.setSingleLine(true); name.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); name.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickName != null) name.setText(a.proposedTrickName); root.addView(name, lpMatch(dp(8)));
        EditText desc = new EditText(this); desc.setHint("Como é feita / o que a diferencia?"); desc.setTextColor(Color.WHITE); desc.setHintTextColor(Color.GRAY);
        desc.setMinLines(3); desc.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); desc.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickDescription != null) desc.setText(a.proposedTrickDescription); root.addView(desc, lpMatch(dp(8)));
        EditText criteria = new EditText(this); criteria.setHint("Critérios sugeridos (ex.: eixo X, voltar tela para cima, 2+ giros)"); criteria.setTextColor(Color.WHITE); criteria.setHintTextColor(Color.GRAY);
        criteria.setMinLines(2); criteria.setBackground(roundRect(Color.rgb(30, 32, 38), 10)); criteria.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (a.proposedTrickCriteria != null) criteria.setText(a.proposedTrickCriteria); root.addView(criteria, lpMatch(dp(10)));
        Button save = smallButton("SALVAR PROPOSTA");
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { Toast.makeText(this, "Dê um nome à manobra.", Toast.LENGTH_SHORT).show(); return; }
            a.proposedTrickName = n; a.proposedTrickDescription = desc.getText().toString().trim(); a.proposedTrickCriteria = criteria.getText().toString().trim();
            for (int i = trickProposals.size() - 1; i >= 0; i--) if (trickProposals.get(i).sourceAttempt == a.index) trickProposals.remove(i);
            TrickProposal tp = new TrickProposal(); tp.sourceAttempt = a.index; tp.name = a.proposedTrickName; tp.description = a.proposedTrickDescription; tp.criteria = a.proposedTrickCriteria;
            trickProposals.add(tp); renderAttempts(); Toast.makeText(this, "Proposta salva para exportação.", Toast.LENGTH_SHORT).show(); dialog.dismiss();
        });
        root.addView(save, lpMatch(dp(6)));
        Button cancel = smallButton("CANCELAR"); cancel.setOnClickListener(v -> dialog.dismiss()); root.addView(cancel, lpMatch(0));
        dialog.setContentView(root); Window w = dialog.getWindow(); if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show(); if (w != null) w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void runVideoSync() {
        if (!monitoring) {
            Toast.makeText(this, "Inicie a sessão antes do SYNC VÍDEO.", Toast.LENGTH_SHORT).show();
            return;
        }
        statusText.setText("SYNC VÍDEO • 3…");
        scheduleSyncTone(0, 3, ToneGenerator.TONE_PROP_BEEP);
        scheduleSyncTone(700, 2, ToneGenerator.TONE_PROP_BEEP);
        scheduleSyncTone(1400, 1, ToneGenerator.TONE_PROP_BEEP);
        handler.postDelayed(() -> {
            long ts = SystemClock.elapsedRealtimeNanos();
            if (toneGenerator != null) toneGenerator.startTone(ToneGenerator.TONE_PROP_ACK, 300);
            logEvent("sync_beep_GO", ts, 0, "video_ground_truth");
            statusText.setText("SYNC GO • agora faça as tentativas");
        }, 2100);
    }

    private void scheduleSyncTone(long delayMs, int n, int tone) {
        handler.postDelayed(() -> {
            long ts = SystemClock.elapsedRealtimeNanos();
            if (toneGenerator != null) toneGenerator.startTone(tone, 140);
            logEvent("sync_beep_" + n, ts, 0, "video_ground_truth");
            statusText.setText("SYNC VÍDEO • " + n + "…");
        }, delayMs);
    }

    private void updateSensorStatus() {
        String gyro = sensorName(gyroscope);
        String acc = sensorName(accelerometer);
        String rot = sensorName(rotationVector);
        String game = sensorName(gameRotationVector);
        String mag = sensorName(magnetometer);
        if(sensorText==null)return;
        sensorText.setText("Sensores\n" +
                "• Giroscópio: " + gyro + "\n" +
                "• Acelerômetro: " + acc + "\n" +
                "• Rotation Vector: " + rot + "\n" +
                "• Game Rotation Vector: " + game + "\n" +
                "• Magnetômetro / bússola: " + mag);
    }

    private String sensorName(Sensor s) {
        return s == null ? "AUSENTE" : s.getName();
    }

    private void clearSession() {
        if (attemptActive) return;
        attempts.clear();
        discardedCandidates.clear();
        trickProposals.clear();
        preBuffer.clear();
        rawEventLog.setLength(0);
        eventLog.setLength(0);
        rawEventCount = 0;
        rawLogTruncated = false;
        attemptCount = 0;
        candidateCount = 0;
        renderAttempts();
        if(lastResultText!=null){lastResultText.setText("ÚLTIMO RESULTADO\nFaça uma manobra para ver o resultado.");lastResultText.setBackground(roundRect(C_PANEL,14));}
        if(statusText!=null)statusText.setText(monitoring ? "ARMADO • sessão zerada" : "PRONTO");
    }

    private void exportCsv() {
        if (attempts.isEmpty() && discardedCandidates.isEmpty() && trickProposals.isEmpty()) {
            Toast.makeText(this, "Ainda não há dados para exportar.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "flipflat-v04-calibration-" + stamp + ".csv");
        startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("Sem stream de saída");
            os.write(buildCsv().getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Calibração CSV exportada.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao exportar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String buildCsv() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Flip Flat Product Alpha V0.4\n");
        sb.append("# Purpose: closed-test UX + calibration + trick-catalog growth\n");
        sb.append("# Main metrics use the strongest continuous high-spin segment; ordinary motion candidates are discarded from the product UI but kept below.\n");
        sb.append("# Saturated gyro values are lower bounds (>N), never false precision. Magnetometer/orientation remain calibration cross-checks.\n");
        sb.append("# Flight/height and drop detection are experimental until video ground-truth calibration.\n");
        sb.append("# raw_log_truncated,").append(rawLogTruncated).append("\n");
        appendSensorMeta(sb, "gyroscope", gyroscope);
        appendSensorMeta(sb, "accelerometer", accelerometer);
        appendSensorMeta(sb, "rotation_vector", rotationVector);
        appendSensorMeta(sb, "game_rotation_vector", gameRotationVector);
        appendSensorMeta(sb, "magnetometer", magnetometer);

        sb.append("\nSUMMARY\n");
        sb.append("attempt,target_trick,trick_name,recognized,overall_grade,points,style_label,spin_grade,axis_grade,finish_grade,control_grade,user_rating,duration_ms,dominant_axis,axis_purity_pct,peak_gyro_deg_s,spin_rate_lower_bound_rps,main_spin_duration_ms,main_spin_turns_lower_bound,total_turns_lower_bound,gyro_saturated,saturation_ms,saturation_pct_main_spin,orientation_path_turns_estimate,mag_vector_path_turns_indicator,finish_normal_delta_deg,same_face_finish,trajectory_label,trajectory_x_cm,trajectory_y_cm,trajectory_z_cm,post_spin_turns_700ms,settle_after_main_ms,secondary_impact_count,drop_suspected,flight_time_candidate_ms,height_candidate_cm,min_accel_g,peak_accel_g,accel_saturated,accel_saturation_ms,heading_start_deg,heading_end_deg,sample_count,sample_dt_median_ms,sample_dt_p95_ms,sample_dt_max_ms,proposed_trick_name,proposed_description,proposed_criteria,close_reason\n");
        for (Attempt a : attempts) {
            sb.append(String.format(Locale.US,
                    "%d,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%.3f,%s,%.4f,%.4f,%.6f,%.3f,%.6f,%.6f,%s,%.3f,%.3f,%.6f,%.6f,%.3f,%s,%s,%.3f,%.3f,%.3f,%.6f,%.3f,%d,%s,%.3f,%.3f,%.6f,%.6f,%s,%.3f,%.3f,%.3f,%d,%.4f,%.4f,%.4f,%s,%s,%s,%s\n",
                    a.index, csvFlat(a.targetTrickName), csvFlat(a.trickName), a.flipFlatRecognized ? "true" : "false", a.overallGrade, a.points,
                    csvFlat(a.styleLabel), a.spinGrade, a.axisGrade, a.finishGrade, a.catchGrade,
                    a.userRating == null ? "" : a.userRating, a.durationMs, a.dominantAxis,
                    a.axisPurityPct, a.peakGyroDegS, a.spinRateLowerBoundRps, a.mainSpinDurationMs,
                    a.spinWindowTurnsLowerBound, a.totalTurnsLowerBound, a.saturated ? "true" : "false",
                    a.saturationMs, a.saturationPctOfHighSpin, a.orientationPathTurnsEstimate,
                    a.magVectorPathTurnsIndicator, a.finishNormalDeltaDeg, a.sameFaceFinish ? "true" : "false",
                    csvFlat(a.trajectoryLabel), a.trajectoryXcm, a.trajectoryYcm, a.trajectoryZcm, a.postSpinTurns700Ms, a.settleAfterMainMs, a.secondaryImpactCount,
                    a.dropSuspected ? "true" : "false", a.flightTimeCandidateMs, a.heightCandidateCm,
                    a.minAccelG, a.peakAccelG, a.accelSaturated ? "true" : "false", a.accelSaturationMs,
                    a.headingStartDeg, a.headingEndDeg, a.sampleCount, a.sampleDtMedianMs,
                    a.sampleDtP95Ms, a.sampleDtMaxMs,
                    csvFlat(a.proposedTrickName == null ? "" : a.proposedTrickName),
                    csvFlat(a.proposedTrickDescription == null ? "" : a.proposedTrickDescription),
                    csvFlat(a.proposedTrickCriteria == null ? "" : a.proposedTrickCriteria),
                    csvFlat(a.closeReason)));
        }

        sb.append("\nDISCARDED_CANDIDATES\n");
        sb.append("candidate_id,duration_ms,main_turns_lower_bound,peak_gyro_deg_s,dominant_axis,axis_purity_pct,main_spin_duration_ms,close_reason\n");
        for (Attempt a : discardedCandidates) {
            sb.append(String.format(Locale.US, "%d,%.3f,%.6f,%.3f,%s,%.3f,%.3f,%s\n",
                    a.candidateId, a.durationMs, a.spinWindowTurnsLowerBound, a.peakGyroDegS,
                    a.dominantAxis, a.axisPurityPct, a.mainSpinDurationMs, csvFlat(a.closeReason)));
        }

        sb.append("\nTRICK_PROPOSALS\n");
        sb.append("source_attempt,name,description,suggested_criteria\n");
        for (TrickProposal tp : trickProposals) {
            sb.append(tp.sourceAttempt).append(',').append(csvFlat(tp.name)).append(',')
                    .append(csvFlat(tp.description)).append(',').append(csvFlat(tp.criteria)).append('\n');
        }

        sb.append("\nATTEMPT_FRAMES\n");
        sb.append("attempt,session_ms,relative_to_trigger_ms,phase,gx_rad_s,gy_rad_s,gz_rad_s,gyro_mag_rad_s,gyro_saturated,ax_ms2,ay_ms2,az_ms2,accel_mag_ms2,accel_saturated,mx_uT,my_uT,mz_uT,mag_mag_uT,heading_deg,rot_accuracy,mag_accuracy,r00,r01,r02,r10,r11,r12,r20,r21,r22\n");
        for (Attempt a : attempts) {
            for (Frame f : a.frames) {
                String phase = phaseForFrame(a, f);
                double rel = (f.timestampNs - a.startTimestampNs) / 1_000_000.0;
                sb.append(String.format(Locale.US,
                        "%d,%.3f,%.3f,%s,%.7f,%.7f,%.7f,%.7f,%s,%.7f,%.7f,%.7f,%.7f,%s,%.7f,%.7f,%.7f,%.7f,%.3f,%d,%d,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%.7f\n",
                        a.index, f.sessionMs, rel, phase,
                        f.gx, f.gy, f.gz, f.gyroMag, f.gyroSaturated ? "true" : "false",
                        f.ax, f.ay, f.az, f.accelMag, f.accelSaturated ? "true" : "false", f.mx, f.my, f.mz, f.magMag,
                        f.headingDeg, f.rotAccuracy, f.magAccuracy,
                        f.rotationMatrix[0], f.rotationMatrix[1], f.rotationMatrix[2],
                        f.rotationMatrix[3], f.rotationMatrix[4], f.rotationMatrix[5],
                        f.rotationMatrix[6], f.rotationMatrix[7], f.rotationMatrix[8]));
            }
        }

        sb.append("\nEVENT_MARKERS\n");
        sb.append("session_ms,event,attempt,detail\n");
        sb.append(eventLog);

        sb.append("\nRAW_SENSOR_EVENTS\n");
        sb.append("session_ms,sensor,accuracy,v0,v1,v2,v3,v4\n");
        sb.append(rawEventLog);
        return sb.toString();
    }

    private String phaseForFrame(Attempt a, Frame f) {
        if (f.timestampNs < a.startTimestampNs) return "PREBUFFER";
        if (!Double.isNaN(a.highSpinStartMs) && !Double.isNaN(a.highSpinEndMs)
                && f.sessionMs >= a.highSpinStartMs && f.sessionMs <= a.highSpinEndMs)
            return f.gyroSaturated ? "MAIN_SPIN_SAT" : "MAIN_SPIN";
        if (f.accelMag < LOW_G_THRESHOLD) return "LOW_G_CANDIDATE";
        if (!Double.isNaN(a.catchCandidateMs) && Math.abs(f.sessionMs - a.catchCandidateMs) < 35) return "CATCH_CANDIDATE";
        if (!Double.isNaN(a.highSpinEndMs) && f.sessionMs > a.highSpinEndMs) return "POST_SPIN";
        return "ACTIVE";
    }

    private void appendSensorMeta(StringBuilder sb, String label, Sensor s) {
        if (s == null) {
            sb.append("# sensor,").append(label).append(",ABSENT\n");
            return;
        }
        sb.append("# sensor,").append(label)
                .append(",name,").append(csvFlat(s.getName()))
                .append(",vendor,").append(csvFlat(s.getVendor()))
                .append(",version,").append(s.getVersion())
                .append(",max_range,").append(s.getMaximumRange())
                .append(",resolution,").append(s.getResolution())
                .append(",min_delay_us,").append(s.getMinDelay())
                .append("\n");
    }

    private void logRawSensorEvent(SensorEvent event) {
        if (rawEventCount >= MAX_RAW_EVENTS) {
            rawLogTruncated = true;
            return;
        }
        rawEventCount++;
        double t = sessionMs(event.timestamp);
        String name = sensorShortName(event.sensor.getType());
        float[] v = event.values;
        rawEventLog.append(String.format(Locale.US, "%.3f,%s,%d", t, name, event.accuracy));
        for (int i = 0; i < 5; i++) {
            rawEventLog.append(',');
            if (i < v.length) rawEventLog.append(String.format(Locale.US, "%.8f", v[i]));
        }
        rawEventLog.append('\n');
    }

    private String sensorShortName(int type) {
        if (type == Sensor.TYPE_GYROSCOPE) return "gyro";
        if (type == Sensor.TYPE_ACCELEROMETER) return "accel";
        if (type == Sensor.TYPE_ROTATION_VECTOR) return "rotation_vector";
        if (type == Sensor.TYPE_GAME_ROTATION_VECTOR) return "game_rotation_vector";
        if (type == Sensor.TYPE_MAGNETIC_FIELD) return "magnetometer";
        return "sensor_" + type;
    }

    private void logEvent(String event, long timestampNs, int attempt, String detail) {
        if (sessionStartNs == 0L) return;
        eventLog.append(String.format(Locale.US, "%.3f,%s,%d,%s\n",
                sessionMs(timestampNs), event, attempt, csvFlat(detail)));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (sensor == null || !monitoring) return;
        if (sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) magAccuracy = accuracy;
        if (sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) rotAccuracy = accuracy;
        logEvent("sensor_accuracy", SystemClock.elapsedRealtimeNanos(), 0,
                sensorShortName(sensor.getType()) + "=" + accuracy);
    }

    private boolean isGyroSaturated(float gx, float gy, float gz) {
        float max = getGyroMaxRange();
        if (max <= 0) return false;
        float threshold = max * SATURATION_FRACTION;
        return Math.abs(gx) >= threshold || Math.abs(gy) >= threshold || Math.abs(gz) >= threshold;
    }

    private float getGyroMaxRange() {
        return gyroscope == null ? 0f : gyroscope.getMaximumRange();
    }

    private boolean isAccelSaturated(float x, float y, float z) {
        float max = accelerometer == null ? 0f : accelerometer.getMaximumRange();
        if (max <= 0) return false;
        float threshold = max * ACCEL_SATURATION_FRACTION;
        return Math.abs(x) >= threshold || Math.abs(y) >= threshold || Math.abs(z) >= threshold;
    }

    private static double rotationDeltaAngle(float[] a, float[] b) {
        double frobenius = 0.0;
        for (int i = 0; i < 9; i++) frobenius += a[i] * b[i];
        double c = (frobenius - 1.0) * 0.5;
        c = Math.max(-1.0, Math.min(1.0, c));
        return Math.acos(c);
    }

    private static double vectorDeltaAngle(float ax, float ay, float az, float bx, float by, float bz) {
        double am = Math.sqrt(ax * ax + ay * ay + az * az);
        double bm = Math.sqrt(bx * bx + by * by + bz * bz);
        if (am < 1e-6 || bm < 1e-6) return 0.0;
        double c = (ax * bx + ay * by + az * bz) / (am * bm);
        c = Math.max(-1.0, Math.min(1.0, c));
        double angle = Math.acos(c);
        return angle < Math.toRadians(0.5) ? 0.0 : angle;
    }

    private double sessionMs(long timestampNs) {
        if (sessionStartNs == 0L) return 0.0;
        return (timestampNs - sessionStartNs) / 1_000_000.0;
    }

    private double headingAtOrBefore(Attempt a, long ts) {
        double result = Double.NaN;
        for (Frame f : a.frames) {
            if (f.timestampNs > ts) break;
            if (!Float.isNaN(f.headingDeg)) result = f.headingDeg;
        }
        return result;
    }

    private double percentile(ArrayList<Double> values, double p) {
        if (values.isEmpty()) return Double.NaN;
        int idx = (int) Math.round((values.size() - 1) * p);
        idx = Math.max(0, Math.min(values.size() - 1, idx));
        return values.get(idx);
    }

    private void vibrateCapture() {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0f, 1.12f);
        return t;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams lpMatch(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = bottomMargin;
        return p;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams weightedWithLeftMargin(int margin) {
        LinearLayout.LayoutParams p = weighted();
        p.leftMargin = margin;
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static float hypot3(float x, float y, float z) {
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    private static float normalize360(float deg) {
        float r = deg % 360f;
        if (r < 0) r += 360f;
        return r;
    }

    private static String csvFlat(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private static float[] identityMatrix() {
        return new float[]{1,0,0, 0,1,0, 0,0,1};
    }

    private static class Frame {
        long timestampNs;
        double sessionMs;
        float gx, gy, gz, gyroMag;
        float ax, ay, az, accelMag;
        boolean accelSaturated;
        float mx, my, mz, magMag;
        float headingDeg = Float.NaN;
        boolean gyroSaturated;
        int rotAccuracy;
        int magAccuracy;
        boolean hasOrientation;
        final float[] rotationMatrix = identityMatrix();

        Frame copy() {
            Frame n = new Frame();
            n.timestampNs = timestampNs; n.sessionMs = sessionMs;
            n.gx = gx; n.gy = gy; n.gz = gz; n.gyroMag = gyroMag;
            n.ax = ax; n.ay = ay; n.az = az; n.accelMag = accelMag; n.accelSaturated = accelSaturated;
            n.mx = mx; n.my = my; n.mz = mz; n.magMag = magMag;
            n.headingDeg = headingDeg; n.gyroSaturated = gyroSaturated;
            n.rotAccuracy = rotAccuracy; n.magAccuracy = magAccuracy;
            n.hasOrientation = hasOrientation;
            System.arraycopy(rotationMatrix, 0, n.rotationMatrix, 0, 9);
            return n;
        }
    }

    private static class Attempt {
        int candidateId;
        int index;
        long startTimestampNs;
        long endTimestampNs;
        double startSessionMs;
        double endSessionMs;
        double durationMs;
        final ArrayList<Frame> frames = new ArrayList<>();
        String closeReason = "";
        String userRating;

        boolean validMotion;
        boolean flipFlatRecognized;
        boolean targetedPrototype;
        String targetTrickName = "FLIP FLAT";
        String trickName = "MOVIMENTO";
        String proposedTrickName;
        String proposedTrickDescription;
        String proposedTrickCriteria;

        String dominantAxis = "?";
        double axisPurityPct;
        double peakGyroDegS;
        double highSpinMs;
        double mainSpinDurationMs;
        double spinWindowTurnsLowerBound;
        double spinRateLowerBoundRps;
        double saturationOnlyTurnsFloor;
        double orientationPathTurnsEstimate;
        double magVectorPathTurnsIndicator;
        double totalTurnsLowerBound;
        boolean saturated;
        double saturationMs;
        double saturationPctOfHighSpin;
        boolean accelSaturated;
        double accelSaturationMs;
        double minAccelG;
        double peakAccelG;
        double catchAccelG;
        double lowGMs;
        boolean lowGCandidate;
        double headingStartDeg = Double.NaN;
        double headingEndDeg = Double.NaN;
        double highSpinStartMs = Double.NaN;
        double highSpinEndMs = Double.NaN;
        double lastLowGMs = Double.NaN;
        double catchCandidateMs = Double.NaN;
        int sampleCount;
        double sampleDtMedianMs = Double.NaN;
        double sampleDtP95Ms = Double.NaN;
        double sampleDtMaxMs = Double.NaN;

        double finishNormalDeltaDeg = Double.NaN;
        boolean sameFaceFinish = false;
        double postSpinTurns700Ms = 0;
        double settleAfterMainMs = 0;
        int secondaryImpactCount = 0;
        boolean dropSuspected = false;
        double flightTimeCandidateMs = Double.NaN;
        double heightCandidateCm = Double.NaN;
        String trajectoryLabel = "INCERTA";
        double trajectoryXcm = 0, trajectoryYcm = 0, trajectoryZcm = 0;
        double trajectoryHorizontalCm = 0, trajectoryVerticalCm = 0;
        int points = 0;

        String spinGrade = "C";
        String axisGrade = "C";
        String finishGrade = "?";
        String catchGrade = "C";
        String overallGrade = "C";
        String styleLabel = "UNCLASSIFIED";
    }

    private static class PersistedAttempt {
        long whenMs; String trickName=""; String grade="—"; int points; double turns; boolean saturated; double axisPurity; String finishGrade="?"; String controlGrade="?"; String resultLabel="";
    }

    private static class TrickDefinition {
        final String name; final boolean official; final String status; final String tagline; final String description; final String[] criteria;
        TrickDefinition(String name, boolean official, String status, String tagline, String description, String[] criteria){this.name=name;this.official=official;this.status=status;this.tagline=tagline;this.description=description;this.criteria=criteria;}
        String criteriaText(){StringBuilder b=new StringBuilder();for(String c:criteria)b.append("• ").append(c).append('\n');return b.toString().trim();}
    }

    private static class SpinSegment {
        long startNs;
        long endNs;
        double pathRad;
        double highSpinMs;
        double satMs;
        double absX, absY, absZ;
        double orientationPath;
        double magVectorPath;
        float peakGyro;
    }

    private static class TrickProposal {
        int sourceAttempt;
        String name = "";
        String description = "";
        String criteria = "";
    }

    private class ReplayView extends View {
        private final Attempt attempt;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cameraPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint frontPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long replayStartMs = 0L;
        private boolean playing = false;
        private int frameIndex = 0;
        private static final float SLOW_FACTOR = 0.32f;

        ReplayView(Context context, Attempt attempt) {
            super(context);
            this.attempt = attempt;
            fill.setColor(C_ACID);
            fill.setStyle(Paint.Style.FILL);
            edge.setColor(Color.WHITE);
            edge.setStrokeWidth(dp(2));
            edge.setStyle(Paint.Style.STROKE);
            textPaint.setColor(Color.rgb(195, 201, 211));
            textPaint.setTextSize(dp(12));
            cameraPaint.setColor(Color.rgb(28, 30, 34));
            cameraPaint.setStyle(Paint.Style.FILL);
            frontPaint.setColor(Color.rgb(225, 229, 236));
            frontPaint.setStrokeWidth(dp(2));
        }

        void startReplay() {
            if (attempt.frames.isEmpty()) return;
            playing = true;
            frameIndex = 0;
            replayStartMs = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (attempt.frames.isEmpty()) return;

            Frame first = attempt.frames.get(0);
            Frame last = attempt.frames.get(attempt.frames.size() - 1);
            if (playing) {
                double targetSessionMs = first.sessionMs + (SystemClock.uptimeMillis() - replayStartMs) * SLOW_FACTOR;
                while (frameIndex + 1 < attempt.frames.size() && attempt.frames.get(frameIndex + 1).sessionMs <= targetSessionMs) {
                    frameIndex++;
                }
                if (frameIndex >= attempt.frames.size() - 1 || targetSessionMs >= last.sessionMs) {
                    playing = false;
                } else {
                    postInvalidateOnAnimation();
                }
            }

            Frame f = attempt.frames.get(Math.min(frameIndex, attempt.frames.size() - 1));
            // World reference: ground/horizon stays fixed while the phone rotates. Translation is an experimental inertial estimate.
            Paint groundPaint=new Paint(Paint.ANTI_ALIAS_FLAG);groundPaint.setColor(Color.rgb(70,72,76));groundPaint.setStrokeWidth(dp(1));
            float groundY=getHeight()*0.78f;canvas.drawLine(dp(16),groundY,getWidth()-dp(16),groundY,groundPaint);
            for(int gi=1;gi<=3;gi++)canvas.drawLine(dp(16),groundY+gi*dp(9),getWidth()-dp(16),groundY+gi*dp(9),groundPaint);
            double progress=Math.max(0,Math.min(1,(f.sessionMs-attempt.highSpinStartMs)/Math.max(1,attempt.highSpinEndMs-attempt.highSpinStartMs)));
            float tx=(float)(attempt.trajectoryXcm*progress); float ty=(float)(attempt.trajectoryYcm*progress); float tz=(float)(attempt.trajectoryZcm*progress);
            float maxT=(float)Math.max(12,Math.max(Math.abs(attempt.trajectoryXcm),Math.max(Math.abs(attempt.trajectoryYcm),Math.abs(attempt.trajectoryZcm))));
            float cx = getWidth() / 2f + (tx/maxT)*getWidth()*0.20f;
            float cy = getHeight() / 2f + dp(8) - (tz/maxT)*getHeight()*0.18f + (ty/maxT)*getHeight()*0.04f;
            float scale = Math.min(getWidth(), getHeight()) * 0.27f;

            float[][] pts = new float[][]{
                    {-0.58f, -1.0f, 0f},
                    { 0.58f, -1.0f, 0f},
                    { 0.58f,  1.0f, 0f},
                    {-0.58f,  1.0f, 0f}
            };
            Path p = new Path();
            for (int i = 0; i < pts.length; i++) {
                float[] v = rotate(f.rotationMatrix, pts[i][0], pts[i][1], pts[i][2]);
                float perspective = 1.0f / (1.0f + 0.18f * v[2]);
                float x = cx + v[0] * scale * perspective;
                float y = cy + v[1] * scale * perspective;
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            canvas.drawPath(p, fill);
            canvas.drawPath(p, edge);

            // Subtle front/back cue: the back gets a camera dot; the front gets a tiny earpiece mark.
            float[] normal = rotate(f.rotationMatrix, 0f, 0f, 1f);
            float[] cam = rotate(f.rotationMatrix, -0.38f, -0.70f, 0.02f);
            float camPerspective = 1.0f / (1.0f + 0.18f * cam[2]);
            float camX = cx + cam[0] * scale * camPerspective;
            float camY = cy + cam[1] * scale * camPerspective;
            if (normal[2] < 0) {
                canvas.drawCircle(camX, camY, dp(7), cameraPaint);
                canvas.drawCircle(camX + dp(2), camY - dp(2), dp(2), frontPaint);
            } else {
                float[] earA = rotate(f.rotationMatrix, -0.13f, -0.77f, 0.02f);
                float[] earB = rotate(f.rotationMatrix, 0.13f, -0.77f, 0.02f);
                float pa = 1.0f / (1.0f + 0.18f * earA[2]);
                float pb = 1.0f / (1.0f + 0.18f * earB[2]);
                canvas.drawLine(cx + earA[0] * scale * pa, cy + earA[1] * scale * pa,
                        cx + earB[0] * scale * pb, cy + earB[1] * scale * pb, frontPaint);
            }

            double rel = f.sessionMs - attempt.startSessionMs;
            String phase = phaseForFrame(attempt, f);
            canvas.drawText(String.format(Locale.US, "%s   %+5.0f ms", phase, rel), dp(12), dp(24), textPaint);
            canvas.drawText(String.format(Locale.US, "%s %.0f%%   %.0f°/s%s   TRJ %s*",
                    attempt.dominantAxis, attempt.axisPurityPct, Math.toDegrees(f.gyroMag),
                    f.gyroSaturated ? " MAX" : "", attempt.trajectoryLabel), dp(12), getHeight() - dp(14), textPaint);
        }

        private float[] rotate(float[] r, float x, float y, float z) {
            return new float[]{
                    r[0] * x + r[1] * y + r[2] * z,
                    r[3] * x + r[4] * y + r[5] * z,
                    r[6] * x + r[7] * y + r[8] * z
            };
        }
    }

    private class TrickIconView extends View {
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cam = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String trickName;
        TrickIconView(Context c) { this(c, activeTrickName); }
        TrickIconView(Context c, String trickName) {
            super(c);
            this.trickName=trickName==null?"FLIP FLAT":trickName;
            body.setColor(C_ACID); body.setStyle(Paint.Style.FILL);
            edge.setColor(Color.WHITE); edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(dp(2));
            cam.setColor(Color.rgb(28, 30, 34));
            arrow.setColor(Color.rgb(190, 196, 207)); arrow.setStyle(Paint.Style.STROKE); arrow.setStrokeWidth(dp(2));
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            Path p=new Path();
            p.moveTo(w*.22f,h*.26f); p.lineTo(w*.72f,h*.18f); p.lineTo(w*.82f,h*.72f); p.lineTo(w*.32f,h*.82f); p.close();
            c.drawPath(p,body); c.drawPath(p,edge);
            c.drawCircle(w*.34f,h*.34f,dp(5),cam);
            c.drawCircle(w*.36f,h*.32f,dp(2),edge);
            String n=trickName.toLowerCase(Locale.ROOT);
            if(n.contains("horizontal") || n.contains("transfer")){
                c.drawLine(w*.08f,h*.52f,w*.92f,h*.52f,arrow);
                c.drawLine(w*.08f,h*.52f,w*.18f,h*.44f,arrow);c.drawLine(w*.08f,h*.52f,w*.18f,h*.60f,arrow);
                c.drawLine(w*.92f,h*.52f,w*.82f,h*.44f,arrow);c.drawLine(w*.92f,h*.52f,w*.82f,h*.60f,arrow);
            }else if(n.contains("backflip")){
                Path a=new Path();a.moveTo(w*.22f,h*.78f);a.quadTo(w*.50f,h*.05f,w*.78f,h*.78f);c.drawPath(a,arrow);
                c.drawLine(w*.78f,h*.78f,w*.70f,h*.68f,arrow);c.drawLine(w*.78f,h*.78f,w*.67f,h*.80f,arrow);
            }else if(n.contains("punch")){
                c.drawLine(w*.50f,h*.12f,w*.50f,h*.88f,arrow);c.drawLine(w*.50f,h*.12f,w*.42f,h*.22f,arrow);c.drawLine(w*.50f,h*.12f,w*.58f,h*.22f,arrow);
            }else if(n.contains("crazy")){
                Path a=new Path();a.moveTo(w*.12f,h*.58f);a.cubicTo(w*.25f,h*.08f,w*.75f,h*.92f,w*.88f,h*.42f);c.drawPath(a,arrow);
                Path b=new Path();b.moveTo(w*.20f,h*.25f);b.cubicTo(w*.60f,h*.05f,w*.40f,h*.95f,w*.80f,h*.75f);c.drawPath(b,arrow);
            }else{
                Path a=new Path(); a.moveTo(w*.18f,h*.70f); a.quadTo(w*.05f,h*.42f,w*.20f,h*.20f); c.drawPath(a,arrow);
                c.drawLine(w*.20f,h*.20f,w*.13f,h*.23f,arrow); c.drawLine(w*.20f,h*.20f,w*.19f,h*.28f,arrow);
            }
        }
    }

    private class TimelineView extends View {
        private final Attempt a;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);

        TimelineView(Context c, Attempt a) {
            super(c);
            this.a = a;
            textP.setColor(Color.rgb(200, 205, 214));
            textP.setTextSize(dp(10));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(14), right = getWidth() - dp(14);
            float y = dp(44);
            p.setStrokeWidth(dp(7));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(65, 68, 78));
            canvas.drawLine(left, y, right, y, p);

            double start = a.frames.isEmpty() ? a.startSessionMs : a.frames.get(0).sessionMs;
            double end = a.frames.isEmpty() ? a.endSessionMs : a.frames.get(a.frames.size() - 1).sessionMs;
            double span = Math.max(1.0, end - start);

            if (!Double.isNaN(a.highSpinStartMs) && !Double.isNaN(a.highSpinEndMs)) {
                p.setColor(a.saturated ? Color.rgb(255, 188, 92) : Color.rgb(125, 255, 169));
                canvas.drawLine(mapX(a.highSpinStartMs, start, span, left, right), y,
                        mapX(a.highSpinEndMs, start, span, left, right), y, p);
            }
            if (!Double.isNaN(a.catchCandidateMs)) {
                p.setColor(Color.rgb(255, 118, 132));
                float x = mapX(a.catchCandidateMs, start, span, left, right);
                canvas.drawCircle(x, y, dp(7), p);
            }
            canvas.drawText("PREBUFFER", left, dp(20), textP);
            canvas.drawText(a.saturated ? "MAIN SPIN / MAX" : "MAIN SPIN", getWidth() * 0.38f, dp(20), textP);
            canvas.drawText("CONTROL", right - dp(48), dp(20), textP);
            canvas.drawText("main spin = bloco usado na nota • voo/queda ainda experimentais", left, getHeight() - dp(12), textP);
        }

        private float mapX(double v, double start, double span, float left, float right) {
            double ratio = Math.max(0, Math.min(1, (v - start) / span));
            return (float) (left + ratio * (right - left));
        }
    }

    private class SensorChartView extends View {
        static final int MODE_GYRO = 0;
        static final int MODE_ACCEL = 1;
        private final Attempt a;
        private final int mode;
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint px = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint py = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pz = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pacc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);

        SensorChartView(Context c, Attempt a, int mode) {
            super(c);
            this.a = a;
            this.mode = mode;
            grid.setColor(Color.rgb(55, 58, 66)); grid.setStrokeWidth(dp(1));
            px.setColor(Color.rgb(255, 112, 120)); px.setStrokeWidth(dp(1)); px.setStyle(Paint.Style.STROKE);
            py.setColor(Color.rgb(125, 255, 169)); py.setStrokeWidth(dp(1)); py.setStyle(Paint.Style.STROKE);
            pz.setColor(Color.rgb(105, 180, 255)); pz.setStrokeWidth(dp(1)); pz.setStyle(Paint.Style.STROKE);
            pacc.setColor(Color.rgb(255, 205, 105)); pacc.setStrokeWidth(dp(2)); pacc.setStyle(Paint.Style.STROKE);
            label.setColor(Color.rgb(190, 195, 205)); label.setTextSize(dp(9));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (a.frames.size() < 2) return;
            float left = dp(8), right = getWidth() - dp(8), top = dp(14), bottom = getHeight() - dp(22);
            for (int i = 0; i <= 4; i++) {
                float yy = top + (bottom - top) * i / 4f;
                canvas.drawLine(left, yy, right, yy, grid);
            }
            if (mode == MODE_GYRO) drawGyro(canvas, left, right, top, bottom);
            else drawAccel(canvas, left, right, top, bottom);
        }

        private void drawGyro(Canvas c, float left, float right, float top, float bottom) {
            double max = Math.max(1.0, getGyroMaxRange());
            Path x = new Path(), y = new Path(), z = new Path();
            for (int i = 0; i < a.frames.size(); i++) {
                Frame f = a.frames.get(i);
                float xx = timeX(f, left, right);
                float vx = mapSigned(f.gx, max, top, bottom);
                float vy = mapSigned(f.gy, max, top, bottom);
                float vz = mapSigned(f.gz, max, top, bottom);
                if (i == 0) { x.moveTo(xx, vx); y.moveTo(xx, vy); z.moveTo(xx, vz); }
                else { x.lineTo(xx, vx); y.lineTo(xx, vy); z.lineTo(xx, vz); }
            }
            c.drawPath(x, px); c.drawPath(y, py); c.drawPath(z, pz);
            c.drawText("X", left, bottom + dp(14), px);
            c.drawText("Y", left + dp(20), bottom + dp(14), py);
            c.drawText("Z", left + dp(40), bottom + dp(14), pz);
            c.drawText("± sensor max", right - dp(70), bottom + dp(14), label);
        }

        private void drawAccel(Canvas c, float left, float right, float top, float bottom) {
            double max = Math.max(3.0 * G, a.peakAccelG * G * 1.08);
            Path p = new Path();
            for (int i = 0; i < a.frames.size(); i++) {
                Frame f = a.frames.get(i);
                float xx = timeX(f, left, right);
                float yy = (float) (bottom - Math.min(1.0, f.accelMag / max) * (bottom - top));
                if (i == 0) p.moveTo(xx, yy); else p.lineTo(xx, yy);
            }
            c.drawPath(p, pacc);
            float oneG = (float) (bottom - (G / max) * (bottom - top));
            c.drawLine(left, oneG, right, oneG, grid);
            c.drawText("1g", left + dp(3), oneG - dp(3), label);
            c.drawText(String.format(Locale.US, "max scale %.1fg", max / G), right - dp(78), bottom + dp(14), label);
        }

        private float timeX(Frame f, float left, float right) {
            double start = a.frames.get(0).sessionMs;
            double end = a.frames.get(a.frames.size() - 1).sessionMs;
            double span = Math.max(0.001, end - start);
            double ratio = Math.max(0, Math.min(1, (f.sessionMs - start) / span));
            return (float) (left + ratio * (right - left));
        }

        private float mapSigned(double value, double max, float top, float bottom) {
            double n = Math.max(-1, Math.min(1, value / max));
            return (float) (top + (1 - (n + 1) / 2.0) * (bottom - top));
        }
    }
}

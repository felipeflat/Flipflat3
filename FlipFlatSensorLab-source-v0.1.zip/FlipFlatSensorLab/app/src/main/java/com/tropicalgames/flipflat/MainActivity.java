package com.tropicalgames.flipflat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int EXPORT_REQUEST = 701;
    private static final float G = SensorManager.GRAVITY_EARTH;

    // Intentionally conservative V0 thresholds. They are meant to be calibrated
    // after collecting a real session from the player.
    private static final float START_GYRO_RAD_S = 4.0f;
    private static final float STOP_GYRO_RAD_S = 1.20f;
    private static final long STOP_HOLD_NS = 280_000_000L;
    private static final long MIN_ATTEMPT_NS = 180_000_000L;
    private static final long MAX_ATTEMPT_NS = 3_500_000_000L;
    private static final float FREEFALL_ACCEL_MS2 = 5.0f;
    private static final long MIN_FREEFALL_NS = 25_000_000L;
    private static final int SENSOR_PERIOD_US = 5_000; // target ~200 Hz

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor rotationVector;
    private Vibrator vibrator;

    private boolean monitoring = false;
    private boolean attemptActive = false;

    private float ax = 0f, ay = 0f, az = G;
    private float accelMagnitude = G;
    private float tiltDeg = 0f;
    private float liveGyroDegS = 0f;

    private long lastGyroTimestampNs = 0L;
    private long attemptStartNs = 0L;
    private long lastAboveStopNs = 0L;
    private long freefallNs = 0L;

    private double angularPathRad = 0.0;
    private double absXRad = 0.0;
    private double absYRad = 0.0;
    private double absZRad = 0.0;
    private double signedXRad = 0.0;
    private double signedYRad = 0.0;
    private double signedZRad = 0.0;

    private float peakGyroRadS = 0f;
    private float minAccel = Float.MAX_VALUE;
    private float peakAccel = 0f;
    private float peakCatchAccel = 0f;
    private float peakTilt = 0f;
    private boolean freefallSeen = false;

    private int attemptCount = 0;
    private final ArrayList<Attempt> attempts = new ArrayList<>();
    private final ArrayList<String> rawRows = new ArrayList<>();

    private TextView statusText;
    private TextView sensorText;
    private TextView gyroText;
    private TextView accelText;
    private TextView tiltText;
    private TextView attemptsText;
    private Button playButton;
    private Button exportButton;
    private Button clearButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        buildUi();
        updateSensorStatus();
        renderAttempts();

        if (accelerometer == null || gyroscope == null) {
            playButton.setEnabled(false);
            statusText.setText("Este aparelho não possui os sensores mínimos necessários.");
        }
    }

    private void buildUi() {
        int pad = dp(18);
        int gap = dp(10);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(11, 12, 15));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(24), pad, dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("FLIP FLAT", 36, Color.WHITE, true);
        title.setLetterSpacing(0.08f);
        root.addView(title);

        TextView subtitle = text("Tropical Games  •  Sensor Lab V0.1", 14,
                Color.rgb(146, 255, 186), false);
        subtitle.setPadding(0, dp(2), 0, dp(18));
        root.addView(subtitle);

        TextView warning = text(
                "PROTOCOLO SEGURO DE TESTE\nUse sobre cama/sofá ou superfície macia, sem pessoas, animais ou objetos frágeis ao redor. Comece com arremessos baixos.",
                13, Color.rgb(235, 235, 235), false);
        warning.setPadding(dp(14), dp(12), dp(14), dp(12));
        warning.setBackground(roundRect(Color.rgb(37, 38, 44), 14));
        root.addView(warning, lpMatch(gap));

        sensorText = text("", 12, Color.LTGRAY, false);
        sensorText.setPadding(dp(2), dp(6), 0, dp(12));
        root.addView(sensorText);

        statusText = text("PRONTO", 20, Color.WHITE, true);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusText.setBackground(roundRect(Color.rgb(28, 29, 34), 16));
        root.addView(statusText, lpMatch(gap));

        LinearLayout liveRow = new LinearLayout(this);
        liveRow.setOrientation(LinearLayout.HORIZONTAL);
        liveRow.setWeightSum(3f);
        root.addView(liveRow, lpMatch(gap));

        gyroText = metric("GIRO\n0 °/s");
        accelText = metric("ACEL.\n1.00 g");
        tiltText = metric("TILT\n0°");
        liveRow.addView(gyroText, weighted());
        liveRow.addView(accelText, weightedWithLeftMargin(dp(6)));
        liveRow.addView(tiltText, weightedWithLeftMargin(dp(6)));

        playButton = new Button(this);
        playButton.setText("▶  PLAY / INICIAR SESSÃO");
        playButton.setTextSize(16);
        playButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        playButton.setTextColor(Color.rgb(10, 20, 13));
        playButton.setAllCaps(false);
        playButton.setBackground(roundRect(Color.rgb(125, 255, 169), 18));
        playButton.setPadding(dp(12), dp(15), dp(12), dp(15));
        playButton.setOnClickListener(v -> toggleMonitoring());
        root.addView(playButton, lpMatch(gap));

        TextView explainer = text(
                "O app abre uma tentativa quando detecta rotação forte e a fecha quando o giro estabiliza. " +
                        "Para cada tentativa calcula voltas equivalentes, eixo dominante, assinatura flat, duração, voo provável e picos de aceleração.",
                13, Color.rgb(188, 190, 198), false);
        explainer.setPadding(dp(4), dp(4), dp(4), dp(12));
        root.addView(explainer);

        TextView section = text("TENTATIVAS", 14, Color.rgb(146, 255, 186), true);
        section.setLetterSpacing(0.05f);
        root.addView(section);

        attemptsText = text("", 14, Color.WHITE, false);
        attemptsText.setTypeface(Typeface.MONOSPACE);
        attemptsText.setPadding(dp(14), dp(12), dp(14), dp(12));
        attemptsText.setBackground(roundRect(Color.rgb(24, 25, 30), 14));
        root.addView(attemptsText, lpMatch(gap));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setWeightSum(2f);
        root.addView(actionRow, lpMatch(0));

        exportButton = smallButton("EXPORTAR CSV");
        exportButton.setOnClickListener(v -> exportCsv());
        actionRow.addView(exportButton, weighted());

        clearButton = smallButton("ZERAR");
        clearButton.setOnClickListener(v -> clearSession());
        actionRow.addView(clearButton, weightedWithLeftMargin(dp(8)));

        TextView foot = text(
                "V0.1 = instrumento de validação, não sistema final de pontuação. Os thresholds serão calibrados com dados reais.",
                11, Color.rgb(132, 134, 143), false);
        foot.setPadding(dp(2), dp(16), dp(2), 0);
        root.addView(foot);

        setContentView(scroll);
    }

    private TextView metric(String value) {
        TextView t = text(value, 15, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(12), dp(6), dp(12));
        t.setBackground(roundRect(Color.rgb(30, 31, 37), 14));
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(roundRect(Color.rgb(48, 50, 58), 14));
        return b;
    }

    private void toggleMonitoring() {
        if (monitoring) stopMonitoring(); else startMonitoring();
    }

    private void startMonitoring() {
        if (accelerometer == null || gyroscope == null) return;
        monitoring = true;
        attemptActive = false;
        lastGyroTimestampNs = 0L;

        sensorManager.registerListener(this, accelerometer, SENSOR_PERIOD_US);
        sensorManager.registerListener(this, gyroscope, SENSOR_PERIOD_US);
        if (rotationVector != null) {
            sensorManager.registerListener(this, rotationVector, SENSOR_PERIOD_US);
        }

        playButton.setText("■  PARAR SESSÃO");
        playButton.setBackground(roundRect(Color.rgb(255, 199, 102), 18));
        statusText.setText("ARMADO • faça um Flip Flat");
    }

    private void stopMonitoring() {
        if (attemptActive) finishAttempt(lastGyroTimestampNs, "sessão encerrada");
        monitoring = false;
        attemptActive = false;
        sensorManager.unregisterListener(this);
        playButton.setText("▶  PLAY / INICIAR SESSÃO");
        playButton.setBackground(roundRect(Color.rgb(125, 255, 169), 18));
        statusText.setText("PAUSADO");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (monitoring) stopMonitoring();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!monitoring) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            ax = event.values[0];
            ay = event.values[1];
            az = event.values[2];
            accelMagnitude = (float) Math.sqrt(ax * ax + ay * ay + az * az);

            if (attemptActive) {
                minAccel = Math.min(minAccel, accelMagnitude);
                peakAccel = Math.max(peakAccel, accelMagnitude);
                if (accelMagnitude < FREEFALL_ACCEL_MS2) freefallSeen = true;
                if (freefallSeen) peakCatchAccel = Math.max(peakCatchAccel, accelMagnitude);
            }
            accelText.setText(String.format(Locale.US, "ACEL.\n%.2f g", accelMagnitude / G));
            return;
        }

        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] r = new float[9];
            SensorManager.getRotationMatrixFromVector(r, event.values);
            float cos = Math.min(1f, Math.max(-1f, Math.abs(r[8])));
            tiltDeg = (float) Math.toDegrees(Math.acos(cos));
            tiltText.setText(String.format(Locale.US, "TILT\n%.0f°", tiltDeg));
            if (attemptActive) peakTilt = Math.max(peakTilt, tiltDeg);
            return;
        }

        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            handleGyroscope(event);
        }
    }

    private void handleGyroscope(SensorEvent event) {
        float gx = event.values[0];
        float gy = event.values[1];
        float gz = event.values[2];
        float mag = (float) Math.sqrt(gx * gx + gy * gy + gz * gz);
        liveGyroDegS = (float) Math.toDegrees(mag);
        gyroText.setText(String.format(Locale.US, "GIRO\n%.0f °/s", liveGyroDegS));

        long ts = event.timestamp;
        double dt = 0.0;
        if (lastGyroTimestampNs != 0L) {
            dt = Math.max(0.0, Math.min(0.05, (ts - lastGyroTimestampNs) / 1_000_000_000.0));
        }
        lastGyroTimestampNs = ts;

        if (!attemptActive && mag >= START_GYRO_RAD_S) {
            beginAttempt(ts);
        }

        if (!attemptActive) return;

        if (dt > 0.0) {
            angularPathRad += mag * dt;
            absXRad += Math.abs(gx) * dt;
            absYRad += Math.abs(gy) * dt;
            absZRad += Math.abs(gz) * dt;
            signedXRad += gx * dt;
            signedYRad += gy * dt;
            signedZRad += gz * dt;
            if (accelMagnitude < FREEFALL_ACCEL_MS2) freefallNs += (long) (dt * 1_000_000_000L);
        }

        peakGyroRadS = Math.max(peakGyroRadS, mag);
        minAccel = Math.min(minAccel, accelMagnitude);
        peakAccel = Math.max(peakAccel, accelMagnitude);
        peakTilt = Math.max(peakTilt, tiltDeg);

        if (mag >= STOP_GYRO_RAD_S) lastAboveStopNs = ts;

        long durationNs = ts - attemptStartNs;
        long relativeMs = durationNs / 1_000_000L;
        rawRows.add(String.format(Locale.US,
                "%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.3f,%.3f",
                attemptCount + 1, relativeMs, ax, ay, az, gx, gy, gz, mag, accelMagnitude, tiltDeg));

        double previewTurns = angularPathRad / (Math.PI * 2.0);
        statusText.setText(String.format(Locale.US, "CAPTURANDO #%d  •  %.2f voltas",
                attemptCount + 1, previewTurns));

        boolean calmLongEnough = durationNs > MIN_ATTEMPT_NS && (ts - lastAboveStopNs) > STOP_HOLD_NS;
        boolean timedOut = durationNs > MAX_ATTEMPT_NS;
        if (calmLongEnough || timedOut) {
            finishAttempt(ts, timedOut ? "timeout" : "estabilizou");
        }
    }

    private void beginAttempt(long ts) {
        attemptActive = true;
        attemptStartNs = ts;
        lastAboveStopNs = ts;
        freefallNs = 0L;
        angularPathRad = 0.0;
        absXRad = absYRad = absZRad = 0.0;
        signedXRad = signedYRad = signedZRad = 0.0;
        peakGyroRadS = 0f;
        minAccel = accelMagnitude;
        peakAccel = accelMagnitude;
        peakCatchAccel = 0f;
        peakTilt = tiltDeg;
        freefallSeen = false;
        statusText.setText("CAPTURANDO #" + (attemptCount + 1));
    }

    private void finishAttempt(long ts, String closeReason) {
        if (!attemptActive) return;
        attemptActive = false;

        long durationNs = Math.max(1L, ts - attemptStartNs);
        double durationMs = durationNs / 1_000_000.0;
        double turns = angularPathRad / (Math.PI * 2.0);
        double xTurns = absXRad / (Math.PI * 2.0);
        double yTurns = absYRad / (Math.PI * 2.0);
        double zTurns = absZRad / (Math.PI * 2.0);
        double axisTotal = absXRad + absYRad + absZRad;
        double zDominance = axisTotal > 0.0 ? absZRad / axisTotal : 0.0;

        String dominantAxis = "X";
        double maxAxis = absXRad;
        if (absYRad > maxAxis) { dominantAxis = "Y"; maxAxis = absYRad; }
        if (absZRad > maxAxis) { dominantAxis = "Z"; }

        boolean probableFlight = freefallNs >= MIN_FREEFALL_NS || minAccel < FREEFALL_ACCEL_MS2;
        String signature;
        if (dominantAxis.equals("Z") && zDominance >= 0.72 && peakTilt <= 35f) {
            signature = "FLAT FORTE";
        } else if (dominantAxis.equals("Z") && zDominance >= 0.55) {
            signature = "FLAT MISTO";
        } else {
            signature = "MULTI-EIXO";
        }

        Attempt a = new Attempt();
        a.index = ++attemptCount;
        a.durationMs = durationMs;
        a.turns = turns;
        a.xTurns = xTurns;
        a.yTurns = yTurns;
        a.zTurns = zTurns;
        a.dominantAxis = dominantAxis;
        a.zDominancePct = zDominance * 100.0;
        a.peakGyroDegS = Math.toDegrees(peakGyroRadS);
        a.minAccelG = minAccel / G;
        a.peakAccelG = peakAccel / G;
        a.catchAccelG = peakCatchAccel / G;
        a.freefallMs = freefallNs / 1_000_000.0;
        a.peakTiltDeg = peakTilt;
        a.probableFlight = probableFlight;
        a.signature = signature;
        a.closeReason = closeReason;
        a.signedXDeg = Math.toDegrees(signedXRad);
        a.signedYDeg = Math.toDegrees(signedYRad);
        a.signedZDeg = Math.toDegrees(signedZRad);
        attempts.add(a);

        renderAttempts();
        statusText.setText(String.format(Locale.US, "#%d SALVO • %.2f voltas • %s",
                a.index, a.turns, a.signature));
        vibrateCapture();
    }

    private void renderAttempts() {
        if (attempts.isEmpty()) {
            attemptsText.setText("Nenhuma tentativa ainda.\nAperte PLAY e faça um arremesso baixo.");
            if (exportButton != null) exportButton.setEnabled(false);
            return;
        }

        if (exportButton != null) exportButton.setEnabled(true);
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, attempts.size() - 8);
        for (int i = attempts.size() - 1; i >= start; i--) {
            Attempt a = attempts.get(i);
            sb.append(String.format(Locale.US,
                    "#%02d  %.2f voltas  %s\n" +
                    "     pico %.0f°/s | %.0f ms | eixo %s\n" +
                    "     Z %.0f%% | tilt %.0f° | voo %s (%.0f ms)\n" +
                    "     acel min %.2fg | pico %.2fg | pós-voo %.2fg\n",
                    a.index, a.turns, a.signature,
                    a.peakGyroDegS, a.durationMs, a.dominantAxis,
                    a.zDominancePct, a.peakTiltDeg,
                    a.probableFlight ? "SIM" : "NÃO", a.freefallMs,
                    a.minAccelG, a.peakAccelG, a.catchAccelG));
            if (i > start) sb.append("\n");
        }
        attemptsText.setText(sb.toString());
    }

    private void updateSensorStatus() {
        String gyro = gyroscope == null ? "AUSENTE" : gyroscope.getName();
        String acc = accelerometer == null ? "AUSENTE" : accelerometer.getName();
        String rot = rotationVector == null ? "opcional ausente" : rotationVector.getName();
        sensorText.setText("Sensores\n• Giroscópio: " + gyro + "\n• Acelerômetro: " + acc + "\n• Vetor de rotação: " + rot);
    }

    private void clearSession() {
        if (attemptActive) return;
        attempts.clear();
        rawRows.clear();
        attemptCount = 0;
        renderAttempts();
        statusText.setText(monitoring ? "ARMADO • sessão zerada" : "PRONTO");
    }

    private void exportCsv() {
        if (attempts.isEmpty()) {
            Toast.makeText(this, "Faça ao menos uma tentativa primeiro.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "flipflat-session-" + stamp + ".csv");
        startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("Sem stream de saída");
            os.write(buildCsv().getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "CSV exportado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao exportar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String buildCsv() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Flip Flat Sensor Lab V0.1\n");
        sb.append("# Device sensors are sampled only while PLAY is active.\n");
        if (gyroscope != null) {
            sb.append("# gyroscope,").append(csv(gyroscope.getName())).append(",max_range_rad_s,")
                    .append(gyroscope.getMaximumRange()).append(",resolution,").append(gyroscope.getResolution()).append("\n");
        }
        if (accelerometer != null) {
            sb.append("# accelerometer,").append(csv(accelerometer.getName())).append(",max_range_ms2,")
                    .append(accelerometer.getMaximumRange()).append(",resolution,").append(accelerometer.getResolution()).append("\n");
        }
        if (rotationVector != null) {
            sb.append("# rotation_vector,").append(csv(rotationVector.getName())).append("\n");
        }
        sb.append("\nSUMMARY\n");
        sb.append("attempt,duration_ms,turns_equivalent,x_turns_abs,y_turns_abs,z_turns_abs,dominant_axis,z_dominance_pct,peak_gyro_deg_s,min_accel_g,peak_accel_g,post_freefall_peak_g,freefall_ms,peak_tilt_deg,probable_flight,signature,signed_x_deg,signed_y_deg,signed_z_deg,close_reason\n");
        for (Attempt a : attempts) {
            sb.append(String.format(Locale.US,
                    "%d,%.3f,%.6f,%.6f,%.6f,%.6f,%s,%.3f,%.3f,%.6f,%.6f,%.6f,%.3f,%.3f,%s,%s,%.3f,%.3f,%.3f,%s\n",
                    a.index, a.durationMs, a.turns, a.xTurns, a.yTurns, a.zTurns,
                    a.dominantAxis, a.zDominancePct, a.peakGyroDegS,
                    a.minAccelG, a.peakAccelG, a.catchAccelG, a.freefallMs,
                    a.peakTiltDeg, a.probableFlight ? "true" : "false",
                    a.signature, a.signedXDeg, a.signedYDeg, a.signedZDeg, a.closeReason));
        }
        sb.append("\nRAW_GYRO_SAMPLES\n");
        sb.append("attempt,t_ms,ax_ms2,ay_ms2,az_ms2,gx_rad_s,gy_rad_s,gz_rad_s,gyro_mag_rad_s,accel_mag_ms2,tilt_deg\n");
        for (String row : rawRows) sb.append(row).append('\n');
        return sb.toString();
    }

    private void vibrateCapture() {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // No-op for V0.1. Accuracy metadata can be added after first device tests.
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0f, 1.12f);
        return t;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams lpMatch(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = bottomMargin;
        return p;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams weightedWithLeftMargin(int margin) {
        LinearLayout.LayoutParams p = weighted();
        p.leftMargin = margin;
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String csv(String s) {
        if (s == null) return "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private static class Attempt {
        int index;
        double durationMs;
        double turns;
        double xTurns;
        double yTurns;
        double zTurns;
        String dominantAxis;
        double zDominancePct;
        double peakGyroDegS;
        double minAccelG;
        double peakAccelG;
        double catchAccelG;
        double freefallMs;
        double peakTiltDeg;
        boolean probableFlight;
        String signature;
        double signedXDeg;
        double signedYDeg;
        double signedZDeg;
        String closeReason;
    }
}

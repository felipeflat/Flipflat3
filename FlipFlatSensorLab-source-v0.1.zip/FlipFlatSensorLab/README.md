# Flip Flat V0.9 Alpha

V0.9 evolves the stable V0.8 Alpha without changing the core sensor capture pipeline.

## What changes in V0.9

- Seven player-facing maneuvers:
  1. Flip Flat
  2. Revolving Door
  3. Punch Line
  4. Shuriken
  5. Flip Flat Horizontal
  6. Crazy Not Random
  7. Backflip
- Adds an attitude metric measured before the main spin. It combines device orientation with the gravity direction from the accelerometer.
- Recognition now considers **rotation axis + phone attitude relative to the ground + trajectory + cross-axis mixture**.
- Revolving Door is the upright member of the Flip Flat/Y-axis family.
- Shuriken is the flat member of the Punch Line/Z-axis family.
- The supplied calibration session is cleanly separated by the V0.9 heuristic: both Revolving Door samples and all six Shuriken samples are recognized by their proposed labels in offline replay of the summary data.
- Technique grading is maneuver-specific. Axis-purity expectations differ by maneuver family instead of forcing one global threshold onto every physical motion.
- Flip Flat tutorial starts with the phone flat/side-on; Revolving Door keeps the upright door-like rotation.
- Punch Line remains front-facing and rotates in its own plane; Shuriken uses the same family with the phone laid down.
- Optional **Game Effects** are separate from the Motion Whistle.
  - judge start cue
  - judge stop cue
  - invalid/buzzer cue
  - increasingly rewarding C/B/A/S result cues
  - extra victory flourish for a new personal record or first S
- The result card is placed above the technical live meters and flashes the result color briefly when a new attempt closes.
- New records are highlighted in the result card.

## Core V0.8 capabilities retained

- Gyroscope / accelerometer / rotation vector / game rotation vector / magnetometer streams.
- Main-spin segmentation and saturation-aware lower-bound turns.
- Conservative recognition: low-confidence motion is allowed to remain unrecognized.
- Anti-touch protected play via immersive mode + optional Android screen pinning.
- Motion Whistle driven by gyroscope + accelerometer intensity.
- Immediate 3D replay, history, catalog, local records and achievements.
- Full raw CSV export, event markers, discarded candidates and developer/calibration mode.

## Scoring philosophy

- Overall grade remains the weakest validated scored criterion.
- Finish remains visible and contributes points, but still does not independently reduce the overall grade until synchronized video calibration is complete.
- Air-time/height remains a bonus signal rather than a hard grade criterion.
- Quantity remains numeric where possible; saturated readings remain honest lower bounds (`>N`).

## Build

- App id: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- versionCode: 10
- versionName: `0.9-alpha`

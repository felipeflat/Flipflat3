# Flip Flat — Sensor Lab V0.1

Prototype Android app for validating whether commodity phone sensors can reliably characterize a one-handed "Flip Flat" toss.

## What this V0 measures

- Gyroscope angular speed (rad/s and deg/s)
- Integrated equivalent rotations (total angular path / 360°)
- Absolute rotation contribution on X/Y/Z
- Dominant rotation axis
- Z-axis dominance as an early proxy for a flat spin
- Orientation tilt from the rotation-vector sensor, when available
- Accelerometer magnitude in g
- Minimum acceleration and free-fall-like interval
- Peak acceleration and post-freefall peak (rough catch/impact proxy)
- Attempt duration
- Automatic attempt segmentation
- Haptic confirmation when an attempt closes
- CSV export with attempt summaries and raw gyro-timestamped samples

## Important: this is a sensor-validation build

The thresholds are intentionally simple and visible in `MainActivity.java`. The goal is not to score tricks yet. The goal is to collect real throws from real devices, inspect the signal, and then calibrate classification and scoring.

Current defaults:

- Start attempt: gyro magnitude >= 4.0 rad/s
- End attempt: gyro magnitude < 1.2 rad/s for ~280 ms
- Probable free-fall: acceleration magnitude < 5.0 m/s²
- Flat signature heuristic: Z is the dominant axis and contributes strongly to total absolute axis rotation

## Suggested first test protocol

Use a bed/sofa or another soft, clear area.

1. Start a session.
2. Do 5 fast spins while keeping the phone in your hand (no toss).
3. Do 10 conservative low Flip Flat tosses.
4. Do 10 normal tosses.
5. Intentionally do 5 ugly / tilted tosses.
6. Export the CSV.

That dataset should be enough to calibrate the first real trick detector.

## Build

Open the project in a current Android Studio version and build the `app` debug variant. The project uses only Android framework APIs and has no runtime dependencies.

- Application ID: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36

## Product direction after sensor validation

A next iteration can convert the telemetry into:

- trick names and combo detection
- difficulty / style / flatness / catch quality scores
- personal bests and streaks
- leaderboards
- device-model calibration profiles
- anti-cheat / impossible-motion filters
- replayable telemetry visualizations


## Automatic APK build on GitHub

The repository includes `.github/workflows/build-apk.yml`.
Push the project to GitHub and run **Build Flip Flat APK** from the Actions tab (or push to `main`). The workflow installs JDK/Android SDK/Gradle, builds the debug APK, and uploads `FlipFlat-v0.1-debug-apk` as a workflow artifact.

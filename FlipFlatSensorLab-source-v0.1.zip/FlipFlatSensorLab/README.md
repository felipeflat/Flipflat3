# Flip Flat V0.8 Alpha

V0.8 polishes the **Flip Flat Alpha** while preserving the V0.7 sensor, recognition, protection and replay baseline.

## Alpha changes

- Main **Fazer manobra** CTA now opens maneuver selection instead of silently assuming Flip Flat.
- Adds **Modo Livre / Reconhecimento Beta** for automatic identification among the five current maneuvers.
- Directed attempts are conservative: if the measured signature does not match the selected maneuver, the result is **NAO VALIDADA** or **NAO RECONHECIDA**, never a forced score.
- Recognition uses the current phone-sensor signatures: dominant-axis shares, initial device orientation, trajectory estimate and cross-axis mixture.
- Recognition confidence and reasoning are exported to CSV for calibration.
- All five maneuvers now use the same procedural 3D replay engine as an animated **ideal model** in the catalog/play flow.
- Result screen keeps the real 3D replay immediately after the attempt.
- Criterion grades are visually stronger. Overall letter grade is the weakest validated criterion; an S requires S across all available validated criteria.
- Home wording uses **habilidade real + recorde digital**. UI copy was trimmed and back navigation made more compact.
- New black/orange launcher icon for a more radical, less green-heavy identity.

## Current five maneuvers

1. Flip Flat
2. Punch Line
3. Flip Flat Horizontal
4. Crazy Not Random
5. Backflip

The recognizer is intentionally conservative and still beta. Low-confidence attempts stay unrecognized and their full sensor traces remain available for calibration.

## V0.5 capabilities retained

- Gyroscope / accelerometer / rotation vector / game rotation vector / magnetometer streams.
- Main-spin segmentation and saturation-aware lower-bound turns.
- Axis purity, finish/control grades, trajectory estimate and drop suspicion.
- Anti-touch protected play via immersive mode + optional Android screen pinning.
- Full raw CSV export, event markers, discarded candidates, user ratings and maneuver proposals.
- Developer mode with replay, timeline and sensor charts.
- Local history, achievements/records shell and immediate post-attempt 3D replay.

## Build

- App id: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- versionCode: 9
- versionName: `0.8-alpha`


## V0.7 UX polish
- Punch Line tutorial corrected to a side-on, clock-axis rotation.
- Removed calibration/prototype/beta labels from player-facing screens.
- Catalog cards use equal visual hierarchy and emphasize best grade/points.
- Trick chooser shows best achieved result beside each challenge.
- Home risk statement simplified.
- Recognition confidence remains in developer logs/CSV only.


## V0.8 experience polish
- Punch Line tutorial now uses a pure front-facing Z-axis rotation: the whole phone spins in its own plane like a ninja star / clock hand.
- Optional **Motion Whistle** synthesizes a live high-pitched tone from gyroscope + accelerometer intensity; it can be toggled beside anti-touch protection.
- Grade hierarchy is much more visible across home, challenge chooser, catalog, history, result and criterion cards. S uses a vivid acid-lime treatment; lower grades progressively recede.
- No scoring thresholds or recognition rules were changed in this release.

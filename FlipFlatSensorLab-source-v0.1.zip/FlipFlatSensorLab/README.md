# Flip Flat — Closed Alpha V0.4

V0.4 keeps the V0.3 sensor/calibration engine and places a much more product-like experience on top of it. The visual direction is deliberately restrained: near-black, white, one acid-green accent, little glow, stronger challenge/lifestyle copy, and a separate developer mode so calibration work does not regress.

## Product shell

- Home: **FARME AURA. OU PASSE VERGONHA.** with one dominant CTA.
- First-play safety gate: playful tone, explicit personal/device responsibility, sofa/bed recommendation, no people/pets/glass/TV nearby.
- Play screen: selected maneuver, compact criteria, live capture, result, grade and points.
- Catalog + achievements: the catalog doubles as the progression guide.
- History: local attempt summaries survive normal app restarts within the same installation.
- Developer / Calibration mode: sensor list, live metrics, attempt cards, replay, graphs, ratings, proposals, video-sync tones and full CSV export remain available.

## Maneuver catalog in this alpha

Official:

1. **FLIP FLAT** — spin, axis lock, finish, control.

Calibration prototypes captured during testing:

2. **PUNCH LINE** — phone is side-on and rotates end-over-end; observer mainly sees a line.
3. **FLIP FLAT HORIZONTAL** — Flat-style rotation thrown laterally and caught by the other hand.
4. **CRAZY NOT RANDOM** — combines Flat rotation with end-over-end rotation; apparent chaos with intended dual-axis balance.
5. **BACKFLIP** — end-over-end rotation while aligned to the horizon, distinct from Punch Line.

Prototype maneuvers can be selected as a target. Their telemetry is labeled with the intended target but automatic recognition is deliberately not claimed yet. This makes future labeled calibration much easier.

## Scoring philosophy

For official Flip Flat:

- `Spin`: conservative numeric turns / speed, using `> N` when the gyro saturates.
- `Axis`: dominant-axis purity.
- `Finish`: same-face / orientation return.
- `Control`: post-spin stabilization.
- **Overall grade = the lowest validated criterion.** In V0.4 that means Spin, Axis and Control. Finish remains visible and influences points, but does not cap the letter grade until video ground truth validates it. Once validated, the intended rule is that S requires S across all official criteria.
- **Points** provide continuous differentiation inside/above a letter grade, using axis quality, conservative spin quantity, candidate air time, finish and control.

A user-confirmed `CAIU` is a fail. Automatic drop detection is a *suspicion* only until the video/labeled dataset is better; it no longer silently fails a trick by itself.

## World / ground reference in replay

The 3D replay now has a fixed ground reference. It also computes an **experimental inertial translation hint** by rotating accelerometer data into the world frame, estimating a pre-spin gravity baseline, subtracting it, and integrating the short main-spin interval.

This is intentionally labeled experimental. It is meant to tell us whether a movement trends vertical, lateral or mixed — especially useful for differentiating the same rotation performed upward versus hand-to-hand — not to claim centimeter-accurate tracking.

The front/back cue from V0.3 remains: camera marker on the back, earpiece cue on the front.

## Calibration / no-regression notes

Unchanged core capabilities from V0.3 include:

- ~200+ Hz gyro/accelerometer capture where the device supports it;
- prebuffer before trigger;
- strongest continuous main-spin segmentation;
- conservative gyro saturation lower bounds;
- raw independent gyro, accel, rotation-vector, game-rotation-vector and magnetometer streams;
- finish and post-spin analysis;
- front/back 3D replay;
- timeline and technical charts;
- BOA / MÉDIA / RUIM / CAIU ground-truth labels;
- local new-maneuver proposal with name, description and suggested criteria;
- video sync beeps;
- discarded-candidate logging;
- full calibration CSV export.

## Candidate filtering

The V0.3 two-stage false-positive gate remains: ordinary hand movement can trigger an internal candidate buffer, but the candidate is only shown as a maneuver if the strongest continuous spin block clears the minimum turn, peak-speed and duration thresholds. Discarded candidates remain in the exported CSV.

## Build

- Application ID: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- versionCode: 5
- versionName: `0.4-closed-alpha`
- no runtime third-party dependencies

## Closed-test note

History is local-only. There is no login, server, cloud leaderboard or moderation backend yet. The developer/calibration path should remain enabled for the closed group so telemetry and user ground truth can continue refining the sport rules before V1.

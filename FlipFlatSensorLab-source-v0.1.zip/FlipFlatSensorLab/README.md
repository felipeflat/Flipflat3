# Flip Flat V0.5 Closed Alpha

V0.5 keeps the V0.3/V0.4 sensor and calibration engine, but moves the product shell much closer to the approved UX direction.

## Product UX changes

- Home rebuilt from the approved black/white/acid-green visual direction.
- Cropped visual artwork from the approved mockups is used as in-app hero art; controls and text remain native Android views for responsiveness and interaction.
- Safety onboarding is now a full product screen instead of a utility dialog.
- Immediate post-trick result includes grade, points, criterion grades and the 3D sensor replay inline.
- Replay/details remain available from the session history and Developer/Calibration mode.
- Catalog cards include maneuver illustrations generated natively from maneuver type.
- Launcher icon added.

## Anti-touch / protected play (beta)

- Optional protected play calls Android `startLockTask()` (screen pinning for a normal app, with system confirmation where required).
- Immersive mode hides status/navigation bars while the app has focus.
- While a session is armed, Back is ignored and stopping requires a deliberate hold on the stop button.
- Product navigation links ignore taps while monitoring.

This reduces accidental exits but cannot make a normal consumer app an unbreakable kiosk without device-owner/device-policy privileges.

## Calibration engine retained

- Gyroscope / accelerometer / rotation vector / game rotation vector / magnetometer streams.
- Main-spin segmentation and saturation-aware lower-bound turns.
- Axis purity, finish/control grades, trajectory estimate, drop suspicion.
- Full raw CSV export, event markers, discarded candidates, user rating and maneuver proposals.
- Developer mode with replay, timeline and sensor charts.

## Build

- App id: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- versionName: `0.5-closed-alpha`

# Flip Flat — Calibration Lab V0.2.1

V0.2 moves Flip Flat from a pure sensor proof-of-concept into a calibration lab + early UX prototype.

## Product philosophy

A phone sensor does not need to provide perfect physical truth for Flip Flat to become a game. V0.2.1 preserves the numeric experience: when the gyro remains inside range the app shows an estimate such as `~ 2.4 turns`; when the gyro saturates it shows a lower bound such as `> 2.7 turns`, alongside the S/A/B/C grade. The number is never hidden just because the sensor reached its ceiling.

## New in V0.2

- Experimental S/A/B/C grades for spin, axis purity, catch and overall execution
- Friendly experimental labels such as `AXIS LOCK`, `MAX SPIN`, `CLEAN FLAT`, `WILD FLAT`
- Explicit gyroscope saturation detection and duration
- High-spin window metrics and lower-bound rotation estimate
- 650 ms pre-trigger buffer
- Per-attempt visual replay reconstructed from Rotation Vector / Game Rotation Vector orientation
- Technical detail screen with gyroscope X/Y/Z and acceleration graphs
- User self-rating per attempt: BOA / MÉDIA / RUIM
- Video synchronization beeps with logged timestamps
- Magnetometer / compass logging
- Rotation Vector + Game Rotation Vector logging
- Continuous raw sensor-event log with original sensor timestamps transformed to session time
- Rich per-attempt frame stream with orientation matrix, raw accelerometer, gyro and magnetic data
- Event markers: attempt start/end, high-spin window, saturation, low-G candidate and catch candidate

## Important calibration caveats

- Gyroscope saturation means rotation is a **lower bound**, not an exact count.
- Low acceleration alone does **not** prove flight during fast spin because centripetal acceleration can be strong.
- The replay shows the **sensor-estimated orientation**, not a reconstructed 3D trajectory through space.
- Grades and labels are experimental UX elements, not final competitive rules.

## Suggested filmed calibration protocol

1. Start a session.
2. Start recording with a second phone at 120/240 fps if possible.
3. Tap `SYNC VÍDEO` and keep the final GO beep audible in the recording.
4. Perform 5 held spins, 5 normal Flip Flats, 5 excellent executions, and 5 intentionally poor/wobbly executions.
5. After each attempt, open the attempt and mark BOA / MÉDIA / RUIM.
6. Export the V0.2 calibration CSV.
7. Compare external video, sensor replay, graphs and raw data.

## Sensors

Required:
- accelerometer
- gyroscope

Optional but logged when available:
- rotation vector
- game rotation vector
- magnetometer

## Build

- Application ID: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- version: `0.2-calibration-lab`


## V0.2.1 numeric-bound adjustment

- User-facing turn quantity stays visible.
- Saturated gyro results use `> N turns` rather than a fake exact value.
- Spin rate is also shown numerically (`~ N turns/s` or `> N turns/s`).
- S/A/B/C grades remain in parallel with the numeric result.
- Rotation-vector path and magnetometer-vector motion are exported as calibration cross-checks; they do not override the conservative gyro lower bound yet.
- Accelerometer saturation is logged too, so a catch can later be represented as a lower-bound impact if necessary.

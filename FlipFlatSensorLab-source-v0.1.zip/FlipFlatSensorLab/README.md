# Flip Flat — Product Alpha V0.3

V0.3 moves the project from a calibration lab toward a deliberately small product: one official trick, **FLIP FLAT**, plus a community path for discovering new tricks instead of inventing a large trick catalog upfront.

## What changed after the V0.2.1 field test

The 7 rated Flip Flat attempts showed a useful pattern: the user-rated bad attempt had only ~47% dominant-axis purity and a much lower spin rate, while the user-rated good attempt reached ~93% purity. The fast attempts saturated the gyro, so saturated numeric results remain conservative lower bounds (`> N turns`).

V0.3 therefore:

- evaluates the **strongest continuous spin burst**, not every bit of hand motion in the whole captured window;
- uses a two-stage motion gate so normal hand movements can be logged for calibration but are not shown as attempts;
- recognizes one official trick, `FLIP FLAT`, and keeps valid unknown movements as `NÃO RECONHECIDA`;
- lets the user attach a **new trick proposal** (name, description, suggested criteria) to an unknown or interesting attempt;
- adds a maneuver catalog with one official Flip Flat card and session proposals;
- adds a subtle camera/earpiece marker to the 3D replay so front/back are visible;
- adds an experimental **finish** metric based on returning to the same screen face/orientation;
- adds an experimental **control / possible drop** heuristic using post-spin motion and repeated impact peaks;
- adds `CAIU` as user ground truth alongside BOA / MÉDIA / RUIM;
- keeps candidate flight time and Newtonian height estimate in technical details only until video calibration;
- keeps magnetometer motion as a cross-check rather than pretending it is a calibrated rotation counter.

## Current Flip Flat scoring prototype

The score is intentionally small and readable:

- 40% spin (turn lower bound + speed)
- 40% axis purity
- 10% finish (same-face return, experimental)
- 10% control after the main spin
- possible/user-confirmed drop => fail

The weights and thresholds are still calibration parameters, not final sport rules.

## Candidate filtering

A normal movement can start a capture buffer, but it is only saved to the product UI when the main continuous spin segment reaches a minimum angular path and peak speed. Rejected candidates are preserved in the exported CSV under `DISCARDED_CANDIDATES`.

## Community trick growth

The Product Alpha starts with only `FLIP FLAT`. Any saved execution can open `PROPOR NOVA MANOBRA`, which stores:

- proposed name
- description
- suggested criteria
- source attempt id
- the attempt telemetry already exported by the app

In this alpha the proposal is local to the session and CSV. A later backend can submit proposals for moderation/approval and grow the sport catalog organically.

## Calibration caveats

- gyro saturation => lower bound, not exact turn count;
- magnetometer/orientation are secondary evidence until ground-truthed with video;
- flight/height use the main spin-burst duration as a candidate only; height assumes catch near launch height (`h = gT^2/8`);
- drop detection is a heuristic and needs labeled drop/catch examples before becoming an authoritative game rule;
- final-face detection uses sensor orientation and needs video validation.

## Build

- Application ID: `com.tropicalgames.flipflat`
- minSdk: 26
- target/compileSdk: 36
- version: `0.3-product-alpha`
